import * as React from "react"

interface Props {
  id: string
  isOpen: boolean
  contentLabel: string
  overlayClassName: string
  className: any
  shouldCloseOnOverlayClick(): void
  onRequestClose(): void
  parentSelector: any
  onAfterOpen(): void
}

export default class MockReactModal extends React.Component<Props, {}> {
  static setAppElement() {
    // In our application, we need this for accessibility but we don't have the full DOM/HTML file here so it won't work in Jest
  }
  render() {
    return (
      <div id={this.props.id}>{this.props.isOpen && this.props.children}</div>
    )
  }
}
