# GAMEBREAKER User Interface

## How to run

1. You will need Node.JS and Yarn to install the dependencies and run the GUI. To install Node.JS, go to https://nodejs.org/en/ and install. Once you've installed node, you can run the following command in your terminal to install Yarn: `npm i -g yarn`
2. In your terminal, run `yarn`
3. In your terminal, run `yarn start` to start the GUI. There is a mock api in the mock-api directory. That API can be run by using the following command in another terminal window: `node mock-api/index.js` or `yarn start:api`.
4. Open your browser to `localhost:3000`

## Generating Initial Configuration

There are a few different parts to the initial configuration: default values, ticks, and constants (maybe more in the future ?).

- Ticks are the possible values in the sliders
- Default values are the starting values for each slider
- Constants are settings like default teams, cost limits, server endpoint etc.

There is a script named `generate-config.js` it can be run via node like `node generate-config.js` or `yarn generate:config`. It pulls the json config files from the `raw-configs` folder. In the `raw-configs` folder, there are three files `constants.json`, `default_values.json`, and `ticks.json`. The `generate-config.js` script, pulls these files in and creates a `config.json` file in a format that the GUI is familiar with. Any changes to schema or format of the raw configs, may require some changes to the `generate-config.js` script.

## TODO

- Write some unit tests to test the transform functions?
- Implement actual API endpoint from python
