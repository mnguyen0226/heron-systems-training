const fs = require("fs")
const constants = require("./raw-configs/constants.json")
const default_values = require("./raw-configs/default_values.json")
const ticks = require("./raw-configs/ticks.json")
const upgrade_costs = require("./raw-configs/upgrade_costs.json")
const unit_costs = require("./raw-configs/unit_costs.json")

const config = { ...constants, races: {} }

Object.keys(ticks).forEach((key) => {
  config.races[key] = {
    units: {},
    upgrades: {},
    skill: {}
  }

  Object.keys(upgrade_costs).forEach((costKey) => {
    const regex = RegExp(/(Level\d)/)
    const match = costKey.match(regex)
    if (match) {
      const level = match[0].replace("Level", "")
      const keyWithoutLevel = costKey.replace(match[0], "")
      if (upgrade_costs[keyWithoutLevel]) {
        upgrade_costs[keyWithoutLevel].levels[level] = upgrade_costs[costKey]
      } else {
        upgrade_costs[keyWithoutLevel] = {
          levels: {
            [level]: upgrade_costs[costKey]
          }
        }
      }
      delete upgrade_costs[costKey]
    }
  })

  Object.keys(ticks[key]).forEach((t) => {
    let costs = null
    Object.keys(ticks[key][t]).forEach((s) => {
      if (t === "units") {
        costs = unit_costs[s]
      } else if (t === "upgrades") {
        costs = upgrade_costs[s]
      }
      config.races[key][t][s] = {
        ...config.races[key][t][s],
        ticks: ticks[key][t][s],
        default_value: default_values[key][s],
        value: default_values[key][s],
        min: ticks[key][t][s][0],
        max: ticks[key][t][s][ticks[key][t][s].length - 1],
        costs
      }
    })
  })
})

// Need to write to config.json and update UI. This seems fragile, maybe add some tests ?
fs.writeFile("./config.json", JSON.stringify(config), (err) => {
  if (err) {
    console.log(`Error writing config file: ${err}`)
  } else {
    console.log(`Successfully wrote config file`)
  }
})
