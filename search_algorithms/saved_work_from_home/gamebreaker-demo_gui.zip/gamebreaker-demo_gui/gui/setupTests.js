/**
 *  Mock the react-modal component due to the SetAppElement
 */
jest.mock("react-modal", () => {
  const React = require("react")
  const TestReactModal = require("./__mocks__/react-modal")
  return TestReactModal.default
})
