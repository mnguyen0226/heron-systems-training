import { Config, Race, RaceType, Settings, Team } from "types/index"

export const fromSlug = (str: string) => {
  if (str) {
    return str.charAt(0).toUpperCase() + str.slice(1)
  }
  return str
}

export const toSlug = (str: string) => {
  if (str) {
    return str.charAt(0).toLowerCase() + str.slice(1)
  }
  return str
}

export const removeSpaces = (str: string) => {
  if (str) {
    return str.replace(/ /g, "_")
  }
  return str
}

export const slugToLabel = (str: string) => {
  const EXCLUDED = ["TrueSkill"]
  if (EXCLUDED.indexOf(str) === -1) {
    return str.replace(/([A-Z])/g, " $1").trim()
  }
  return str
}

export const flattenConfig = (config: Race) => {
  // TODO: May need to convert values with spaces to _
  return {
    units: config.units,
    upgrades: config.upgrades,
    skill: config.skill
  }
}

export const formatSettingsForExport = (settings: Settings) => {
  const formatted = {}
  Object.keys(settings).map((k) => {
    const race = Object.keys(settings[k])[0]
    formatted[k] = {
      [race]: {}
    }
    Object.keys(settings[k][race]).map((category) => {
      if (settings[k][race][category]) {
        Object.keys(settings[k][race][category]).map((s) => {
          const setting = settings[k][race][category][s]
          formatted[k][race][s] = setting.value
        })
      }
    })
  })
  return formatted
}

export const calculateCostsAndAvailable = (
  config: Config,
  settings: Settings,
  team: Team,
  race: RaceType
) => {
  const { cost_limits } = config
  const { mineral: mineralMax, gas: gasMax } = cost_limits
  let mineralUsed = 0
  let gasUsed = 0
  let mineralAvailable = mineralMax - mineralUsed
  let gasAvailable = gasMax - gasUsed
  if (settings) {
    const r = settings[team][race]
    Object.keys(r).forEach((key) => {
      Object.keys(r[key]).forEach((setting) => {
        const { value, costs } = r[key][setting]
        if (value !== 0) {
          if (costs.levels) {
            if (costs.levels[value].minerals) {
              mineralUsed += costs.levels[value].minerals
            }
            if (costs.levels[value].gas) {
              gasUsed += costs.levels[value].gas
            }
          } else {
            if (costs.minerals) {
              mineralUsed += costs.minerals * value
            }
            if (costs.gas) {
              gasUsed += costs.gas * value
            }
          }
        }
        mineralAvailable = mineralMax - mineralUsed
        gasAvailable = gasMax - gasUsed
      })
    })
    return {
      mineral: {
        max: mineralMax,
        used: mineralUsed,
        available: mineralAvailable
      },
      gas: {
        max: gasMax,
        used: gasUsed,
        available: gasAvailable
      }
    }
  }
}
