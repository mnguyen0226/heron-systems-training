import * as Helpers from "./helpers"

describe("Test the helper functions", () => {
  it("Should test the toSlug", () => {
    const team = "Marine"
    expect(Helpers.toSlug(team)).toBe("marine")
  })
  it("Should return the label for a slug", () => {
    const slug = "marine"
    expect(Helpers.fromSlug(slug)).toBe("Marine")
  })
  it("Should return null if variable is null (toSlug)", () => {
    expect(Helpers.toSlug(null)).toBeFalsy()
  })
  it("Should return null if variable is null (fromSlug)", () => {
    expect(Helpers.fromSlug(null)).toBeFalsy()
  })
  it("Should return null if variable is null (removeSpaces)", () => {
    expect(Helpers.removeSpaces(null)).toBeFalsy()
  })
  it("Should remove spaces from a string and add an underscore", () => {
    expect(Helpers.removeSpaces("One Two")).toBe("One_Two")
  })
  it("Should transform the slug to a label with capitals", () => {
    expect(Helpers.slugToLabel("TrueSkill")).toBe("TrueSkill")
  })
})
