import "@testing-library/jest-dom/extend-expect"
import { render } from "@testing-library/react"
import * as React from "react"
import { ContextType, Provider } from "../Context"
const DefaultConfig = require("../../config.json")
import { flattenConfig, toSlug } from "util/helpers"

const FakePrediction = {
  blue: {
    terran: {
      win: 87.14101314544678,
      attrition: 59.77259278297424,
      minerals: 60.56172251701355,
      gas: 78.42156887054443,
      win_deltas: {
        Marine: [5.521911382675171, -86.73688326962292],
        Marauder: [-2.1589040756225586, -21.872371435165405],
        Reaper: [-24.635422229766846, -50.56710243225098],
        SiegeTank: [12.854456901550293, -87.08510994911194],
        Hellion: [12.4065101146698, -79.59497347474098],
        Cyclone: [12.850439548492432, -87.11261276039295],
        Thor: [-43.15060079097748, -22.739434242248535]
      }
    }
  },
  red: {
    protoss: {
      win: 12.858986854553223,
      attrition: 40.22740721702576,
      minerals: 39.43827748298645,
      gas: 21.578431129455566,
      win_deltas: {
        Zealot: [-11.565250158309937, 20.672404766082764],
        Stalker: [49.775075912475586, -6.557631492614746],
        Sentry: [82.92943462729454, -3.22343111038208],
        Adept: [87.1258743602084, -12.846148014068604],
        Immortal: [87.12932997077587, -12.858927249908447],
        Colossus: [87.1389600693874, -12.767279148101807],
        HighTemplar: [87.13991571066799, -10.943830013275146]
      }
    }
  }
}

const defaultContext: ContextType = {
  config: DefaultConfig,
  settings: {
    blue: {
      [toSlug(DefaultConfig.teams.blue)]: flattenConfig(
        DefaultConfig.races[DefaultConfig.teams.blue]
      )
    },
    red: {
      [toSlug(DefaultConfig.teams.red)]: flattenConfig(
        DefaultConfig.races[DefaultConfig.teams.red]
      )
    }
  },
  prediction: FakePrediction
}

const renderWithContext = (ui, customContext = {}) => {
  const context = { ...defaultContext, ...customContext }
  return render(<Provider value={context}>{ui}</Provider>)
}

export * from "@testing-library/react"
export { renderWithContext }
