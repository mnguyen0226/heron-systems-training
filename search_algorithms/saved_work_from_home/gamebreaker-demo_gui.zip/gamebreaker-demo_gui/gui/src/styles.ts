export default {
  container: {
    display: "flex",
    flexDirection: "column" as "column",
    flex: 1
  },
  main: {
    display: "flex",
    marginTop: 24,
    marginLeft: 16,
    marginRight: 16,
    marginBottom: 24,
    alignItems: "flex-start" as "flex-start"
  },
  loading: {
    position: "fixed" as "fixed",
    left: 0,
    top: 0,
    right: 0,
    bottom: 0,
    display: "flex",
    alignItems: "center" as "center",
    justifyContent: "center" as "center",
    backgroundColor: "rgba(0,0,0,.4)"
  }
}
