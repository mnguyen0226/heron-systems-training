import * as React from "react"
import { Config, RaceType, Team } from "./types"
import { State } from "./Provider"

const AppContext = React.createContext<ContextType>({})

const { Provider, Consumer } = AppContext

type ContextType = State & {
  config?: Config
  onChangeSetting?: (setting: string, value: number, team: Team) => void
  onSettingChangeComplete?: () => void // This may need a value like onChangeSetting but leave for now,
  onChangeRace?: (race: RaceType, team: Team) => void
}

const withAppContext = (Component) => {
  return function WrapperComponent(props) {
    return (
      <Consumer>
        {(context: ContextType) => <Component {...props} context={context} />}
      </Consumer>
    )
  }
}

export { Consumer, Provider, ContextType, withAppContext, AppContext }
