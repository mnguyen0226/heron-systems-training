export type Race = {
  units: {
    [key: string]: {
      ticks: number[]
      default_value: number
      value: number
      min: number
      max: number
      cost:
        | { minerals: number; gas: number }
        | { levels: { [level: number]: number } }
    }
  }
  upgrades: {
    [key: string]: {
      ticks: number[]
      default_value: number
      value: number
      min: number
      max: number
      cost:
        | { minerals: number; gas: number }
        | { levels: { [level: number]: number } }
    }
  }
  skill: {
    [key: string]: {
      ticks: number[]
      default_value: number
      value: number
      min: number
      max: number
      cost:
        | { minerals: number; gas: number }
        | { levels: { [level: number]: number } }
    }
  }
}

export type Config = {
  races: {
    [name: string]: Race
  }
  cost_limits: {
    mineral: number
    gas: number
  }
  teams: {
    blue: string
    red: string
  }
  server: string
}

export type Settings = {
  [team: string]: {
    [race: string]: Race
  }
}

export type Team = "red" | "blue"

const Teams = {
  RED: "red" as "red",
  BLUE: "blue" as "blue"
}

const Races = {
  TERRAN: "terran",
  PROTOSS: "protoss"
}

export type RaceType = "terran" | "protoss"

export type ColorObject = {
  [100]: string
  [200]: string
  [300]: string
  [400]: string
  [500]: string
  [600]: string
  [700]: string
  [800]: string
  [900]: string
}

export type Prediction = {
  [team: string]: {
    [race: string]: {
      win: number
      attrition: number
      minerals: number
      gas: number
      win_deltas: {
        [key: string]: number[]
      }
    }
  }
}

export { Teams, Races }
