import Alert from "elements/alert"
import * as React from "react"
import Loading from "react-loading"
import styles from "./styles"
import { Config, Prediction, RaceType, Settings, Team } from "./types/index"
import colors from "./util/colors"
import {
  calculateCostsAndAvailable,
  flattenConfig,
  formatSettingsForExport,
  toSlug
} from "./util/helpers"
import { Provider } from "./Context"
const clonedeep = require("lodash.clonedeep")
const DefaultConfig: Config = require("../config.json")

export type State = {
  loading?: boolean
  settings?: Settings
  prediction?: Prediction
  dirtyData?: boolean
  errors?: string[]
}

class AppProvider extends React.Component<{}, State> {
  state = {
    loading: true,
    settings: null,
    prediction: null,
    dirtyData: false,
    errors: null
  }
  componentDidMount() {
    this.loadData()
    this.init()
  }
  init = async () => {
    await this.loadData()
    this.sendData()
  }
  loadData = async () => {
    const { teams, races } = DefaultConfig
    const settings = {
      blue: {
        [toSlug(teams.blue)]: flattenConfig(races[teams.blue])
      },
      red: {
        [toSlug(teams.red)]: flattenConfig(races[teams.red])
      }
    }
    await this.setState({ settings })
  }
  sendData = async () => {
    this.setState({ loading: true })
    try {
      const body = JSON.stringify(formatSettingsForExport(this.state.settings))
      const response = await fetch(DefaultConfig.server, {
        method: "POST",
        body,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json"
        }
      })
        .then((r) => {
          return r.json()
        })
        .then((json) => {
          return json
        })
      this.setState({ prediction: response, loading: false })
    } catch (e) {
      const errors = [
        `${e} Ensure the prediction server is running and try again.`
      ]
      this.setState({ loading: false, errors })
    }
  }
  handleChangeSetting = (field: string, value: number, team: Team) => {
    const clone = clonedeep(this.state.settings)
    const teamSlug = toSlug(team)
    const [category, setting] = field.split(".")
    const race = Object.keys(clone[teamSlug])[0]
    clone[teamSlug][race][category][setting].value = value
    const isDataDirty =
      JSON.stringify(clone) !== JSON.stringify(this.state.settings)
    const projectedCosts = calculateCostsAndAvailable(
      DefaultConfig,
      clone,
      team,
      race as RaceType
    )
    if (
      projectedCosts.gas.used <= projectedCosts.gas.max &&
      projectedCosts.mineral.used <= projectedCosts.mineral.max
    ) {
      this.setState({ settings: clone, dirtyData: isDataDirty, errors: null })
    } else {
      const errors = []
      if (projectedCosts.gas.used > projectedCosts.gas.max) {
        errors.push("Not enough gas resources available")
      }
      if (projectedCosts.mineral.used > projectedCosts.mineral.max) {
        errors.push("Not enough mineral resources available")
      }
      this.setState({ errors })
    }
  }
  handleSettingChangeComplete = (...all) => {
    if (this.state.dirtyData) {
      this.sendData()
      this.setState({ dirtyData: false })
    }
  }
  handleChangeRace = (race: RaceType, team: Team) => {
    const { races } = DefaultConfig
    const clone = clonedeep(this.state.settings)
    const teamSlug = toSlug(team)
    const raceSlug = toSlug(race)
    clone[teamSlug] = {
      [raceSlug]: flattenConfig(races[race])
    }
    this.setState({ settings: clone }, () => this.sendData())
  }
  handleRequestAlertClose = () => {
    this.setState({ errors: null })
  }
  render() {
    return (
      <Provider
        value={{
          ...this.state,
          config: DefaultConfig,
          onChangeSetting: this.handleChangeSetting,
          onSettingChangeComplete: this.handleSettingChangeComplete,
          onChangeRace: this.handleChangeRace
        }}
      >
        <>
          {this.props.children}
          {this.state.loading && (
            <div style={styles.loading}>
              <Loading type="spin" color={colors.yellow[500]} />
            </div>
          )}
          <Alert
            errors={this.state.errors}
            requestClose={this.handleRequestAlertClose}
          />
        </>
      </Provider>
    )
  }
}

export default AppProvider
