import * as React from "react"
import styles from "./styles"

export default () => (
  <div style={styles.container}>
    <span style={styles.heading}>GAMEBREAKER</span>
  </div>
)
