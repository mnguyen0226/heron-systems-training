import * as React from "react"
import { render } from "util/test-utils"
import Header from "./"

describe("Test the <Header /> component", () => {
  it("Should render the header component successfully", () => {
    const { getByText } = render(<Header />)
    expect(getByText(/Gamebreaker/gim)).toBeTruthy()
  })
})
