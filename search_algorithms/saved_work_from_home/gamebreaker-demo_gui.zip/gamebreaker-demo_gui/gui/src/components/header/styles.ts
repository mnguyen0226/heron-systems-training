import colors from "util/colors"

export default {
  container: {
    height: 72,
    display: "flex",
    alignItems: "center" as "center",
    paddingLeft: 16,
    backgroundColor: colors.gray[200],
    maxWidth: "100%"
  },
  heading: {
    fontSize: 24,
    fontWeight: 700 as 700,
    color: colors.gray[700]
  }
}
