import colors from "util/colors"

export default {
  container: {
    backgroundColor: colors.gray[200],
    borderRadius: 8,
    boxShadow: "0px 4px 25px rgba(0,0,0, .12)",
    width: 600
  },
  settings: {
    display: "flex",
    flexDirection: "column" as "column"
  },
  settingsSection: {
    marginBottom: 24
  },
  lastSettingSection: {
    marginBottom: 0,
    borderBottomRightRadius: 40,
    paddingBottom: 0
  }
}
