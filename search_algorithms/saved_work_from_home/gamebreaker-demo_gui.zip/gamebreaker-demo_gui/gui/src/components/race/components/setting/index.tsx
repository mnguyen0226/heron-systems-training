import Slider from "elements/slider"
import * as React from "react"
import { Team, Teams } from "types/index"
import colors from "util/colors"
import { slugToLabel } from "util/helpers"
import styles from "./styles"

type Props = {
  label: string
  ticks: number | number[]
  min: number
  max: number
  value: number
  deltas: { decrease: number; increase: number }
  onChange: (value: number) => void
  onAfterChange: (value: number) => void
  index: number
  last?: boolean
  team: Team
}

const getColorForTeam = (team: Team) => {
  if (team === Teams.BLUE) {
    return colors.blue
  } else if (team === Teams.RED) {
    return colors.red
  }
}

export default (props: Props) => {
  const odd = props.index % 2
  const color = getColorForTeam(props.team)
  const label = slugToLabel(props.label)
  return (
    <div
      style={Object.assign(
        {},
        styles.container,
        odd && styles.odd,
        props.last && styles.last
      )}
    >
      <span style={styles.label}>{label}</span>
      <div style={styles.settingContainer}>
        <div style={styles.deltaContainer}>
          {Boolean(props.deltas.decrease) && (
            <span style={styles.delta}>
              {props.deltas.decrease > 0 && `+`}
              {props.deltas.decrease.toFixed(0)}%
            </span>
          )}
        </div>
        <Slider
          marks={props.ticks}
          min={props.min}
          max={props.max}
          value={props.value}
          onChange={props.onChange}
          onAfterChange={props.onAfterChange}
          step={1}
          color={color}
        />
        <div style={styles.deltaContainer}>
          {Boolean(props.deltas.increase) && (
            <span style={styles.delta}>
              {props.deltas.increase > 0 && `+`}
              {props.deltas.increase.toFixed(0)}%
            </span>
          )}
        </div>
        <span style={styles.value}>{props.value}</span>
      </div>
    </div>
  )
}
