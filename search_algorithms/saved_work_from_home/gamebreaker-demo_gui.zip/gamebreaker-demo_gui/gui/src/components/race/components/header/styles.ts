export default {
  container: {
    height: 72,
    paddingLeft: 16,
    borderTopRightRadius: 8,
    borderTopLeftRadius: 8,
    display: "flex",
    alignItems: "center",
    flex: 1
  },
  title: {
    fontSize: 24,
    fontWeight: 700 as 700
  }
}
