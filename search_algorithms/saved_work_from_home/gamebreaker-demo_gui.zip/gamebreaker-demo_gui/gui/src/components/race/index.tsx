import * as React from "react"
import { RaceType, Team } from "types/index"
import { calculateCostsAndAvailable, toSlug } from "util/helpers"
import { AppContext, ContextType } from "../../Context"
import Header from "./components/header"
import Setting from "./components/setting"
import Summary from "./components/summary"
import styles from "./styles"

type Props = {
  team: Team
  style?: any
}

export default (props: Props) => {
  const {
    settings,
    onChangeSetting,
    onSettingChangeComplete,
    onChangeRace,
    prediction,
    config
  } = React.useContext<ContextType>(AppContext)
  const race = settings && Object.keys(settings[toSlug(props.team)])[0]
  const raceObj = settings && settings[toSlug(props.team)][race]
  const predictionForRace = prediction && prediction[toSlug(props.team)][race]

  const costs = calculateCostsAndAvailable(
    config,
    settings,
    props.team,
    race as RaceType
  )
  const handleChange = (value: number, setting: string) => {
    const { team } = props
    onChangeSetting(setting, value, team)
  }
  const getLastSectionCategory = () => {
    let last = null
    if (raceObj) {
      Object.keys(raceObj).forEach((key) => {
        if (raceObj[key] && Object.keys(raceObj[key]).length) {
          last = key
        }
      })
    }
    return last
  }

  if (raceObj) {
    return (
      <div style={Object.assign({}, styles.container, props.style)}>
        <Header team={props.team} />
        <Summary
          race={race as RaceType}
          onChangeRace={(r) => onChangeRace(r, props.team)}
          costs={costs}
        />
        <div style={styles.settings}>
          {Object.keys(raceObj).map((key, i) => {
            const lastSection = getLastSectionCategory() === key
            console.log(getLastSectionCategory())
            if (raceObj[key]) {
              if (Object.keys(raceObj[key]).length) {
                return (
                  <div
                    style={Object.assign(
                      {},
                      styles.settingsSection,
                      lastSection && styles.lastSettingSection
                    )}
                    key={key}
                  >
                    {raceObj[key] &&
                      Object.keys(raceObj[key]).map((k, index) => {
                        const setting = raceObj[key][k]
                        const lastSetting =
                          Object.keys(raceObj[key]).length === index + 1
                        const deltas = { decrease: null, increase: null }
                        if (
                          predictionForRace &&
                          predictionForRace.win_deltas[k]
                        ) {
                          const delta_arr = predictionForRace.win_deltas[k]
                          deltas.decrease = delta_arr[0]
                          deltas.increase = delta_arr[1]
                        }
                        return (
                          <Setting
                            label={k}
                            min={setting.min}
                            max={setting.max}
                            ticks={10}
                            value={setting.value}
                            onChange={(val) => handleChange(val, `${key}.${k}`)}
                            deltas={{
                              decrease: deltas.decrease,
                              increase: deltas.increase
                            }}
                            index={index}
                            team={props.team}
                            key={index}
                            onAfterChange={onSettingChangeComplete}
                            last={lastSection && lastSetting}
                          />
                        )
                      })}
                  </div>
                )
              }
            }
          })}
        </div>
      </div>
    )
  } else {
    return null
  }
}
