import * as React from "react"
import { Teams } from "types/index"
import { renderWithContext } from "util/test-utils"
import Race from "./"

describe("Test the <Race /> component", () => {
  it("Should render successfully", () => {
    const { container } = renderWithContext(<Race team={Teams.BLUE} />)
    expect(container).toBeTruthy()
  })
})
