import * as React from "react"
import { RaceType } from "types/index"
import { fromSlug } from "util/helpers"
import { AppContext, ContextType } from "../../../../Context"
import styles from "./styles"

type Props = {
  onChangeRace: (race: RaceType) => void
  race: RaceType
  costs: {
    mineral: { max: number; used: number; available: number }
    gas: { max: number; used: number; available: number }
  }
}

export default (props: Props) => {
  const { config } = React.useContext<ContextType>(AppContext)
  return (
    <div style={styles.container}>
      <div style={styles.settingContainer}>
        <span style={styles.label}>Select Race</span>
        <select
          data-testid="race-select"
          value={props.race}
          onChange={(e) => props.onChangeRace(e.target.value as RaceType)}
        >
          {Object.keys(config.races).map((r) => {
            return (
              <option key={r} value={r}>
                {fromSlug(r)}
              </option>
            )
          })}
        </select>
      </div>
      <div style={styles.settingContainer}>
        <span style={styles.label}>
          Minerals <span style={styles.available}>(Available)</span>
        </span>
        <span style={styles.value}>
          {props.costs?.mineral?.used}
          <span style={styles.available}>
            ({props.costs?.mineral?.available})
          </span>
        </span>
      </div>
      <div style={styles.settingContainer}>
        <span style={styles.label}>
          Gas <span style={styles.available}>(Available)</span>
        </span>
        <span style={styles.value}>
          {props.costs?.gas?.used}
          <span style={styles.available}>({props.costs?.gas?.available})</span>
        </span>
      </div>
    </div>
  )
}
