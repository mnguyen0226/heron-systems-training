import * as React from "react"
import { Teams } from "types/index"
import { fireEvent, render } from "util/test-utils"
import Setting from "./"

const options = {
  ticks: [0, 1, 2, 3, 4],
  label: "Marine",
  value: 2,
  min: 0,
  max: 4,
  deltas: { decrease: -1, increase: 1 },
  onChange: null,
  index: 0,
  onAfterChange: null,
  team: Teams.BLUE
}

describe("Test the Race -> <Setting /> component", () => {
  it("Should render <Setting /> successfully", () => {
    const onChange = jest.fn()
    const onAfterChange = jest.fn()
    options.onAfterChange = onAfterChange
    options.onChange = onChange
    const { container } = render(<Setting {...options} />)
    expect(container).toBeTruthy()
  })
})
