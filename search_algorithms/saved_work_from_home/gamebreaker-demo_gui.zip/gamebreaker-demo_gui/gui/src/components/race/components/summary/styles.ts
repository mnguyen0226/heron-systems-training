import colors from "util/colors"

export default {
  container: {
    display: "flex",
    flexDirection: "row" as "row",
    paddingLeft: 16,
    paddingRight: 16,
    justifyContent: "space-between",
    paddingTop: 16,
    paddingBottom: 16,
    backgroundColor: colors.white
  },
  settingContainer: {
    display: "flex",
    flexDirection: "column" as "column",
    alignItems: "flex-start" as "flex-start",
    justifyContent: "flex-start" as "flex-start"
  },
  label: {
    textTransform: "uppercase" as "uppercase",
    fontSize: 14,
    fontWeight: 900 as 900,
    color: colors.gray[500],
    marginBottom: 12
  },
  value: {
    color: colors.gray[800],
    fontSize: 18,
    fontWeight: 700 as 700,
    display: "flex",
    flex: 1,
    alignItems: "center" as "center"
  },
  available: {
    color: colors.gray[500],
    fontWeight: 500 as 500,
    marginLeft: 8
  }
}
