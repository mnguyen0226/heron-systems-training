import * as React from "react"
import { Races, RaceType } from "types/index"
import { fireEvent, renderWithContext } from "util/test-utils"
import Summary from "./"

const options = {
  costs: null,
  race: Races.TERRAN as RaceType,
  onChangeRace: null
}

describe("Test the Race -> <Summary /> component", () => {
  it("Should render successfully", () => {
    const { container } = renderWithContext(<Summary {...options} />, null)
    expect(container).toBeTruthy()
  })
  it("Should call the onChangeRace when the select is changed", async () => {
    options.onChangeRace = jest.fn()
    const { getByTestId } = await renderWithContext(<Summary {...options} />)
    fireEvent.change(getByTestId("race-select"), {
      target: { value: "protoss" }
    })
    expect(options.onChangeRace).toHaveBeenCalledTimes(1)
  })
})
