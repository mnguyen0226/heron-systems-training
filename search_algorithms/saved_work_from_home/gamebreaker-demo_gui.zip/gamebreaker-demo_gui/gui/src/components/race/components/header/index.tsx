import * as React from "react"
import { Team, Teams } from "types/index"
import colors from "util/colors"
import styles from "./styles"

type Props = {
  team: Team
}

const getInfoForTeam = (team: Team) => {
  if (team === Teams.BLUE) {
    return {
      title: "Blue",
      background: colors.blue[500],
      text: colors.blue[100]
    }
  } else if (team === Teams.RED) {
    return {
      title: "Red",
      background: colors.red[500],
      text: colors.red[100]
    }
  }
}

export default (props: Props) => {
  const { team } = props
  const info = getInfoForTeam(team)
  return (
    <div
      style={Object.assign({}, styles.container, {
        backgroundColor: info.background
      })}
    >
      <span style={Object.assign({}, styles.title, { color: info.text })}>
        Team {info.title}
      </span>
    </div>
  )
}
