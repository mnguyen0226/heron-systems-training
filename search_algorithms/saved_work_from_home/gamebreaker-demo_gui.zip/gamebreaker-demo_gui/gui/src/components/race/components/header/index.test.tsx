import * as React from "react"
import { Teams } from "types/index"
import { render } from "util/test-utils"
import Header from "./"

describe("Test the Race -> <Header /> component", () => {
  it("Should render successfully", () => {
    const { getByText } = render(<Header team={Teams.BLUE} />)
    expect(getByText("Team Blue")).toBeInTheDocument()
  })
})
