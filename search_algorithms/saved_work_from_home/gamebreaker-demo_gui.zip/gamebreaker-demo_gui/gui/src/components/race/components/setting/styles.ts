import colors from "util/colors"

export default {
  container: {
    display: "flex",
    flexDirection: "row" as "row",
    paddingTop: 12,
    paddingBottom: 12,
    backgroundColor: colors.gray[100],
    paddingLeft: 16,
    paddingRight: 16
  },
  odd: {
    backgroundColor: colors.white
  },
  settingContainer: {
    display: "flex",
    flex: 1,
    flexDirection: "row" as "row",
    alignItems: "center" as "center"
  },
  label: {
    fontSize: 16,
    color: colors.gray[600],
    textTransform: "uppercase" as "uppercase",
    fontWeight: 600 as 600,
    display: "flex",
    alignItems: "center" as "center",
    width: 200
  },
  delta: {
    color: colors.gray[600],
    width: 40
  },
  last: {
    borderBottomRightRadius: 8,
    borderBottomLeftRadius: 8
  },
  value: {
    color: colors.gray[800],
    fontWeight: 700 as 700,
    marginLeft: 8,
    alignSelf: "flex-end" as "flex-end",
    flex: 1,
    width: 30,
    textAlign: "right" as "right"
  },
  deltaContainer: {
    width: 50
  }
}
