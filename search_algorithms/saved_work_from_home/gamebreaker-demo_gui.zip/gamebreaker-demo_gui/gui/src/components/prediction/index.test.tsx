import * as React from "react"
import { renderWithContext } from "util/test-utils"
import Prediction from "./"

describe("Test the <Prediction /> component", () => {
  it("Should render successfully", () => {
    const { container } = renderWithContext(<Prediction />)
    expect(container).toBeTruthy()
  })
})
