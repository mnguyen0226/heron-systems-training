import * as React from "react"
import { AppContext, ContextType } from "../../Context"
import PredictionBar from "./components/bar"
import styles from "./styles"

type Props = {}

export default (props: Props) => {
  const { prediction } = React.useContext<ContextType>(AppContext)
  const bluePrediction =
    prediction && prediction.blue[Object.keys(prediction.blue)[0]]
  const redPrediction =
    prediction && prediction.red[Object.keys(prediction.red)[0]]
  if (bluePrediction && redPrediction) {
    return (
      <div style={styles.container}>
        <div style={styles.header}>
          <span style={styles.heading}>Prediction</span>
        </div>
        <PredictionBar
          prediction={{ red: redPrediction, blue: bluePrediction }}
        />
        <div style={styles.resultTable}>
          <div style={styles.row}>
            <div
              style={Object.assign(
                {},
                styles.cell,
                styles.labelCell,
                styles.labelCellDark,
                styles.roundedTopLeft
              )}
            >
              <span style={styles.label}>Win Probability</span>
            </div>
            <div
              style={Object.assign(
                {},
                styles.cell,
                styles.blueCell,
                styles.blueCellDark
              )}
            >
              <span style={Object.assign({}, styles.value, styles.blueValue)}>
                {bluePrediction.win.toFixed(2)}%
              </span>
            </div>
            <div
              style={Object.assign(
                {},
                styles.cell,
                styles.redCell,
                styles.redCellDark,
                styles.roundedTopRight
              )}
            >
              <span style={Object.assign({}, styles.value, styles.redValue)}>
                {redPrediction.win.toFixed(2)}%
              </span>
            </div>
          </div>
          <div style={styles.row}>
            <div style={Object.assign({}, styles.cell, styles.labelCell)}>
              <span style={styles.label}>Expected Attrition (Minerals)</span>
            </div>
            <div style={Object.assign({}, styles.cell, styles.blueCell)}>
              <span style={Object.assign({}, styles.value, styles.blueValue)}>
                {bluePrediction.minerals.toFixed(2)}
              </span>
            </div>
            <div style={Object.assign({}, styles.cell, styles.redCell)}>
              <span style={Object.assign({}, styles.value, styles.redValue)}>
                {redPrediction.minerals.toFixed(2)}
              </span>
            </div>
          </div>
          <div style={styles.row}>
            <div
              style={Object.assign(
                {},
                styles.cell,
                styles.labelCell,
                styles.labelCellDark
              )}
            >
              <span style={styles.label}>Expected Attrition (Gas)</span>
            </div>
            <div
              style={Object.assign(
                {},
                styles.cell,
                styles.blueCell,
                styles.blueCellDark
              )}
            >
              <span style={Object.assign({}, styles.value, styles.blueValue)}>
                {bluePrediction.gas.toFixed(2)}
              </span>
            </div>
            <div
              style={Object.assign(
                {},
                styles.cell,
                styles.redCell,
                styles.redCellDark
              )}
            >
              <span style={Object.assign({}, styles.value, styles.redValue)}>
                {redPrediction.gas.toFixed(2)}
              </span>
            </div>
          </div>
          <div style={styles.row}>
            <div
              style={Object.assign(
                {},
                styles.cell,
                styles.labelCell,
                styles.roundedBottomLeft
              )}
            >
              <span style={styles.label}>Expected Units Lost</span>
            </div>
            <div style={Object.assign({}, styles.cell, styles.blueCell)}>
              <span style={Object.assign({}, styles.value, styles.blueValue)}>
                {bluePrediction.attrition.toFixed(2)}
              </span>
            </div>
            <div
              style={Object.assign(
                {},
                styles.cell,
                styles.redCell,
                styles.roundedBottomRight
              )}
            >
              <span style={Object.assign({}, styles.value, styles.redValue)}>
                {redPrediction.attrition.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>
    )
  }
  return null
}
