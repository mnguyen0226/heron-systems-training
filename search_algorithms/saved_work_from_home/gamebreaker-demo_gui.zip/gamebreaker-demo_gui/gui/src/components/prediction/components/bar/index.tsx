import * as React from "react"
import styles from "./styles"

type Props = {
  prediction: {
    red: {
      win: number
    }
    blue: {
      win: number
    }
  }
}

export default (props: Props) => {
  const { prediction } = props
  const showLabel = (winPct: number) => {
    if (winPct >= 10) {
      return true
    }
    return false
  }
  console.log(prediction.blue.win)
  if (prediction?.red?.win.toFixed(2) === "100.00") {
    return (
      <div style={Object.assign({}, styles.bar, styles.full, styles.redBar)}>
        <span style={Object.assign({}, styles.label, styles.redBarLabel)}>
          100%
        </span>
      </div>
    )
  } else if (prediction?.blue?.win.toFixed(2) === "100.00") {
    return (
      <div style={Object.assign({}, styles.bar, styles.full, styles.blueBar)}>
        <span style={Object.assign({}, styles.label, styles.blueBarLabel)}>
          100%
        </span>
      </div>
    )
  } else {
    return (
      <div style={styles.bar}>
        <div
          style={Object.assign(
            { width: `${prediction.blue.win}%` },
            styles.blueBar
          )}
        >
          {showLabel(prediction.blue.win) && (
            <span style={styles.blueBarLabel}>
              {prediction.blue.win.toFixed(2)}%
            </span>
          )}
        </div>
        <div
          style={Object.assign(
            { width: `${prediction.red.win}%` },
            styles.redBar
          )}
        >
          {showLabel(prediction.red.win) && (
            <span style={styles.redBarLabel}>
              {prediction.red.win.toFixed(2)}%
            </span>
          )}
        </div>
      </div>
    )
  }
}
