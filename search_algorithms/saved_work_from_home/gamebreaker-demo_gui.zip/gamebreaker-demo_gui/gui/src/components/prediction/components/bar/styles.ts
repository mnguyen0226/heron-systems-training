import colors from "util/colors"

export default {
  full: {
    width: "100%",
    borderRadius: 8
  },
  bar: {
    height: 48,
    width: "100%",
    backgroundColor: colors.gray[200],
    marginBottom: 24,
    display: "flex",
    alignItems: "center" as "center",
    justifyContent: "center" as "center"
  },
  blueBar: {
    borderTopLeftRadius: 8,
    borderBottomLeftRadius: 8,
    backgroundColor: colors.blue[500],
    display: "flex",
    alignItems: "center" as "center",
    justifyContent: "center" as "center",
    height: 48,
    minWidth: "1%",
    maxWidth: "99%"
  },
  blueBarLabel: {
    fontSize: 16,
    color: colors.blue[100],
    fontWeight: 700 as 700
  },
  redBar: {
    borderTopRightRadius: 8,
    borderBottomRightRadius: 8,
    backgroundColor: colors.red[500],
    display: "flex",
    alignItems: "center" as "center",
    justifyContent: "center" as "center",
    height: 48,
    minWidth: "1%",
    maxWidth: "99%"
  },
  redBarLabel: {
    fontSize: 16,
    color: colors.red[100],
    fontWeight: 700 as 700
  },
  label: {
    fontSize: 16,
    fontWeight: 700 as 700,
    color: colors.gray[700]
  }
}
