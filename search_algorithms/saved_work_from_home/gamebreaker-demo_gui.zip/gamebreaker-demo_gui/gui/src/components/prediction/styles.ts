import colors from "util/colors"

export default {
  container: {
    backgroundColor: colors.gray[100],
    alignSelf: "flex-start" as "flex-start",
    paddingLeft: 16,
    paddingRight: 16,
    paddingBottom: 16,
    borderRadius: 8,
    boxShadow: "0px 4px 25px rgba(0,0,0,.12)",
    width: 400,
    marginLeft: 24
  },
  header: {
    height: 72,
    display: "flex",
    alignItems: "center" as "center"
  },
  heading: {
    fontSize: 24,
    fontWeight: 700 as 700,
    color: colors.gray[700]
  },
  bar: {
    height: 48,
    width: "100%",
    backgroundColor: colors.gray[200],
    marginBottom: 24,
    display: "flex"
  },
  blueBar: {
    borderTopLeftRadius: 8,
    borderBottomLeftRadius: 8,
    backgroundColor: colors.blue[500],
    display: "flex",
    alignItems: "center" as "center",
    justifyContent: "center" as "center"
  },
  blueBarLabel: {
    fontSize: 16,
    color: colors.blue[100],
    fontWeight: 700 as 700
  },
  redBar: {
    borderTopRightRadius: 8,
    borderBottomRightRadius: 8,
    backgroundColor: colors.red[500],
    display: "flex",
    alignItems: "center" as "center",
    justifyContent: "center" as "center"
  },
  redBarLabel: {
    fontSize: 16,
    color: colors.red[100],
    fontWeight: 700 as 700
  },
  label: {
    fontSize: 16,
    fontWeight: 700 as 700,
    color: colors.gray[700]
  },
  value: {
    fontWeight: 700 as 700,
    color: colors.gray[700]
  },
  resultTable: {},
  row: {
    display: "flex"
    // paddingTop: 8,
    // paddingBottom: 8
  },
  cell: {
    width: "20%",
    paddingTop: 12,
    paddingBottom: 12,
    textAlign: "center" as "center"
  },
  labelCell: {
    width: "60%",
    textAlign: "left" as "left",
    paddingLeft: 12
  },
  blueCell: {
    backgroundColor: colors.blue[400]
  },
  redCell: {
    backgroundColor: colors.red[400]
  },
  redValue: {
    color: colors.red[900]
  },
  blueValue: {
    color: colors.blue[900]
  },
  labelCellDark: {
    backgroundColor: colors.gray[300]
  },
  blueCellDark: {
    backgroundColor: colors.blue[500]
  },
  redCellDark: {
    backgroundColor: colors.red[500]
  },
  roundedTopLeft: {
    borderTopLeftRadius: 4
  },
  roundedTopRight: {
    borderTopRightRadius: 4
  },
  roundedBottomRight: {
    borderBottomRightRadius: 4
  },
  roundedBottomLeft: {
    borderBottomLeftRadius: 4
  }
}
