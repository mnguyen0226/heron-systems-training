import * as React from "react"
import { render } from "util/test-utils"
import App from "./App"

describe("Test the App", () => {
  it("Should render successfully", () => {
    const { container } = render(<App />)
    expect(container).toBeTruthy()
  })
})
