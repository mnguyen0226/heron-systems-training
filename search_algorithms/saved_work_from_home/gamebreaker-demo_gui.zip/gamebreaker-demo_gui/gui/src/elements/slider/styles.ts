export default {
  container: {
    display: "flex",
    flexDirection: "column" as "column",
    marginLeft: 16,
    marginRight: 16,
    width: 200
  },
  main: {
    display: "flex"
  }
}
