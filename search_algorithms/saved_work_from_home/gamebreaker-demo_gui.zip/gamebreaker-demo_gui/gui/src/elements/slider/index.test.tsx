import * as React from "react"
import colors from "util/colors"
import { render } from "util/test-utils"
import Slider from "./"

describe("Test the <Slider /> component", () => {
  it("Should render successfully", () => {
    const { container } = render(
      <Slider
        marks={[1, 2]}
        min={0}
        max={10}
        value={5}
        onChange={null}
        onAfterChange={null}
        step={1}
        color={colors.blue}
      />
    )
    expect(container).toBeTruthy()
  })
})
