import Slider, {
  createSliderWithTooltip,
  Handle,
  SliderTooltip
} from "rc-slider"
import "rc-slider/assets/index.css"
import * as React from "react"
import { ColorObject } from "types/index"
import colors from "util/colors"
import styles from "./styles"

const SliderWithTooltip = createSliderWithTooltip(Slider)

const handle = (props) => {
  const { value, dragging, index, ...restProps } = props
  return (
    <SliderTooltip
      prefixCls="rc-slider-tooltip"
      overlay={`${value}`}
      visible={dragging}
      placement="top"
      key={index}
    >
      <Handle value={value} {...restProps} />
    </SliderTooltip>
  )
}

type Props = {
  min: number
  max: number
  step: number
  marks: any
  value: number
  onAfterChange: (value: number) => void
  onChange: (value: number) => void
  color: ColorObject
}

const CustomSlider: React.FC<Props> = (props: Props) => {
  return (
    <div style={styles.container}>
      <Slider
        min={props.min}
        max={props.max}
        onAfterChange={props.onAfterChange}
        onChange={props.onChange}
        value={props.value}
        step={props.step}
        railStyle={{ backgroundColor: colors.gray[300] }}
        trackStyle={{ backgroundColor: props.color[500] }}
        dotStyle={{ backgroundColor: props.color[500] }}
        handleStyle={{
          backgroundColor: props.color[500],
          border: "none",
          width: 24,
          height: 24,
          top: 0
        }}
        handle={handle}
      />
    </div>
  )
}

CustomSlider.defaultProps = {
  color: colors.gray
}

export default CustomSlider
