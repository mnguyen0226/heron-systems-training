import * as React from "react"
import { renderWithContext } from "util/test-utils"
import Alert from "./"

describe("Test the <Alert /> component", () => {
  it("Should render successfully", () => {
    const { container } = renderWithContext(<Alert />)
    expect(container).toBeTruthy()
  })
  it("Should open when an error is added", async () => {
    const { getByText } = renderWithContext(<Alert errors={["Fake Error"]} />)
    expect(getByText("Fake Error")).toBeInTheDocument()
  })
  it("Should render multiple errors", async () => {
    const { getByText } = renderWithContext(
      <Alert errors={["Fake Error", "Fake Error 2"]} />
    )
    expect(getByText("Fake Error")).toBeInTheDocument()
    expect(getByText("Fake Error 2")).toBeInTheDocument()
  })
  it("Should attempt to close when the `Close` element is clicked", () => {
    const onRequestClose = jest.fn()
    const { getByText } = renderWithContext(
      <Alert
        errors={["Fake Error", "Fake Error 2"]}
        requestClose={onRequestClose}
      />
    )
    const element = getByText("Close")
    element.click()
    expect(onRequestClose).toHaveBeenCalledTimes(1)
  })
})
