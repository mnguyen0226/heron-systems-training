import * as React from "react"
import { FiAlertCircle } from "react-icons/fi"
import Modal from "react-modal"
import styles from "./styles"

Modal.setAppElement("#root")

const customStyles = {
  content: {
    top: "50%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)",
    border: "none",
    padding: 0
  },
  overlay: {
    backgroundColor: "rgba(0,0,0,.5)"
  }
}

type Props = {
  errors?: string[]
  requestClose?: () => void
}

export default (props: Props) => {
  const [modalIsOpen, setIsOpen] = React.useState(false)
  React.useEffect(() => {
    if (!modalIsOpen && props.errors) {
      setIsOpen(true)
    }
  })
  const requestClose = () => {
    setIsOpen(false)
    props.requestClose()
  }
  return (
    <Modal
      isOpen={modalIsOpen}
      style={customStyles}
      onRequestClose={requestClose}
    >
      <div style={styles.container}>
        <div style={styles.header}>
          <FiAlertCircle style={styles.icon} />
          <span style={styles.heading}>
            Error{props.errors && props.errors.length > 1 && `s`}
          </span>
          <div style={styles.closeContainer}>
            <span onClick={requestClose} style={styles.close}>
              Close
            </span>
          </div>
        </div>
        <div style={styles.content}>
          {props.errors &&
            props.errors.length > 1 &&
            props.errors.map((error, index) => (
              <li key={index}>
                <span style={styles.message}>{error}</span>
              </li>
            ))}
          {props.errors && props.errors.length === 1 && (
            <span style={styles.message}>{props.errors[0]}</span>
          )}
        </div>
      </div>
    </Modal>
  )
}
