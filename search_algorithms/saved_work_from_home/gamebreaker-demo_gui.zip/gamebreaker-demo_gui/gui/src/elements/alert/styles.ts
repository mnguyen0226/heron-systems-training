import colors from "../../util/colors"
import Colors from "../../util/colors"

export default {
  absoluteContainer: {
    backgroundColor: "rgba(0,0,0,.4)",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    position: "fixed" as "fixed",
    display: "flex",
    alignItems: "center" as "center",
    justifyContent: "center" as "center",
    pointerEvents: "none" as "none"
  },
  container: {
    backgroundColor: "rgba(255, 255, 255, 1)",
    borderRadius: 4,
    zIndex: 999,
    boxShadow: "0px 2px 4px rgba(0,0,0,.12)",
    display: "flex",
    alignItems: "center",
    width: 400,
    flexDirection: "column" as "column"
  },
  message: {
    fontSize: 18,
    fontWeight: 500 as 500,
    color: Colors.gray[700],
    lineHeight: 1.6
  },
  icon: {
    color: Colors.red[100],
    fontSize: 24
  },
  header: {
    backgroundColor: colors.red[500],
    alignSelf: "stretch" as "stretch",
    height: 48,
    display: "flex",
    alignItems: "center",
    paddingLeft: 16,
    paddingRight: 16
  },
  heading: {
    color: colors.red[100],
    marginLeft: 12,
    fontSize: 24,
    fontWeight: 600 as 600
  },
  content: {
    padding: 24,
    alignSelf: "flex-start" as "flex-start"
  },
  close: {
    color: colors.red[100],
    fontSize: 16,
    cursor: "pointer" as "pointer"
  },
  closeContainer: {
    flex: 1,
    justifyContent: "flex-end" as "flex-end",
    display: "flex"
  }
}
