import Header from "components/header"
import Prediction from "components/prediction"
import Race from "components/race"
import * as React from "react"
import { render } from "react-dom"
import styles from "./styles"
import { Teams } from "./types"
import Provider from "./Provider"

const App = () => (
  <Provider>
    <div style={styles.container}>
      <Header />
      <div style={styles.main}>
        <Race team={Teams.BLUE} />
        <Race team={Teams.RED} style={{ marginLeft: 24 }} />
        <Prediction />
      </div>
    </div>
  </Provider>
)

render(
  <App />,
  document.getElementById("root") || document.createElement("div")
)

export default App
