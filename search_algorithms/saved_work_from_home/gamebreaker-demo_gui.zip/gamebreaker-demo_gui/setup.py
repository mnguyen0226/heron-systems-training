from setuptools import find_packages
from setuptools import setup

# https://github.com/kennethreitz/setup.py/blob/master/setup.py


with open("README.md", "r") as fh:
    long_description = fh.read()

extras = {
    "profiler": ["pyinstrument>=2.0"],
}
test_deps = ["pytest"]

all_deps = []
for group_name in extras:
    all_deps += extras[group_name]
all_deps = all_deps + test_deps
extras["all"] = all_deps


setup(
    name="gamebreaker",
    version="0.0.1dev0",
    author="heron",
    author_email="joe.tatusko@heronsystems.com",
    description="Reinforcement Learning for DeepRTS + SC2",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/heronsystems/adept-sc2",
    license="GNU",
    python_requires=">=3.5.0",
    packages=find_packages(),
    install_requires=[
        "absl-py<1,>=0.9.0",
        "adeptRL>=0.2.0",
        "cloudpickle<1.4.0,>=0.5",
        "deap==1.3.1",
        "docopt<1,>=0.6.2",
        "numpy<2,>=1.18.4",
        "matplotlib<4,>=3.0.0",
        "scikit-learn>=0.23.0",
        "omegaconf<3,>=2.0.5",
        "pandas==1.1.1",
        "plotly==4.10.0",
        "psutil",
        "pygame==1.9.6",
        "pysc2<4,>=3.0.0",
        "pytest",
        "requests",
        "shap>=0.35.0",
        "torch<2,>=1.5.0",
        "torchvision<1,>=0.6.0",
        "transitions==0.8.2",
    ],
    test_requires=test_deps,
    extras_require=extras,
    include_package_data=True,
)
