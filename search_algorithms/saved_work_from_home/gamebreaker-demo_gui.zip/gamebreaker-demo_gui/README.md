install pygame deps:
```sh
sudo apt-get install git python3-dev python3-setuptools python3-numpy python3-opengl \
    libsdl-image1.2-dev libsdl-mixer1.2-dev libsdl-ttf2.0-dev libsmpeg-dev \
    libsdl1.2-dev libportmidi-dev libswscale-dev libavformat-dev libavcodec-dev \
    libtiff5-dev libx11-6 libx11-dev fluid-soundfont-gm timgm6mb-soundfont \
    xfonts-base xfonts-100dpi xfonts-75dpi xfonts-cyrillic fontconfig fonts-freefont-ttf \
    libfreetype6-dev cmake
```

```sh
cp /media/banshee/gamebreaker/install/SC2.4.10.zip /tmp
unzip /tmp/SC2.4.10.zip -d ~/
# password is: iagreetotheeula

cd ~/Documents/gamebreaker
python setup.py develop
```

Helpful Links:
* [PySC2 Repository](https://github.com/deepmind/pysc2)
* [PySC2 Environment Configuration Class](https://github.com/deepmind/pysc2/blob/master/pysc2/lib/features.py#L470)
* [PySC2 Environment Documentation](https://github.com/deepmind/pysc2/blob/master/docs/environment.md)
