# """
# Testing for search
# """
# import random
# import unittest
# from pysc2.lib import units
# from gamebreaker.classifier.utils import DataDirHelper
# from gamebreaker.classifier.utils import DataType
# from gamebreaker.search.search import FullSearch
# from gamebreaker.search.search import GeneticSearch
# from gamebreaker.search.search import MonteCarloSearch
# from gamebreaker.selector.selector import GeneralUniformSelector
# from gamebreaker.unit_data import available_units
# class SearchTest(unittest.TestCase):
#     def test_monte_carlo_integration(self):
#         # MC algorithm is pretty much only integrating selector and classifier
#         helper = DataDirHelper("/media/banshee/gb_winprob/Data/proc_balanced_races", DataType.TRAIN)
#         state = helper.read_episode(0)[0][5]
#         MockNet = LogregMock()
#         self.test_selector = GeneralUniformSelector(
#             available_units([units.Terran]), (0, 10), (0, 10), 300, 200
#         )
#         test_search = MonteCarloSearch(MockNet, state, self.test_selector, 25)
#         # Testing Integration through 2 different random scenarios
#         for _ in range(2):
#             ally, wp = test_search.search()
#             print("Best Units:")
#             for ally_unit in ally:
#                 print(ally_unit["unit_type"], "at position", ally_unit["pos"])
#             print(wp)
#     def test_full_search_integration(self):
#         helper = DataDirHelper("/media/banshee/gb_winprob/Data/proc_balanced_races", DataType.TRAIN)
#         state = helper.read_episode(0)[0][5]
#         MockNet = LogregMock()
#         self.test_selector = GeneralUniformSelector(
#             available_units([units.Terran]), (0, 0), (0, 0), 300, 200
#         )
#         test_search = FullSearch(MockNet, state, self.test_selector, 10)
#         # Testing Integration through 2 different random scenarios
#         for _ in range(2):
#             ally, wp = test_search.search()
#             print("Best Units:")
#             for ally_unit in ally:
#                 print(ally_unit["unit_type"], "at position", ally_unit["pos"])
#             print(wp)
#     def test_genetic_search_integration(self):
#         helper = DataDirHelper("/media/banshee/gb_winprob/Data/proc_balanced_races", DataType.TRAIN)
#         state = helper.read_episode(0)[0][5]
#         MockNet = LogregMock()
#         self.test_selector = GeneralUniformSelector(
#             available_units([units.Terran]), (0, 0), (0, 0), 300, 200
#         )
#         test_search = GeneticSearch(MockNet, state, self.test_selector)
#         # Testing Integration through 2 different random scenarios
#         for _ in range(2):
#             ally, wp = test_search.search()
#             print("Best Units:")
#             for ally_unit in ally:
#                 print(ally_unit["unit_type"], "at position", ally_unit["pos"])
#             print(wp)
# class LogregMock:
#     def __init__(self):
#         pass
#     def forward(self, state):
#         return random.random()
