from typing import List

import pytest

from gamebreaker.selector import UpgradeSelector


class TestUpgradeSelector:
    @pytest.mark.parametrize(
        "upgrade_list,runtime_error",
        [([], False), (["Research_AdeptResonatingGlaives_quick"], False), (["NotAnUpgrade"], True)],
    )
    def test_upgrades_valid(self, upgrade_list: List[str], runtime_error: bool):
        try:
            _ = UpgradeSelector(upgrade_list)
            assert not runtime_error
        except RuntimeError:
            assert runtime_error

    @pytest.mark.parametrize(
        "upgrade_list,expected",
        [
            (
                ["Research_ProtossAirArmorLevel2_quick"],
                ["Research_ProtossAirArmorLevel1_quick", "Research_ProtossAirArmorLevel2_quick"],
            ),
            (
                ["Research_ProtossAirArmorLevel3_quick"],
                [
                    "Research_ProtossAirArmorLevel1_quick",
                    "Research_ProtossAirArmorLevel2_quick",
                    "Research_ProtossAirArmorLevel3_quick",
                ],
            ),
            (
                [
                    "Research_ProtossAirArmorLevel1_quick",
                    "Research_ProtossAirArmorLevel2_quick",
                    "Research_ProtossAirArmorLevel3_quick",
                ],
                [
                    "Research_ProtossAirArmorLevel1_quick",
                    "Research_ProtossAirArmorLevel2_quick",
                    "Research_ProtossAirArmorLevel3_quick",
                ],
            ),
        ],
    )
    def test_check_leveled_upgrades(self, upgrade_list: List[str], expected: List[str]):
        selector = UpgradeSelector(upgrade_list)
        produced_upgrades = selector.select()
        for upgrade in expected:
            assert upgrade in produced_upgrades, f"{upgrade} not in selector!"
        assert len(produced_upgrades) == len(expected)
