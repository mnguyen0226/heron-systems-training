import numpy as np
import torch
from adept.preprocess.base.preprocessor import CPUPreprocessor
from adept.preprocess.base.preprocessor import GPUPreprocessor
from adept.preprocess.ops import CastToFloat
from adept.preprocess.ops import FromNumpy
from pysc2.lib.features import FeatureUnit

from gamebreaker.env.base.obs_info import get_bit_length
from gamebreaker.env.base.obs_info import get_features_infos
from gamebreaker.env.base.ops import CopyOverScalarFeatures
from gamebreaker.env.base.ops import CreateEmptyArray
from gamebreaker.env.base.ops import FilterForNet
from gamebreaker.env.base.ops import ProcessCategoricalFeatures
from gamebreaker.env.base.ops import ProcessScalarFeatures


class TestPreprocessing:
    """
    Tests the preprocessing of data
    """

    @staticmethod
    def _setup_preprocessing(data_path):
        unit_max = 512
        x_max, y_max = 32, 32

        bit_length = get_bit_length(x_max, y_max)
        features_info = get_features_infos(x_max, y_max)

        observation_dtypes = {"raw_units": np.int64}
        observation_space = {"raw_units": (None, len(FeatureUnit))}

        cpu_preprocessor = CPUPreprocessor(
            [
                FromNumpy("raw_units", "raw_units"),
                CreateEmptyArray(unit_max, "raw_units", "proc_units"),
                ProcessCategoricalFeatures(
                    x_max, y_max, ["raw_units", "proc_units"], ["proc_units"]
                ),
                CopyOverScalarFeatures(["raw_units", "proc_units"], ["proc_units"]),
                FilterForNet("raw_units", "raw_units"),
            ],
            observation_space,
            observation_dtypes,
        )
        gpu_preprocessor = GPUPreprocessor(
            [
                ProcessScalarFeatures(x_max, y_max, "proc_units", "proc_units"),
                CastToFloat("proc_units", "proc_units"),
            ],
            cpu_preprocessor.observation_space,
            cpu_preprocessor.observation_dtypes,
        )

        raw_data = np.load(data_path, allow_pickle=True)

        new_data = torch.zeros(size=(len(raw_data), unit_max, 129))
        for j in range(len(raw_data)):
            obs = {"raw_units": raw_data[j]}
            new_data[j] = cpu_preprocessor(obs)["proc_units"]
        obs = {"proc_units": new_data}
        obs = gpu_preprocessor(obs)

        proc_data = obs["proc_units"]

        return (
            raw_data,
            proc_data,
            features_info,
            bit_length,
            cpu_preprocessor.ops[2].get_id,
        )

    def test_categorical(self):
        (raw_data, proc_data, features_info, bit_length, get_id,) = self._setup_preprocessing(
            "/media/banshee/gb_winprob/Data/balanced_races/Training/0/00000_1.npy"
        )
        for raw_step, proc_step in zip(raw_data, proc_data):
            for raw_unit, proc_unit in zip(raw_step, proc_step):
                for feature in bit_length:
                    info = features_info[feature]
                    rep = bin(get_id(int(raw_unit[info.raw_idx].item()), feature))[2:].zfill(
                        bit_length[feature]
                    )
                    for i in range(len(rep)):
                        assert int(rep[i]) == proc_unit[info.proc_idx + i].item()

    def test_scalar(self):
        (raw_data, proc_data, features_info, bit_length, get_id,) = self._setup_preprocessing(
            "/media/banshee/gb_winprob/Data/balanced_races/Training/0/00000_1.npy"
        )
        for raw_step, proc_step in zip(raw_data, proc_data):
            for raw_unit, proc_unit in zip(raw_step, proc_step):
                for feature in features_info:
                    if feature not in bit_length and feature != "on_creep":
                        info = features_info[feature]
                        expected = raw_unit[info.raw_idx] / info.range
                        assert expected == proc_unit[info.proc_idx]
