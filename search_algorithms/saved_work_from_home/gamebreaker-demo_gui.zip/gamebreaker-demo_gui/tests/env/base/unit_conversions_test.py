import unittest

import numpy as np
import pytest

from gamebreaker.env.base.obs_utils import get_proc_unit
from gamebreaker.env.base.obs_utils import get_raw_unit


class TestUnitConversions(unittest.TestCase):
    """Tests get_proc_unit() and get_raw_unit() from obs_utils"""

    @staticmethod
    def _setup_proc_to_raw(
        proc_file="/media/banshee/gb_winprob/Data/proc_dataset_v3/Testing/0/00000.npy",
    ):
        # Testing going from processed -> raw -> processed
        return np.load(proc_file, allow_pickle=True)[0]["data"]

    def test_proc_to_raw_unit(self):
        """Tests going from processed to raw data and back again"""
        proc_data = self._setup_proc_to_raw()
        proc_unit = proc_data[0, :, 0]
        new_proc_unit = get_proc_unit(get_raw_unit(proc_unit, 64, 64), 64, 64)
        assert (np.allclose(proc_unit, new_proc_unit)) == True

    def test_proc_to_raw_unit_list(self):
        proc_data = self._setup_proc_to_raw()
        proc_unit_list = proc_data[0, :, :]
        new_proc_unit_list = get_proc_unit(get_raw_unit(proc_unit_list, 64, 64), 64, 64)
        assert (np.allclose(proc_unit_list, new_proc_unit_list)) == True

    def test_proc_to_raw_unit_data(self):
        proc_data = self._setup_proc_to_raw()
        new_proc_data = get_proc_unit(get_raw_unit(proc_data, 64, 64), 64, 64)
        assert (np.allclose(proc_data, new_proc_data)) == True

    @staticmethod
    def _setup_raw_to_proc(
        raw_file="/media/banshee/gb_winprob/Data/raw_dataset_v3/Testing/0/00000_0.npy",
    ):
        # Test going from raw -> processed -> raw
        return np.load(raw_file, allow_pickle=True)[0]["data"]

    def test_raw_to_proc(self):
        raw_data = self._setup_raw_to_proc()
        raw_unit = raw_data[0][0, :]

        raw_unit.tag = 0
        new_raw_unit = get_raw_unit(get_proc_unit(raw_unit, 64, 64, map_tag=0), 64, 64)
        assert (np.allclose(raw_unit, new_raw_unit)) == True

    def test_raw_to_proc_timestep(self):
        raw_data = self._setup_raw_to_proc()
        raw_unit = raw_data[0][0, :]
        raw_timestep = raw_data[0]
        for unit_ix in range(raw_timestep.shape[0]):
            raw_timestep[unit_ix].tag = 0

        new_raw_timestep = get_raw_unit(get_proc_unit(raw_timestep, 64, 64, map_tag=0), 64, 64)

        assert (np.allclose(raw_timestep, new_raw_timestep)) == True
