import unittest

import pytest
import torch

from gamebreaker.env.base.obs_utils import bin_to_cat
from gamebreaker.env.base.obs_utils import cat_to_bin
from gamebreaker.env.base.obs_utils import scale


class TestObsUtils(unittest.TestCase):
    """Tests observation utils"""

    @staticmethod
    def _setup_cat_to_bin(start_idx: int = 0):
        """Sets up values for cat to bin tests

        Parameters
        ----------
        start_idx : int
            start index of output tensor, by default 0

        Returns
        -------
        List[Tuple[int, torch.Tensor]]
            list of input and expected output pairs
        """
        inputs = [0, 1, 2, 8, 18, 31]  # range: 31 (5-bits)
        l_pad = [0 for _ in range(start_idx)]
        outputs = [
            torch.Tensor(l_pad + [0, 0, 0, 0, 0]),
            torch.Tensor(l_pad + [0, 0, 0, 0, 1]),
            torch.Tensor(l_pad + [0, 0, 0, 1, 0]),
            torch.Tensor(l_pad + [0, 1, 0, 0, 0]),
            torch.Tensor(l_pad + [1, 0, 0, 1, 0]),
            torch.Tensor(l_pad + [1, 1, 1, 1, 1]),
        ]

        return [*zip(inputs, outputs)]

    def test_cat_to_bin_idx0(self):
        """Tests cat to bin method"""
        # test for start idx of 0
        out_tensor = torch.zeros(5)  # tensor used to store output
        value_pairs = self._setup_cat_to_bin()

        for in_val, desired_output in value_pairs:
            cat_to_bin(in_val, 31, out_tensor)

            assert torch.allclose(desired_output, out_tensor) == True

    def test_cat_to_bin_idx2(self):
        # test for start idx of 2
        out_tensor = torch.zeros(7)  # tensor used to store output
        value_pairs = self._setup_cat_to_bin(start_idx=2)

        for in_val, desired_output in value_pairs:
            cat_to_bin(in_val, 31, out_tensor, 2)

            assert torch.allclose(desired_output, out_tensor) == True

    def test_bit_err_1(self):
        # test that raises error when out tensor is of insufficient size
        with self.assertRaises(AssertionError):
            cat_to_bin(
                0, 31, torch.zeros(4)
            )  # needs 5 bits to store max val 31, given 4 bit tensor

    def test_bit_err_2(self):
        with self.assertRaises(AssertionError):
            cat_to_bin(
                0, 31, torch.zeros(5), 1
            )  # needs 5 bits to store max val 31, given 4 usable bits

    @staticmethod
    def _setup_bin_to_cat(start_idx: int = 0):
        """Sets up values for bin to cat tests

        Parameters
        ----------
        start_idx : int
            start index of output tensor, by default 0

        Returns
        -------
        List[Tuple[torch.Tensor, int]]
            list of input and expected output pairs
        """
        l_pad = [0 for _ in range(start_idx)]
        inputs = [
            torch.Tensor(l_pad + [0, 0, 0, 0, 0]),
            torch.Tensor(l_pad + [0, 0, 0, 0, 1]),
            torch.Tensor(l_pad + [0, 0, 0, 1, 0]),
            torch.Tensor(l_pad + [0, 1, 0, 0, 0]),
            torch.Tensor(l_pad + [1, 0, 0, 1, 0]),
            torch.Tensor(l_pad + [1, 1, 1, 1, 1]),
        ]
        outputs = [0, 1, 2, 8, 18, 31]  # range: 31 (5-bits)

        return [*zip(inputs, outputs)]

    def test_bin_to_cat_idx0(self):
        """Tests bin to cat method"""
        num_bits = 5

        # test for start idx of 0
        value_pairs = self._setup_bin_to_cat()

        for in_val, desired_output in value_pairs:
            out_val = bin_to_cat(in_val, num_bits)

            assert desired_output == out_val

    def test_bin_to_cat_idx2(self):
        """Tests bin to cat method"""
        num_bits = 5
        # test for start idx of 2
        value_pairs = self._setup_bin_to_cat(start_idx=2)

        for in_val, desired_output in value_pairs:
            out_val = bin_to_cat(in_val, num_bits, start_idx=2)

            assert desired_output == out_val

    def test_bit_err_3(self):
        # test that raises error when out tensor is of insufficient size
        with self.assertRaises(AssertionError):
            bin_to_cat(torch.zeros(4), 5)

    def test_bit_err_4(self):
        with self.assertRaises(AssertionError):
            bin_to_cat(
                torch.zeros(5), 5, 1
            )  # needs 5 bits to store max val 31, given 4 usable bits

    @staticmethod
    def _setup_scale():
        """Sets up values for cat to bin tests

        Returns
        -------
        List[Tuple[float, Tuple[float, float], float]]
            list of input, range, and expected output sets
        """
        inputs = [0, 10, 7.5, 14, 24.5, 0, -50, -30]
        ranges = [
            (0, 10),
            (0, 10),
            (0, 10),
            (0, 28),
            (0, 28),
            (-50, 50),
            (-50, 50),
            (-50, 50),
        ]

        outputs = [-1, 1, 0.5, 0, 0.75, 0, -1, -0.6]

        return [*zip(inputs, ranges, outputs)]

    def test_scale(self):
        """Tests scale method"""
        value_sets = self._setup_scale()

        for in_val, val_range, output in value_sets:
            assert output == pytest.approx(scale(in_val, val_range))
