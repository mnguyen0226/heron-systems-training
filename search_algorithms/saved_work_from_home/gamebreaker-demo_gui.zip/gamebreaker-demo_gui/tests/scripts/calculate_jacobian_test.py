from typing import List

import numpy as np
import pytest
import torch
from pysc2.lib.features import FeatureUnit

from gamebreaker.data.unit_stats import MAX_STATS
from gamebreaker.scripts.calculate_jacobian import get_labeled_jacobian
from gamebreaker.scripts.calculate_jacobian import get_normalized_jacobian
from gamebreaker.scripts.calculate_jacobian import get_sorted_jacobian
from gamebreaker.scripts.calculate_jacobian import remove_redundant_axes


class TestRemoveRedundantAxes:
    @pytest.mark.parametrize("nb_units", [1, 256, 512])
    def test_dimensions_are_correct(self, nb_units: int):
        """Tests that the number of dimensions are correct in remove_redundant_axes()

        Parameters
        ----------
        nb_units: int
            Number of units in the input vector

        Returns
        -------
        None
        """
        test_input = tuple(
            (torch.zeros(1, 1, nb_units, len(FeatureUnit)), torch.ones(1, 1, len(MAX_STATS), 512))
            for _ in range(5)
        )

        test_output = remove_redundant_axes(test_input)

        assert all(tensors.ndim == 2 for tensors in test_output)

    @pytest.mark.parametrize("nb_units", [1, 256, 512])
    def test_shapes_are_correct(self, nb_units: int):
        """Tests that the shapes are correct in remove_redundant_axes()

        Parameters
        ----------
        nb_units: int
            Number of units in the input vector

        Returns
        -------
        None
        """
        test_input = tuple(
            (torch.zeros(1, 1, nb_units, len(FeatureUnit)), torch.ones(1, 1, len(MAX_STATS), 512))
            for _ in range(5)
        )

        test_output = remove_redundant_axes(test_input)

        expected_shape = (nb_units, (len(MAX_STATS) + len(FeatureUnit) - 1))
        for tensors in test_output:
            assert tensors.shape == expected_shape

    @pytest.mark.parametrize("nb_units", [1, 256, 512])
    def test_stats_placement(self, nb_units: int):
        """Tests that the stats are ordered correctly in remove_redundant_axes()

        Parameters
        ----------
        nb_units: int
            Number of units in the input vector

        Returns
        -------
        None
        """
        test_input = tuple(
            (torch.zeros(1, 1, nb_units, len(FeatureUnit)), torch.ones(1, 1, len(MAX_STATS), 512))
            for _ in range(5)
        )

        test_output = remove_redundant_axes(test_input)

        for jac in test_output:
            assert torch.equal(
                jac[:, 0 : len(MAX_STATS)], torch.ones_like(jac[:, 0 : len(MAX_STATS)])
            )
            assert torch.equal(jac[:, len(MAX_STATS) :], torch.zeros_like(jac[:, len(MAX_STATS) :]))


def test_get_labeled_jacobian():
    """Tests that get_labeled_jacobian() returns a dictionary with all labels and that they match
    the input

    Returns
    -------

    """
    labels = ["A", "B", "C", "D", "E"]
    test_input = tuple(torch.zeros(10) + i for i in range(len(labels)))

    output_dict = get_labeled_jacobian(test_input, labels)

    for ix, label in enumerate(labels):
        assert label in output_dict, f"{label} not in output dictionary!"
        assert (
            torch.equal(output_dict[label], torch.zeros_like(output_dict[label] + ix)),
            f"{label} doesn't correspond to correct tensor!",
        )


@pytest.mark.parametrize(
    "abs_norm,min_val,scale",
    [
        (False, -1, 0),
        (False, -1, 1),
        (False, -1, -1),
        (False, -1, 100),
        (True, 0, 0),
        (True, 0, 1),
        (True, 0, -1),
        (True, 0, 100),
    ],
)
def test_get_normalized_jacobian(abs_norm: bool, min_val: int, scale: int):
    """Ensures that get_normalized_jacobian() returns a tensor between -1 or 0 and 1

    Parameters
    ----------
    abs_norm: bool
        False means normalize to [-1, 1] and True means [0, 1]
    min_val: int
        -1 if abs_norm is False, 0 if True
    scale: int
        What to multiply the input tensor by

    Returns
    -------
    None
    """
    normalized_tensor = get_normalized_jacobian(scale * torch.rand(10, 512), abs_norm)
    assert torch.min(normalized_tensor) >= min_val, (
        f"Min value {torch.min(normalized_tensor)}" + f" less than expected (f{min_val})"
    )
    assert torch.max(normalized_tensor) <= 1, (
        f"Max value {torch.max(normalized_tensor)}" + f" greater than expected (1)"
    )


class TestGetSortedJacobian:
    labels = np.asarray(["A", "B", "C", "D", "E"])
    orig_input = torch.stack([i * torch.ones(5) for i in range(5)])

    @pytest.mark.parametrize(
        "order", [[0, 1, 2, 3, 4], [1, 2, 3, 4, 0], [4, 1, 3, 2, 0],],
    )
    def test_sorting_dim_zero(self, order: List[int]):
        """Checks that we can properly sort along dimension 0

        Parameters
        ----------
        order: List[int]
            The order used to shuffle labels and orig_input

        Returns
        -------
        None
        """
        test_input = torch.clone(self.orig_input)[order, :]

        sorted_tensor, sorted_labels = get_sorted_jacobian(test_input, self.labels[order], 0)

        for ix, row in enumerate(sorted_tensor):
            assert torch.equal(row, (len(self.labels) - ix - 1) * torch.ones_like(row))
            assert self.labels[-ix - 1] == sorted_labels[ix]

    @pytest.mark.parametrize(
        "order", [[0, 1, 2, 3, 4], [1, 2, 3, 4, 0], [4, 1, 3, 2, 0],],
    )
    def test_sorting_dim_one(self, order: List[int]):
        """Checks that we can properly sort along dimension 1

        Parameters
        ----------
        order: List[int]
            The order used to shuffle labels and orig_input

        Returns
        -------
        None
        """
        test_input = torch.clone(self.orig_input)[order, :].permute(1, 0)

        sorted_tensor, sorted_labels = get_sorted_jacobian(test_input, self.labels[order], 1)

        for ix, row in enumerate(sorted_tensor.permute(1, 0)):
            assert torch.equal(row, (len(self.labels) - ix - 1) * torch.ones_like(row))
            assert self.labels[-ix - 1] == sorted_labels[ix]
