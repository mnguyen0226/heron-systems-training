import torch
from adept.network import ModularNetwork
from adept.preprocess import GPUPreprocessor
from adept.utils.util import DotDict

from gamebreaker.classifier.network import CUSTOM_REGISTRY
from gamebreaker.scripts.train_classifier import get_batch_results


def test_get_batch_results():
    # Need to build a network, args, units, and labels
    args = {
        "net2d": "Identity2D",
        "netbody": "Identity2D",
        "head1d": "Identity1D",
        "head2d": "Identity2D",
    }

    in_shape = (10, 15)
    batch_size = 16

    obs_space = {"units": in_shape}

    output_space = {"test1": (1,), "test2": (1,)}

    # ModularNetwork needs a GPUPreprocessor. Ignore this.
    gpu_preprocessor = GPUPreprocessor([], obs_space)

    # Create the ModularNetwork from our arguments
    network = ModularNetwork.from_args(
        DotDict(args), obs_space, output_space, gpu_preprocessor, CUSTOM_REGISTRY
    )
    network = network.train()

    input_tensor = torch.zeros((batch_size, in_shape[0], in_shape[1]))

    labels = torch.zeros(2, batch_size)

    loss_fcn = [torch.nn.MSELoss(), torch.nn.MSELoss()]

    accuracies, loss, predictions = get_batch_results(network, loss_fcn, input_tensor, labels,)

    for key in accuracies:
        assert 0 <= torch.max(accuracies[key]) <= 1
        assert type(accuracies[key]) is torch.Tensor

    for key in loss:
        assert type(loss[key]) is torch.Tensor

    for key in predictions:
        assert type(predictions[key]) is torch.Tensor
