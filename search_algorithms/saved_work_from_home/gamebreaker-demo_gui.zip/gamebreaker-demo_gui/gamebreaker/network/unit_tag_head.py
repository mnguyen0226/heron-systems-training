from adept.network import SubModule2D
from torch import nn
from torch.nn import functional as F


class UnitTagHead(SubModule2D):
    args = {}

    def __init__(self, input_shape, id, unit_max):
        """Creates a UnitTagHead

        Parameters
        ----------
        input_shape :
            shape of the input
        id : int
            identifier for the submodule
        unit_max : int
            maximum units to create
        """
        super().__init__(input_shape, id)
        self.unit_max = unit_max

        f, s = input_shape
        # f = 512, s = 1
        self.linear1 = nn.Linear(f, 1024, bias=False)
        self.linear2 = nn.Linear(1024, 1024, bias=False)

        self.norm1 = nn.BatchNorm1d(1024)
        self.norm2 = nn.BatchNorm1d(1024)

    @classmethod
    def from_args(cls, args, input_shape, id):
        """Class factory constructor

        Parameters
        ----------
        args : Dict
            arguments
        input_shape :
            shape of the input
        id : int
            identifier for the submodule

        Returns
        -------
        Object of class UnitTagHead

        Raises
        ------
        Exception
            if there was not a unit_max argument input
        """
        if not args.unit_max:
            raise Exception("This head requires an SC2 environment with unit_max argument")
        return cls(input_shape, id, args.unit_max)

    @property
    def _output_shape(self):
        """Returns the output shape of the module

        Returns
        -------
        Tuple[int, int]
            unit_max, 2
        """
        return (self.unit_max, 2)

    def _forward(self, input, internals, **kwargs):
        """Call forward on the network

        Parameters
        ----------
        input :
            input data
        internals : Dict
            internals of the network

        Returns
        -------
        Tuple[torch.Tensor, dict]
            The output of the netowrk and the internals
        """
        b, s, f = input.shape
        x = input.view(b, self.unit_max)
        x = F.relu(self.norm1(self.linear1(x)))
        x = F.relu(self.norm2(self.linear2(x)))
        x = x.view(b, self.unit_max, 2)
        return x, internals

    def _new_internals(self):
        """Returns the new internals

        Returns
        -------
        Dict
            empty dict
        """
        return {}
