# TODO: remove, there is nothing here
from adept.network import NetworkModule


class LinearLSTM(NetworkModule):
    args = {}

    def __init__(self):
        pass

    @classmethod
    def from_args(cls, args, observation_space, output_space, gpu_preprocessor, net_reg):
        pass

    def new_internals(self, device):
        pass

    def forward(self, observation, internals):
        pass
