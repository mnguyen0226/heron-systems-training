from abc import ABCMeta
from collections import OrderedDict
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple
from typing import Union

import torch
from adept.network import NetworkModule
from adept.preprocess import GPUPreprocessor
from adept.registry import Registry
from adept.utils.util import DotDict
from torch import nn
from torch.nn import functional as F

from gamebreaker.env.base.actions import RAW_FUNCTIONS
from gamebreaker.env.base.obs_idx import ObsIdx
from gamebreaker.env.base.obs_info import get_bit_length

# Batch dimension
b = 0

# Feature dimension
f = 1

# Sequence dimension
s = 2


class CollectMineralsNetwork(NetworkModule):
    args = {}

    NB_ACTIONS = len(RAW_FUNCTIONS)

    def __init__(
        self,
        in_shape: Tuple[int, int],
        conv_nb_hidden: Optional[int] = 32,
        nb_conv_layer: Optional[int] = 7,
        lstm_nb_hidden: Optional[int] = 512,
        kernel_size: Optional[int] = 3,
        stride: Optional[int] = 2,
        padding: Optional[int] = 1,
        x_max: Optional[int] = 64,
        y_max: Optional[int] = 64,
    ):
        """
        Custom network for playing Starcraft II

        Parameters
        ----------
        in_shape: Tuple[int, int]
            The input shape to the network, (Features, Sequence)
        conv_nb_hidden: Optional[int]
            How many channels to use in the conv layers
        nb_conv_layer: Optional[int]
            How many conv layers to use for the input
        lstm_nb_hidden: Optional[int]
            Number of hiddent units in the LSTM
        kernel_size: Optional[int]
            Kernel size of the conv layers
        stride: Optional[int]
            Stride of the conv layers
        padding: Optional[int]
            Padding for the conv layers
        x_max: Optional[int]
            Maximum x value of the map the agent is playing on
        y_max: Optional[int]
            Maximum y value of the map the agent is playing on
        """
        super().__init__()

        # Save the args
        self._feature_size, self._sequence_size = in_shape
        self._lstm_nb_hidden = lstm_nb_hidden

        # TODO: Still trying to figure out how to signal to the network that no, we are not in
        #  training. May have to not use Adept at eval.
        self._training = False

        # Create the input convolutional layers
        relu_gain = nn.init.calculate_gain("relu")
        convs = []
        for i in range(nb_conv_layer):
            conv_layer = nn.Conv1d(
                self._feature_size if i == 0 else conv_nb_hidden,
                conv_nb_hidden,
                kernel_size=(1,) if i == 0 else (kernel_size,),
                stride=(1,) if i == 0 else (stride,),
                padding=(0,) if i == 0 else (padding,),
                bias=False,
            )
            conv_layer.weight.data.mul_(relu_gain)
            convs.append((f"conv{i}", conv_layer))
            convs.append((f"norm{i}", nn.BatchNorm1d(conv_nb_hidden)))
            convs.append((f"relu{i}", nn.ReLU()))
        self.convs = nn.Sequential(OrderedDict(convs))

        # Calculate the output size of the convolutional layers
        conv_output_size = (
            conv_nb_hidden,
            self._sequence_size // (2 ** (nb_conv_layer - 1)),
        )

        # Use the above size to calculate the flattened input size of the LSTM
        self.lstm_input_size = conv_output_size[0] * conv_output_size[1]

        # The lstm body that handles time-sequence data
        self.body = nn.LSTMCell(self.lstm_input_size, lstm_nb_hidden)

        # How many bits we use to represent the alliance feature
        alliance_bit_length = get_bit_length(x_max, y_max)["alliance"]

        # The indices in the feature dimension of the features we'd like to grab from the input
        # alliance: What team the unit is on (player, neutral, enemy)
        # x/y: Scalar position of the unit
        # order_length: How many orders the unit currently has
        # Order_id_0: What the unit's current order is (we only let the agent assign one order)
        # Active: Does the unit currently have an order
        self.unit_info_indices = (
            list(range(ObsIdx.alliance_bit0, ObsIdx.alliance_bit0 + alliance_bit_length))
            + [ObsIdx.x, ObsIdx.y]
            + [ObsIdx.order_length]
            + list(range(ObsIdx.order_id_0_bit0, ObsIdx.order_id_0_bit9 + 1))
            + [ObsIdx.active]
        )

        # The critic output-head
        self.critic_output = nn.Sequential(
            OrderedDict(
                [
                    (
                        "critic_linear_0",
                        nn.Linear(
                            in_features=lstm_nb_hidden, out_features=lstm_nb_hidden // 2, bias=False
                        ),
                    ),
                    ("critic_norm_0", nn.BatchNorm1d(lstm_nb_hidden // 2)),
                    ("critic_relu_0", nn.ReLU()),
                    (
                        "critic_linear_1",
                        nn.Linear(
                            in_features=lstm_nb_hidden // 2,
                            out_features=lstm_nb_hidden // 4,
                            bias=False,
                        ),
                    ),
                    ("critic_norm_1", nn.BatchNorm1d(lstm_nb_hidden // 4)),
                    ("critic_relu_1", nn.ReLU()),
                    (
                        "critic",
                        nn.Linear(in_features=lstm_nb_hidden // 4, out_features=1, bias=True),
                    ),
                ]
            )
        )

        # The function id output head
        self.func_output = nn.Sequential(
            OrderedDict(
                [
                    (
                        "func_embed",
                        nn.Linear(
                            in_features=lstm_nb_hidden, out_features=lstm_nb_hidden // 2, bias=False
                        ),
                    ),
                    ("func_norm", nn.BatchNorm1d(lstm_nb_hidden // 2)),
                    ("func_relu", nn.ReLU()),
                    (
                        "func_out",
                        nn.Linear(
                            in_features=lstm_nb_hidden // 2,
                            out_features=self.NB_ACTIONS,
                            bias=True,
                        ),
                    ),
                ]
            )
        )

        # The selected units output head
        sel_units_output = []
        for i_sel in range(3):
            sel_embed = nn.Conv1d(
                in_channels=self.NB_ACTIONS + lstm_nb_hidden + len(self.unit_info_indices)
                if i_sel == 0
                else conv_nb_hidden,
                out_channels=conv_nb_hidden,
                kernel_size=(kernel_size,),
                stride=(1,),
                padding=(1,),
                bias=False,
            )

            sel_embed.weight.data.mul_(relu_gain)
            sel_units_output.append((f"sel_conv_{i_sel}", sel_embed))
            sel_units_output.append((f"sel_norm_{i_sel}", nn.BatchNorm1d(conv_nb_hidden)))
            sel_units_output.append((f"sel_relu_{i_sel}", nn.ReLU()))
        sel_units_output.append(
            (
                "sell_out",
                nn.Conv1d(
                    in_channels=conv_nb_hidden,
                    out_channels=1,
                    kernel_size=(1,),
                    stride=(1,),
                    bias=True,
                ),
            )
        )

        self.selected_units_output = nn.Sequential(OrderedDict(sel_units_output))

        # The target unit output head
        targ_embed = nn.Conv1d(
            in_channels=1 + lstm_nb_hidden + len(self.unit_info_indices),
            out_channels=conv_nb_hidden,
            kernel_size=(kernel_size,),
            stride=(stride,),
            padding=(padding,),
            bias=False,
        )
        targ_embed.weight.data.mul_(relu_gain)

        target_embedding = [
            ("targ_conv", targ_embed),
            ("targ_norm_0", nn.BatchNorm1d(conv_nb_hidden)),
            ("targ_relu_0", nn.ReLU()),
            ("targ_flatten", nn.Flatten()),
            (
                "targ_linear_1",
                nn.Linear(
                    conv_nb_hidden * self._sequence_size // 2, out_features=in_shape[-1], bias=False
                ),
            ),
            ("targ_norm_1", nn.BatchNorm1d(in_shape[-1])),
            ("targ_relu_1", nn.ReLU()),
        ]
        self.target_embedding = nn.Sequential(OrderedDict(target_embedding))

        self.targ_out = nn.Linear(in_features=in_shape[-1], out_features=in_shape[-1], bias=True,)

        # The x/y position output heads
        self.x_out = nn.Linear(in_features=in_shape[-1], out_features=x_max, bias=True)
        self.y_out = nn.Linear(in_features=in_shape[-1], out_features=y_max, bias=True)

    @classmethod
    def from_args(
        cls: ABCMeta,
        args: DotDict,
        observation_space: Dict[str, Tuple[int, int]],
        output_space: Dict[str, Any],
        gpu_preprocessor: GPUPreprocessor,
        net_reg: Registry,
    ) -> "CollectMineralsNetwork":
        """
        Builds the network from an args DotDict

        Parameters
        ----------
        args: DotDict
            Contains arguments to build the model. Needs to contain in_shape, x_max, and y_max
        observation_space: Dict[str, Tuple[int, int]]
            Unused
        output_space: Dict[str, Any]
            Unused
        gpu_preprocessor: GPUPreprocessor
            Unused
        net_reg: Registry
            Unused

        Returns
        -------
        CollectMineralsNetwork
        """
        return cls(in_shape=args.in_shape, x_max=args.x_max, y_max=args.y_max,)

    def new_internals(self, device: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Generates new internals for the LSTM

        Parameters
        ----------
        device: torch.Tensor
            The device to move the internals to

        Returns
        -------
        Dict[str, torch.Tensor]
        """
        return {
            "hx": torch.zeros(self._lstm_nb_hidden).to(device),
            "cx": torch.zeros(self._lstm_nb_hidden).to(device),
        }

    def forward(
        self,
        observation: Dict[str, Union[torch.Tensor, Any]],
        internals: Dict[str, List[torch.Tensor]],
    ) -> Tuple[Dict[str, torch.Tensor], Dict[str, List[torch.Tensor]], Dict[str, torch.Tensor]]:
        """Forward function of the network

        Parameters
        ----------
        observation: Dict[str, torch.Tensor]
            The state returned from PySC2 and fully preprocessed
        internals: Dict[str, torch.Tensor]
            The previous internals used for the LSTM

        Returns
        -------
        Tuple[Dict[str, torch.Tensor], Dict[str, List[torch.Tensor]], Dict[str, torch.Tensor]
            Tuple containing the output decisions of the model, the internals, and the original
            observation, respectively
        """
        # Clone the input observation
        xs = torch.clone(observation["proc_units"])

        # Grab the unit tags, as these get passed through the skip connections
        # TODO: Experiment with other features that can skip to output (health, x, y, etc)
        unit_tags = torch.clone(xs[:, self.unit_info_indices, :])

        # Pass input through the convs to reduce the size
        xs = self.convs(xs)

        # Flatten the output of the convolutional network so that we can pass it into the LSTM
        xs = torch.reshape(xs, (-1, self.lstm_input_size))

        # Pass the output of the conv1d's into the LSTM to get the next hidden and cell state
        next_hx, next_cx = self.body(
            xs, (torch.stack(internals["hx"]), torch.stack(internals["cx"]))
        )

        # Now we begin generating the outputs
        outputs = {}

        # Get the output for the critic
        outputs["critic"] = self.critic_output(next_hx)

        # Pass the output of the LSTM through some processing layers
        func_id = self.func_output(next_hx)

        outputs["func_id"] = torch.clone(func_id)

        # because of starcraft II wonkiness, we need to do the sampling of actions inside
        # the network, rather than outside of it.
        func_id_chosen = self.get_action_choice(func_id,)
        outputs["func_id_chosen"] = func_id_chosen

        # Concatenate the chosen function, the lstm output, and the unit_tags
        selected_units_input = torch.cat(
            (
                torch.unsqueeze(func_id_chosen, s).expand(
                    -1, self.NB_ACTIONS, self._sequence_size,
                ),
                torch.unsqueeze(next_hx, s).expand(-1, self._lstm_nb_hidden, self._sequence_size),
                unit_tags,
            ),
            dim=f,
        )

        # Generate the probability distribution of selecting each unit individually
        selected_units = self.selected_units_output(selected_units_input)

        # Store the distribution as the output
        outputs["selected_units"] = torch.clone(selected_units).squeeze(f)

        # Make a hard decision of which units are getting selected
        selected_units_chosen = self.get_selected_units(selected_units, observation["proc_units"])

        # Store the actually selected units in the output
        outputs["selected_units_chosen"] = selected_units_chosen.squeeze(f)

        # Combine the actually selected units with the lstm output and the skip connection
        target_unit_input = torch.cat(
            (
                selected_units_chosen,
                torch.unsqueeze(next_hx, s).expand(-1, self._lstm_nb_hidden, self._sequence_size),
                unit_tags,
            ),
            dim=f,
        )

        # Process the above tensor
        target_info = self.target_embedding(target_unit_input).view(
            observation["proc_units"].shape[0], -1
        )

        # Get a probability distribution over which units are the target
        outputs["target_unit"] = self.targ_out(target_info).squeeze(f)

        # In Starcraft II, we can only select one target at a time, so its a simple selection
        outputs["target_unit_chosen"] = self.get_target_unit(
            outputs["target_unit"], observation["proc_units"]
        )

        # Determine the x and y location
        x = self.x_out(target_info)
        y = self.y_out(target_info)

        outputs["x"] = torch.clone(x)

        x_chosen = self.get_action_choice(x)
        outputs["x_chosen"] = x_chosen

        outputs["y"] = torch.clone(y)

        y_chosen = self.get_action_choice(y)
        outputs["y_chosen"] = y_chosen

        return outputs, {"hx": list(next_hx), "cx": list(next_cx)}, observation["proc_units"]

    def get_action_choice(self, distribution: torch.Tensor) -> torch.Tensor:
        """Takes in a distribution and selects an action from it

        Parameters
        ----------
        distribution: torch.Tensor
            The output from a network's output head that determines which action we want to take

        Returns
        -------
        torch.Tensor
            A one-hot encoding for the action we're selecting
        """
        # Generate the output tensor
        output = torch.zeros_like(distribution)

        # Normalize the distribution to be a probability distribution
        soft_distribution = F.softmax(distribution, -1)
        if self._training:
            # Sample from the distribution, using the distribution
            indices = soft_distribution.multinomial(1).squeeze()
        else:
            # Just select the best action
            indices = torch.argmax(soft_distribution, dim=-1)

        # Turn the output into a one-hot
        output[range(0, output.shape[0]), indices] += 1

        # Detach so that gradients don't get weird
        return output.detach()

    def get_target_unit(self, distribution: torch.Tensor, obs: torch.Tensor) -> torch.Tensor:
        """Determines which unit the action will target

        Parameters
        ----------
        distribution: torch.Tensor
            The output of the model's target unit layer
        obs: torch.Tensor
            The input observation, used to mask the units

        Returns
        -------
        torch.Tensor
            One-hot encoding of the targetted unit
        """
        # Determine how many units aren't just zeros
        nonzero_units = torch.sum(obs, dim=1)

        # Create a mask that prevents us from choosing a unit that does not exist.
        target_unit_mask = nonzero_units != torch.zeros_like(nonzero_units)

        # Mask out the parts of the distribution that don't correspond to actual units
        masked_distribution = torch.where(
            target_unit_mask, distribution, torch.zeros_like(distribution) + -(10 ** 10)
        )

        # Normalize the masked distribution to be a probability distribution
        softmax = F.softmax(masked_distribution, dim=-1)

        # Either sample for the unit we want or take the highest weighted option
        if self._training:
            action = softmax.multinomial(1).squeeze(1)
        else:
            action = torch.argmax(softmax, dim=-1)

        # One hot encode
        output = torch.zeros_like(distribution)
        output[range(0, output.shape[0]), action] += 1

        # Detach so gradients don't get weird
        return output.detach()

    def get_selected_units(self, distribution: torch.Tensor, obs: torch.Tensor) -> torch.Tensor:
        """Function used to determine which units the network is choosing to complete the chosen
        action

        Parameters
        ----------
        distribution: torch.Tensor
            Tensor containing the probabilities of selecting each unit (binary decision).
        obs: torch.Tensor
            The original input, used to determine which units are valid to select

        Returns
        -------
        torch.Tensor
            A many-hot encoding of which units are being selected
        """
        # Get a mask of all the units that belong to the player (Alliance bits 001)
        unit_mask = torch.prod(
            obs[:, ObsIdx.alliance_bit0 : ObsIdx.alliance_bit2 + 1, :].permute(0, 2, 1)
            == torch.cat(
                (
                    torch.zeros(obs.shape[0], obs.shape[-1], 1),
                    torch.zeros(obs.shape[0], obs.shape[-1], 1),
                    torch.ones(obs.shape[0], obs.shape[-1], 1),
                ),
                dim=-1,
            ).to(obs.device),
            dim=-1,
        )

        # In Starcraft II, we can select multiple units at once to perform an action, so long as
        # those units belong to us. Therefore, the probability distribution we receive from the
        # model is actually 512 (or however many units we have) probability distributions. Typically
        # we would treat anything over 0.5 as "selected". To turn the model's output into a
        # probability distribution, we take 1-sigmoid(distribution) for "not selected" and
        # sigmoid(distribution) for "selected".
        selected_units_softmax = (
            torch.stack([1 - torch.sigmoid(distribution), torch.sigmoid(distribution)])
            .squeeze(-2)
            .permute(1, 2, 0)
        )

        # If we're training, sample each unit that belongs to us if we'd like to use it. Otherwise,
        # take the argmax (returns 0 if we don't want to select, 1 if we do) of each unit
        if self._training:
            selected_units_action = (
                selected_units_softmax.view(-1, 2).multinomial(1).view(*distribution.shape)
            )
        else:
            selected_units_action = torch.argmax(selected_units_softmax.view(-1, 2), dim=-1).view(
                *distribution.shape
            )

        # Take the units we'd like to select out of the unit mask
        selected_units_action *= unit_mask.view(*selected_units_action.shape)

        # Detach so gradients don't get messed up
        return selected_units_action.detach()

    def to(self, device: torch.Tensor) -> "CollectMineralsNetwork":
        """Used to move the model to the GPU

        Parameters
        ----------
        device: torch.Tensor
            Which GPU we're moving to

        Returns
        -------
        CollectMineralsNetwork
        """
        super().to(device)
        self.body = self.body.to(device)
        return self
