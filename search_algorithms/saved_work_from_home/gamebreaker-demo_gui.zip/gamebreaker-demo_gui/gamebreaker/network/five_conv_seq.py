from adept.modules import Identity
from adept.network import SubModule2D
from torch import nn
from torch.nn import functional as F


class FiveConvSeq(SubModule2D):
    args = {
        "normalize": "bn",
        "nb_hidden": 512,
    }

    def __init__(self, input_shape, id, normalize, nb_hidden):
        """Creates a Five Convolutional Layer Sequence

        Parameters
        ----------
        input_shape :
            Shape of the input
        id : int
            id for the module
        normalize : string
            whether or not to perform batch norm
        nb_hidden : int
            size of the hidden dimension
        """
        super().__init__(input_shape, id)
        self._nb_hidden = nb_hidden

        f, s = input_shape
        h = nb_hidden
        is_bias = normalize != "bn"
        # Sequence Length = S = 512
        self.conv1 = nn.Conv1d(f, h, kernel_size=3, stride=2, padding=1, bias=is_bias)
        # S = 256
        self.conv2 = nn.Conv1d(h, h, kernel_size=3, stride=2, padding=1, bias=is_bias)
        # S = 128
        self.conv3 = nn.Conv1d(h, h, kernel_size=3, stride=2, padding=1, bias=is_bias)
        # S = 64
        self.conv4 = nn.Conv1d(h, h, kernel_size=3, stride=2, padding=1, bias=is_bias)
        # S = 32
        self.conv5 = nn.Conv1d(h, h, kernel_size=3, stride=2, padding=1, bias=is_bias)
        # S = 16

        if normalize:
            self.norm1 = nn.BatchNorm1d(h)
            self.norm2 = nn.BatchNorm1d(h)
            self.norm3 = nn.BatchNorm1d(h)
            self.norm4 = nn.BatchNorm1d(h)
            self.norm5 = nn.BatchNorm1d(h)
        else:
            self.norm1 = Identity()
            self.norm2 = Identity()
            self.norm3 = Identity()
            self.norm4 = Identity()
            self.norm5 = Identity()

    @classmethod
    def from_args(cls, args, input_shape, id):
        """Class factory constructor

        Parameters
        ----------
        args : Dict
            Arguments
        input_shape :
            input shape
        id : int
            id for the module

        Returns
        -------
        Object of type FiveConvSeq
        """
        return cls(input_shape, id, args.normalize, args.nb_hidden)

    @property
    def _output_shape(self):
        """Returns the output shape dimension

        Returns
        -------
        Tuple[int, int]
            nb_hidden, by output sequence length
        """
        f, s = self.input_shape

        output_seq_len = s
        for i in range(5):
            output_seq_len //= 2

        return self._nb_hidden, output_seq_len

    def _forward(self, xs, internals, **kwargs):
        """Call forward on the network

        Parameters
        ----------
        xs :
            input
        internals :
            dict of internals

        Returns
        -------
        Tuple[torch.Tensor, dict]
            the output of the network, and the internals
        """
        xs = F.relu(self.norm1(self.conv1(xs)))
        xs = F.relu(self.norm2(self.conv2(xs)))
        xs = F.relu(self.norm3(self.conv3(xs)))
        xs = F.relu(self.norm4(self.conv4(xs)))
        xs = F.relu(self.norm5(self.conv5(xs)))
        return xs, {}

    def _new_internals(self):
        """Return empty internals

        Returns
        -------
        Dict
            empty dict
        """
        return {}
