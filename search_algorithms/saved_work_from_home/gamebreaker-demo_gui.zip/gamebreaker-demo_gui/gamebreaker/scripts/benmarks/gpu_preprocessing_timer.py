import time

import numpy as np
import torch
from adept.preprocess.observation import ObsPreprocessor
from adept.preprocess.ops import CastToDouble
from adept.preprocess.ops import CastToFloat
from adept.preprocess.ops import FromNumpy
from pysc2.lib.features import FeatureUnit

from gamebreaker.classifier.utils.common_utils import normalize_size
from gamebreaker.env.base.ops import CreateEmptyArray
from gamebreaker.env.base.ops import FilterForNet
from gamebreaker.env.base.ops import PermuteToFS
from gamebreaker.env.base.ops import ProcessCategoricalFeatures
from gamebreaker.env.base.ops import ProcessScalarFeatures

PATH = "/media/banshee/gb_winprob/Data/balanced_races/Training/0/00001_1.npy"

dev = "cuda:0" if torch.cuda.is_available() else "cpu"
print(dev)
device = torch.device(dev)

data = normalize_size(np.load(PATH, allow_pickle=True))
all_obs = [{"raw_units": v} for v in data]

unit_max = 512
observation_space = {"raw_units": (None, len(FeatureUnit))}
observation_dtypes = {"raw_units": np.int64}
categorical_processor = ProcessCategoricalFeatures(32, 32)
scalar_processor = ProcessScalarFeatures(32, 32, device)
cpu_preprocessor = ObsPreprocessor(
    [FromNumpy(), CreateEmptyArray(unit_max), categorical_processor, FilterForNet(),],
    observation_space,
    observation_dtypes,
)
gpu_preprocessor = ObsPreprocessor(
    [scalar_processor, CastToFloat(), PermuteToFS(),],
    cpu_preprocessor.observation_space,
    cpu_preprocessor.observation_dtypes,
)

proc_obs = []
for obs in all_obs:
    processed_obs = cpu_preprocessor(obs)
    processed_obs["proc_units"] = processed_obs["proc_units"].repeat(64, 1).reshape(64, 512, 129)
    proc_obs.append(processed_obs)

num_iters = 100

times = np.zeros(num_iters)
for i in range(num_iters):
    start = time.perf_counter()
    for obs in proc_obs:
        obs["proc_units"] = obs["proc_units"].to(device)
        processed_obs = gpu_preprocessor(obs)
    times[i] = time.perf_counter() - start

print("Mean time:", np.mean(times))
print("Standard deviation:", np.std(times))
