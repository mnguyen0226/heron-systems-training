# Copyright (C) 2020 Heron Systems, Inc.
import importlib
import os
import shutil
from pathlib import Path

import numpy as np
import torch
from absl import flags
from adept.preprocess import CPUPreprocessor
from adept.preprocess import GPUPreprocessor
from adept.preprocess.ops import CastToFloat
from adept.preprocess.ops import FromNumpy
from adept.utils.util import DotDict
from pysc2 import maps
from pysc2.env import sc2_env
from pysc2.lib import units
from pysc2.lib.features import FeatureUnit

from gamebreaker import unit_data
from gamebreaker.classifier.utils.common_utils import RACE_MAP
from gamebreaker.classifier.utils.dataset_utils import GameRecorder
from gamebreaker.env.action_postprocessor import ActionPostprocessor
from gamebreaker.env.base.ops import CopyOverScalarFeatures
from gamebreaker.env.base.ops import CreateEmptyArray
from gamebreaker.env.base.ops import FilterForNet
from gamebreaker.env.base.ops import PermuteToFS
from gamebreaker.env.base.ops import ProcessCategoricalFeatures
from gamebreaker.env.base.ops import ProcessScalarFeatures
from gamebreaker.env.winprob_env import WinProbEnv
from gamebreaker.selector import ChainSelector
from gamebreaker.selector import MultichokeSelector
from gamebreaker.selector import MultiSelector
from gamebreaker.selector import RandomUpgradeSelector
from gamebreaker.selector import SprinkleBlockSelector
from gamebreaker.selector import SprinkleCreepSelector
from gamebreaker.selector.army_selector import GeneralUniformArmySelector

TEAM = ["Red", "Blue"]
FLAGS = flags.FLAGS
FLAGS([""])
WORLD_SIZE = (64, 64)

MAP = "Flat64-Gamebreaker-NoFog"
# Install Flat32-Gamebreaker
install_path = os.path.join(Path.home(), "StarCraftII", "Maps", "Melee", MAP)

globals()["Flat64-Gamebreaker-NoFog"] = type(
    "Flat64-Gamebreaker-NoFog", (maps.melee.Melee,), dict(filename="Flat64-Gamebreaker-NoFog"),
)

if not os.path.exists(install_path):
    source_path = os.path.join("..", "..", "resources", "Flat64-Gamebreaker-NoFog.SC2Map")
    assert os.path.exists(source_path)

    shutil.copyfile(source_path, install_path)

observation_space = {"raw_units": (None, len(FeatureUnit))}
observation_dtypes = {"raw_units": np.int64}

UNIT_MAX = 512

cpu_preprocessor = CPUPreprocessor(
    [
        FromNumpy("raw_units", "raw_units"),
        CreateEmptyArray(UNIT_MAX, "raw_units", "proc_units", creep=True),
        ProcessCategoricalFeatures(
            WORLD_SIZE[0], WORLD_SIZE[1], ["raw_units", "proc_units"], ["proc_units"],
        ),
        CopyOverScalarFeatures(["raw_units", "proc_units"], ["proc_units"], creep=True),
        FilterForNet("raw_units", "raw_units"),
    ],
    observation_space,
    observation_dtypes,
)
gpu_preprocessor = GPUPreprocessor(
    [
        ProcessScalarFeatures(WORLD_SIZE[0], WORLD_SIZE[1], "proc_units", "proc_units", creep=True),
        CastToFloat("proc_units", "proc_units"),
        PermuteToFS("proc_units", "proc_units"),
    ],
    cpu_preprocessor.observation_space,
    cpu_preprocessor.observation_dtypes,
)


def run_loop(
    agents, env, recorder, max_episodes=0, max_frames=0,
):
    """A run loop to have agents and an environment interact

    Parameters
    ----------
    agents : List
        List of agents in the interaction
    env : MicroBattleEnv
        pysc2 env to run
    network : ModularNetwork
        Win prob classifier network to graph results of
    max_episodes : int, optional
        maximum number of episodes to run, by default 0
    max_frames : int, optional
        maximum number of frames to run, by default 0
    """
    total_frames = 0
    total_episodes = 0
    action_postprocessor = ActionPostprocessor(env)
    observation_spec = env.observation_spec()
    action_spec = env.action_spec()
    for agent, obs_spec, act_spec in zip(agents, observation_spec, action_spec):
        agent.setup(obs_spec, act_spec)

    try:
        while not max_episodes or total_episodes < max_episodes:
            total_episodes += 1
            timesteps = env.reset()

            for a in agents:
                a.reset()

            is_done = False
            unit_data = []
            upgrades = [timesteps[0].observation.upgrades, timesteps[1].observation.upgrades]
            while not is_done:
                unit_data.append(timesteps[0].observation.raw_units)
                total_frames += 1
                print(env.predictions)

                actions = [agent.step(timestep) for agent, timestep in zip(agents, timesteps)]
                actions = action_postprocessor.postprocess(actions)
                if max_frames and total_frames >= max_frames:
                    return
                if timesteps[0].last():
                    break

                timesteps, _, is_done, info = env.step(actions)

            ep_num = recorder.save_episode(info["result"], unit_data, upgrades)
            if info["result"] == 0:
                print(f"{ep_num}: Red won!")
            elif info["result"] == 1:
                print(f"{ep_num}: Blue won!")
            else:
                print(f"{ep_num}: Tie!")

    except KeyboardInterrupt:
        pass


def get_army_selectors(races, minerals, gases, x_positions, y_positions, seed=0):
    """Creates the army selectors

    This method creates a list of GeneralUniformArmySelectors that take in the given parameters and
    generate random uniformly selected armies

    Parameters
    ----------
    races : List
        The list of races
    minerals : List
        The list of maximum mineral costs
    gases : List
        The list of maximum gas costs
    x_positions : List
        The list of valid x spawn positions
    y_positions : List
        The list of valid y spawn positions
    seed : int, optional
        The seed for random number generation, by default 0

    Returns
    -------
    selectors : List[GeneralUniformArmySelector, GeneralUniformArmySelector]
        The army selectors to use
    """
    selectors = []
    for race, mineral, gas, x, y in zip(races, minerals, gases, x_positions, y_positions):
        selectors.append(
            GeneralUniformArmySelector(
                unit_data.available_units(race),
                minerals=mineral,
                gas=gas,
                x_area=tuple(x),
                y_area=tuple(y),
                seed=0,
            )
        )
    return selectors


def main():
    """Runs the pysc2 environment with the win probability renderer

    Raises
    ------
    RuntimeError
        Incorrect races for the players
    """
    from gamebreaker.config import CFG

    # Build the network
    args = {"logdir": CFG.logdir, "tag": CFG.tag, "gpu_id": CFG.gpu_id}

    args = DotDict(args)

    # Grab the agents
    agent_classes = []
    players = []

    # TODO: Ensure desired agent is the AGENT_LIST
    desired_agents = CFG.agents
    desired_races = CFG.races

    # we need the sc2_env.Race for players and the unit list for everything else
    players_races = []
    unit_races = []
    for desired_race in desired_races:
        if desired_race.lower() == "terran":
            players_races.append(sc2_env.Race.terran)
            unit_races.append(units.Terran)
        elif desired_race.lower() == "protoss":
            players_races.append(sc2_env.Race.protoss)
            unit_races.append(units.Protoss)
        elif desired_race.lower() == "zerg":
            players_races.append(sc2_env.Race.zerg)
            unit_races.append(units.Zerg)
        else:
            raise RuntimeError(f"Race must be either terran, protoss, or zerg (got {desired_race})")

    classifier_races = torch.tensor(
        [RACE_MAP[desired_race.lower()] for desired_race in desired_races]
    )

    for player_race, desired_agent in zip(players_races, desired_agents):
        agent_module, agent_name = desired_agent.rsplit(".", 1)
        agent_cls = getattr(importlib.import_module(agent_module), agent_name)
        agent_classes.append(agent_cls)
        players.append(sc2_env.Agent(player_race, agent_name))

    agent_info = [(desired_agents[0].rsplit(".")[-1], desired_agents[1].rsplit(".")[-1])]

    x_spawns = [CFG.blue_x_spawns, CFG.red_x_spawns]
    y_spawns = [CFG.blue_y_spawns, CFG.red_y_spawns]

    selectors = get_army_selectors(unit_races, CFG.minerals, CFG.gas, x_spawns, y_spawns,)

    upgrade_selectors = [RandomUpgradeSelector(race=unit_race) for unit_race in unit_races]

    terrain_selector = ChainSelector(
        [
            MultiSelector(
                [
                    MultichokeSelector(
                        (0, 0),
                        WORLD_SIZE,
                        orientations=["right", "up"],
                        n_multichokes=list(range(0, 8)),
                        thickness=list(range(1, 3)),
                    ),
                    SprinkleBlockSelector((0, 0), WORLD_SIZE, n_blockers=list(range(112))),
                    MultichokeSelector(
                        (0, 0),
                        WORLD_SIZE,
                        orientations=["right", "up"],
                        n_multichokes=list(range(0, 1)),
                        thickness=list(range(1, 3)),
                    ),
                ],
                [0.7, 0.1, 0.2],
            ),
            MultiSelector(
                [SprinkleCreepSelector((0, 0), WORLD_SIZE, n_tumors=list(range(15))),], [1.0],
            ),
        ]
    )

    """Run one thread worth of the environment with agents."""
    with WinProbEnv(
        WORLD_SIZE,
        selectors,
        map_name=MAP,
        players=players,
        agent_interface_format=sc2_env.AgentInterfaceFormat(
            feature_dimensions=sc2_env.Dimensions(screen=84, minimap=84,),
            action_space=sc2_env.ActionSpace.RAW,
            use_raw_units=True,
            raw_crop_to_playable_area=True,
        ),
        # terrain_selector=terrain_selector,
        step_mul=8,
        game_steps_per_episode=800000,
        disable_fog=True,
        visualize=True,
        upgrade_selectors=upgrade_selectors,
        agent_info=agent_info,
        race_info=classifier_races,
        network_args=args,
        save_replay_info={"replay_dir": "StimReplays", "replay_prefix": "no_stim"},
    ) as env:
        recorder = GameRecorder(CFG.save_path, "Recording", unit_races, agent_info)
        agents = [agent_cls() for agent_cls in agent_classes]

        run_loop(
            agents, env, recorder, max_episodes=CFG.max_episodes,
        )


if __name__ == "__main__":
    main()
