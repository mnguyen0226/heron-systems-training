import csv
import os
import sys
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple
from typing import Union

import torch
import torch.nn as nn
from adept.network import ModularNetwork
from adept.utils.util import DotDict

from gamebreaker.classifier.utils.common_utils import get_network
from gamebreaker.classifier.utils.common_utils import get_old_args
from gamebreaker.classifier.utils.common_utils import get_path_from_args
from gamebreaker.classifier.utils.training_utils import GBDataset


def print_bar(ratio: float, max_length: Optional[int] = 30):
    """Prints a progress bar

    Parameters
    ----------
    ratio: float
        How much of the progress bar should be filled
    max_length: int
        Maximum number of characters to use for the progress bar

    Returns
    -------
    None
    """
    bar_length = min((max_length, round(max_length * ratio) + 1)) - 1
    if bar_length == (max_length - 1):
        pointer_char = "="
    else:
        pointer_char = ">"
    progress_bar = (
        "[" + "=" * bar_length + pointer_char + " " * (max_length - max((bar_length, 1)) - 1) + "]"
    )

    sys.stdout.write(f"\r{progress_bar}")
    sys.stdout.flush()


def print_results(acc: Dict[str, float], loss: Dict[str, float]):
    """Prints a table containing the acc and loss values

    Parameters
    ----------
    acc: Dict[str, float]
        Accuracies of the model separated by key
    loss: Dict[str, float]
        Losses of the model separated by key

    Returns
    -------
    None
    """
    top_bar = "+" + "-" * 6 + "+"
    title_bar = "|" + " " * 6 + "|"
    acc_bar = "|" + "acc".center(6) + "|"
    loss_bar = "|" + "loss".center(6) + "|"

    max_key_len = max([len(key) for key in acc]) + 2
    for key in acc:
        top_bar += "-" * max_key_len + "+"
        title_bar += key.center(max_key_len) + "|"
        acc_bar += f"{acc[key]: 0.3f}".center(max_key_len) + "|"
        loss_bar += f"{loss[key]: 0.3f}".center(max_key_len) + "|"

    print(top_bar)
    print(title_bar)
    print(top_bar)
    print(acc_bar)
    print(loss_bar)
    print(top_bar)


def save_results(
    model_path: str,
    dataset_name: str,
    acc: Dict[str, Union[str, float]],
    loss: Dict[str, Union[str, float]],
):
    """Saves the accuracy and loss to a CSV file in the model's directory

    Parameters
    ----------
    model_path: str
        Path to the model
    dataset_name: str
        Path to the dataset
    acc: Dict[str, Union[str, float]]
        Accuracies of the model
    loss: Dict[str, Union[str, float]]
        Losses of the model

    Returns
    -------
    None
    """
    if not os.path.isdir(os.path.join(model_path, "test_results")):
        os.mkdir(os.path.join(model_path, "test_results"))
    filename = os.path.join(model_path, "test_results", f"{dataset_name.rsplit('/')[-1]}.csv")
    print(f"Saving to {filename}")
    with open(filename, "w") as fp:
        writer = csv.DictWriter(fp, fieldnames=["mode"] + [key for key in acc])
        writer.writeheader()
        acc["mode"] = "accuracy"
        writer.writerow(acc)
        loss["mode"] = "loss"
        writer.writerow(loss)


def evaluate_over_dataset(
    network: ModularNetwork,
    dataset: GBDataset,
    output_labels: List[str],
    loss: List[Union[nn.BCELoss, nn.MSELoss]],
    max_length: Optional[int] = 30,
) -> Tuple[Dict[str, float], Dict[str, float]]:
    """Evaluate the model on a given dataset

    Parameters
    ----------
    network: ModularNetwork
        The network used for predictions
    dataset: GBDataset
        The dataset to evaluate against
    output_labels: List[str]
        The names of the things we're predicting against
    loss: List[Union[nn.BCELoss, nn.MSELoss]]
        List of loss functions used against the classifier
    max_length: int
        Maximum length of the progress bar

    Returns
    -------
    Tuple[Dict[str, float], Dict[str, float]]
        The accuracy and loss on this dataset
    """
    avg_acc = {key: {"numer": 0, "denom": 0} for key in output_labels}
    avg_loss = {key: {"numer": 0, "denom": 0} for key in output_labels}

    for nb_batches, (units, _, labels) in enumerate(dataset):
        temp = network.forward({"units": units}, {})

        predictions = {}
        for key in temp[0]:
            pred = temp[0][key].squeeze(-1)
            pred = torch.sigmoid(pred)
            pred = pred.double()
            predictions[key] = pred

        for ix, (label, key) in enumerate(zip(labels, predictions)):
            avg_acc[key]["numer"] += torch.sum(1 - torch.abs(predictions[key] - label)).item()
            avg_acc[key]["denom"] += units.shape[0]

            avg_loss[key]["numer"] += loss[ix](predictions[key], label).item()
            avg_loss[key]["denom"] += units.shape[0]

        print_bar(nb_batches / len(dataset), max_length=max_length)
    print_bar(1, max_length=max_length)
    print("")
    avg_acc = {key: avg_acc[key]["numer"] / avg_acc[key]["denom"] for key in avg_acc}
    avg_loss = {key: avg_loss[key]["numer"] / avg_loss[key]["denom"] for key in avg_loss}

    return avg_acc, avg_loss


def parse_args() -> Tuple[DotDict, List[str]]:
    """Function for parsing omegaconf arguments

    Returns
    -------
    Tuple[DotDict, List[str]]
        The arguments for the model and a list of paths to the datasets
    """
    from gamebreaker.config import CFG

    args = {
        "logdir": CFG.logdir,
        "tag": CFG.tag,
        "gpu_id": CFG.gpu_id,
        "ram_size": CFG.ram_size,
        "batch_size": CFG.batch_size,
    }

    datasets = CFG.datasets

    return DotDict(args), datasets


@torch.no_grad()
def main(args: DotDict, datasets: List[str]):
    """Main function for evaluating against a dataset

    Parameters
    ----------
    args: DotDict
        Arguments used to build the model
    datasets: List[str]
        List of paths to datasets

    Returns
    -------
    None
    """
    model_path = get_path_from_args(args)

    args = get_old_args(args, model_path)

    network = get_network(args, model_path)
    network.eval()

    for ix, loss_function in enumerate(args.loss):
        if loss_function == "bce":
            args.loss[ix] = torch.nn.BCELoss()
        elif loss_function == "mse":
            args.loss[ix] = torch.nn.MSELoss()

    for datapath in datasets:
        print(datapath)
        dataset = GBDataset(
            datapath,
            args.batch_size,
            gpu_id=args.gpu_id,
            indices=args.feature_indices,
            ram_size=args.ram_size,
        )

        avg_acc, avg_loss = evaluate_over_dataset(network, dataset, args.output_labels, args.loss)
        print_results(avg_acc, avg_loss)
        save_results(model_path, datapath, avg_acc, avg_loss)


if __name__ == "__main__":
    main(*parse_args())
