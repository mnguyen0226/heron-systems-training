import os

import numpy as np
import torch
from adept.utils.util import DotDict

from gamebreaker.classifier.utils.common_utils import get_network
from gamebreaker.classifier.utils.common_utils import get_old_args
from gamebreaker.classifier.utils.common_utils import get_path_from_args
from gamebreaker.classifier.utils.dataset_utils import read_episode

if __name__ == "__main__":
    # These are the bare minimum arguments needed to be passed into to load up a previous
    # model.
    # - logdir: specifies the path to the model's directory
    # - tag: the name of the model (and the model's directory) to use
    # - gpu_id: which GPU you'd like to run the model on (CPU usage is untested)
    args = {
        "logdir": "/media/banshee/gb_winprob/refactored_models",
        "tag": "agents_and_upgrades_noisy",
        "gpu_id": 0,
    }

    args = DotDict(args)

    # Get the path to the save directory
    model_path = get_path_from_args(args)

    # Retrieve the previous model's arguments
    args = get_old_args(args, model_path)

    # Build the network
    network = get_network(args, model_path)
    network.eval()
    path = "/media/banshee/gb_winprob/Data/proc_dataset_v3/Testing/0"

    with torch.no_grad():
        test_games = os.listdir(path)
        filename = os.path.join(path, test_games[0])

        units, upgrades, labels = read_episode(filename)

        units = units.float().to(args.gpu_id)
        upgrades = upgrades.float().to(args.gpu_id)

        single_pred = network.forward({"units": units[0:1], "upgrades": upgrades[0:1]}, {})
        print("Single Step:")
        for key in single_pred[0]:
            pred = single_pred[0][key].squeeze(-1)
            pred = torch.sigmoid(pred)
            print(f"\t{key}: {float(pred): 0.3f}")

        # Predict over the entire game
        game_pred = network.forward({"units": units, "upgrades": upgrades}, {})
        print("Full Game:")
        for key in game_pred[0]:
            pred = game_pred[0][key].squeeze(-1)
            pred = torch.sigmoid(pred)
            print(f"\t{key}: {pred.cpu().numpy().flatten()}")
