from typing import Dict
from typing import List
from typing import Tuple

import numpy as np
import plotly.graph_objects as go
import torch
from adept.preprocess import CPUPreprocessor
from adept.preprocess import GPUPreprocessor
from adept.preprocess.ops import CastToFloat
from adept.utils.util import DotDict
from pysc2.lib import units
from pysc2.lib.features import FeatureUnit
from pysc2.lib.features import PlayerRelative
from pysc2.lib.upgrades import Upgrades
from torch.autograd.functional import jacobian

from gamebreaker.classifier.utils.common_utils import create_upgrades_vec
from gamebreaker.classifier.utils.common_utils import get_network
from gamebreaker.classifier.utils.common_utils import get_old_args
from gamebreaker.classifier.utils.common_utils import get_path_from_args
from gamebreaker.classifier.utils.dataset_utils import convert_raw_to_stats
from gamebreaker.data.unit_stats import MAX_STATS
from gamebreaker.env.base.obs_info import get_features_infos
from gamebreaker.env.base.ops import CopyOverScalarFeatures
from gamebreaker.env.base.ops import CreateEmptyArray
from gamebreaker.env.base.ops import FilterForNet
from gamebreaker.env.base.ops import PermuteToFS
from gamebreaker.env.base.ops import ProcessCategoricalFeatures
from gamebreaker.env.base.ops import ProcessScalarFeatures
from gamebreaker.unit_data import all_units


def remove_redundant_axes(
    jac_tuple: Tuple[Tuple[torch.Tensor, ...], ...]
) -> Tuple[torch.Tensor, ...]:
    """
    Because we have to batch the input, the jacobian will include the same jacobian several times.
    Also, we need to recombine the unit stats with the inputs

    Parameters
    ----------
    jac_tuple: Tuple[torch.Tensor, ...]
        Tuple of jacobians that includes extra information

    Returns
    -------
    Tuple[torch.Tensor, ...]
    """
    new_jac_tuple = []
    for raw_unit_jac, unit_stats_jac in jac_tuple:
        raw_jac = raw_unit_jac[0, 0, :, 1:]
        nb_units = raw_jac.shape[0]
        stats_jac = unit_stats_jac[0, 0].permute(1, 0)[0:nb_units, :]

        new_jac_tuple.append(torch.cat((stats_jac, raw_jac), 1))

    return tuple(new_jac_tuple)


def get_labeled_jacobian(
    jacobian_tuple: Tuple[torch.Tensor, ...], labels: List[str]
) -> Dict[str, torch.Tensor]:
    """
    Converts the output from PyTorch's jacobian function from a Tuple of tensors to a
    dictionary of tensors

    Parameters
    ----------
    jacobian_tuple: Tuple[torch.Tensor, ...]
        The jacobians as they're output from PyTorch's Jacobian function
    labels: List[str]
        List of labels for the dictionary

    Returns
    -------
    Dict[str, torch.Tensor]
        Dictionary with keys corresponding to labels and tensors from the Jacobian
    """
    return {label: torch.clone(jacobian_tuple[ix]) for ix, label in enumerate(labels)}


def get_jacobian_fig(jacobian_tensor: torch.Tensor, **kwargs) -> go.Figure:
    """This function plots a 2-D tensor (assumably a jacobian) to a heatmap using plotly
    graph objects.

    Parameters
    ----------
    jacobian_tensor: torch.Tensor
        2D tensor to be plotted in a heatmap
    kwargs
        Dictionary with optional keys:
            - xlabels: Tick labels for x-axis
            - ylabels: Tick labels for y-axis
            - title: Title for the plot
            - x_title: Title for the x-axis
            - y_title: Title for the y-axis

    Returns
    -------
    go.Figure
        Plottable figure of the jacobian
    """

    # Create a heatmap using plotly
    fig = go.Figure(
        data=go.Heatmap(z=jacobian_tensor, x=kwargs.get("xlabels"), y=kwargs.get("ylabels"))
    )

    # Add all of the annotations to the graph
    fig.update_layout(
        title=dict(text=kwargs.get("title"), font=dict(family="Arial", size=30),),
        xaxis=dict(tickfont=(dict(family="Arial", size=12))),
        yaxis=dict(tickfont=(dict(family="Arial", size=12))),
        xaxis_title=dict(text=kwargs.get("x_title"), font=dict(family="Arial", size=16)),
        yaxis_title=dict(text=kwargs.get("y_title"), font=dict(family="Arial", size=16)),
    )

    return fig


def get_normalized_jacobian(
    jacobian_in: torch.Tensor, absolute_norm: bool = False,
) -> torch.Tensor:
    """Get the Jacobian, normalized between either [0, 1] or [-1, 1]

    Parameters
    ----------
    jacobian_in: torch.Tensor
        The input jacobian to normalize
    absolute_norm: bool
        If 'True', normalizes between [0, 1], otherwise normalizes between [-1, 1]
    Returns
    -------
    torch.Tensor
        The normalized jacobian
    """

    max_abs_value = torch.max(torch.abs(jacobian_in))

    # Protect against div by 0 errors
    if max_abs_value == 0:
        return jacobian_in

    if absolute_norm:
        normalized_jacobian = torch.abs(jacobian_in) / max_abs_value
    else:
        normalized_jacobian = jacobian_in / max_abs_value

    return normalized_jacobian


def get_sorted_jacobian(
    jacobian_tensor: torch.Tensor, labels: np.ndarray, sort_dim: int
) -> Tuple[torch.Tensor, np.ndarray]:
    """Function for sorting a 2-D tensor along a given dimension as well as the labels for
    that dimension.

    Parameters
    ----------
    jacobian_tensor: torch.Tensor
        1- or 2-D tensor containing the jacobian to be sorted by the average value of row or column
    labels: np.ndarray
        The labels corresponding to the axis that is to be sorted (we need to sort these in the same
        order as the jacobian tensor)
    sort_dim: int
        Which dimension we're sorting across (0 or 1)

    Returns
    -------
    Tuple[torch.Tensor, np.ndarray]
        Tuple containing the sorted jacobian and axis labels
    """

    # Determine the average importance of each row or column as the average of the
    # absolute value of that row or column.
    avg_importance = torch.mean(torch.abs(jacobian_tensor), dim=1 - sort_dim)

    # Sort the average importance tensor, and track the indices. This allows us to sort
    # the jacobian tensor and the labels together
    if sort_dim == 0:
        _, sorted_indices = torch.sort(avg_importance, descending=True)
    else:
        _, sorted_indices = torch.sort(avg_importance, descending=True)

    # Depending on the dimension that we're sorting by, use the sorted indices to
    # rearrange that dimension and the corresponding labels
    temp_tensor = torch.clone(jacobian_tensor)

    if sort_dim == 0:
        sorted_jacobian = temp_tensor[sorted_indices]
    elif sort_dim == 1:
        sorted_jacobian = temp_tensor[:, sorted_indices]
    else:
        raise RuntimeError("dim must be either 0 or 1!")

    labels = labels[sorted_indices]

    return sorted_jacobian, labels


def parse_args() -> DotDict:
    """Parses the arguments from the accompanying .yml file

    Returns
    -------
    DotDict
        All of the arguments needed to use the model
    """
    from gamebreaker.config import CFG

    args = {"logdir": CFG.logdir, "tag": CFG.tag, "gpu_id": CFG.gpu_id}

    args = DotDict(args)

    model_path = get_path_from_args(args)

    args = get_old_args(args, model_path)
    args.x_max = CFG.x_max
    args.y_max = CFG.y_max
    args.unit_max = CFG.unit_max
    args.file_name = CFG.file_name
    args.abs_norm = CFG.abs_norm

    return args


def build_preprocessors(
    unit_max: int, x_max: int, y_max: int
) -> Tuple[CPUPreprocessor, GPUPreprocessor]:
    """Builds the CPU and GPU preprocessors for the classifier

    Parameters
    ----------
    unit_max: int
        Number of units to normalize to (typically 512)
    x_max: int
        Maximum x value on the map
    y_max: int
        Maximum y value on the map

    Returns
    -------
    Tuple[CPUPreprocessor, GPUPreprocessor]
    """
    # Create the preprocessors
    observation_space = {"raw_units": (None, len(FeatureUnit))}
    observation_dtypes = {"raw_units": np.int64}

    cpu_preprocessor = CPUPreprocessor(
        [
            CreateEmptyArray(unit_max, "raw_units", "proc_units", creep=True),
            ProcessCategoricalFeatures(x_max, y_max, ["raw_units", "proc_units"], ["proc_units"]),
            CopyOverScalarFeatures(["raw_units", "proc_units"], ["proc_units"], creep=True),
            FilterForNet("raw_units", "raw_units"),
        ],
        observation_space,
        observation_dtypes,
    )
    gpu_preprocessor = GPUPreprocessor(
        [
            ProcessScalarFeatures(x_max, y_max, "proc_units", "proc_units", creep=True),
            CastToFloat("proc_units", "proc_units"),
            PermuteToFS("proc_units", "proc_units"),
        ],
        cpu_preprocessor.observation_space,
        cpu_preprocessor.observation_dtypes,
    )

    return cpu_preprocessor, gpu_preprocessor


def main(args: DotDict) -> None:
    """Main function for generating the Jacobian

    Parameters
    ----------
    args: DotDict
        Contains all of the arguments listed in the accompanying .yml file

    Returns
    -------
    None
    """
    # Grab the model path (if it says it created one, there's something wrong with your
    # args)
    model_path = get_path_from_args(args)
    # Build the network
    network = get_network(args, model_path)
    network.train()

    # Create the preprocessors
    cpu_preprocessor, gpu_preprocessor = build_preprocessors(args.unit_max, args.x_max, args.y_max)

    # To get around the issue of recombining bits to determine importance for them, we
    # instead wrap the network's forward function to take in the raw data then process it.
    def jacobian_forward(
        unit_list: torch.Tensor, stat_list: torch.Tensor
    ) -> Tuple[torch.Tensor, ...]:
        """Wraps the classifier's forward function to allow for preprocessing

        Parameters
        ----------
        unit_list: torch.Tensor
            The raw unit vectors from PySCII
        stat_list: torch.Tensor
            List of stats corresponding to each unit in unit_list

        Returns
        -------
        Tuple[torch.Tensor, ...]
            Returns a tuple of the predictions from the classifier
        """
        # Process the raw unit_list
        obs = {"raw_units": unit_list[0, :, :]}
        obs = cpu_preprocessor(obs)
        cpu_proc_units = torch.cat(
            (
                obs["proc_units"].reshape((1, *obs["proc_units"].shape)),
                obs["proc_units"].reshape((1, *obs["proc_units"].shape)),
            ),
            0,
        )
        obs = {"proc_units": cpu_proc_units}

        obs = gpu_preprocessor(obs)

        unit_input = torch.cat((stat_list[:, :, :], obs["proc_units"][:, 9:, :]), 1)

        unit_input = torch.index_select(unit_input, 1, torch.tensor(args.feature_indices))

        predictions = {}
        # Predict on the given input
        temp = network.forward({"units": unit_input.float().to(args.gpu_id)}, {},)[0]
        for key in temp:
            pred = temp[key].squeeze(-1)
            pred = torch.sigmoid(pred)
            pred = pred.double()
            predictions[key] = pred

        # Return a tuple of tensors (as expected by PyTorch's jacobian)
        return tuple(predictions.values())

    # Pull out the specific timestep for the unit list
    game_data = np.load(args.file_name, allow_pickle=True)[0]
    unit_data = game_data["data"][0:1]

    # Pull out the upgrade list for this game and process it
    upgrade_data = create_upgrades_vec([game_data["upgrades"][0], game_data["upgrades"][1]])

    # Calculate the unit stats
    game_stats = convert_raw_to_stats(unit_data, upgrade_data, args.unit_max)
    game_stats = torch.from_numpy(np.asarray(game_stats)).float()

    unit_data = torch.tensor(unit_data).float()
    unit_data = torch.cat((unit_data, unit_data), 0)
    game_stats = torch.cat((game_stats, game_stats), 0)

    # Calculate the jacobian of each output w.r.t. each input
    jac_tuple = jacobian(jacobian_forward, (unit_data, game_stats), strict=True)
    jac_tuple = remove_redundant_axes(jac_tuple)
    jac_dict = get_labeled_jacobian(jac_tuple, args.output_labels)

    # Normalize the Jacobian so it's values lie between 0 and 1 by first taking the
    # absolute value and then dividing by the maximum value
    abs_jac_dict = {}
    for output_label in jac_dict:
        # Normalize the jacobian
        abs_jac_dict[output_label] = get_normalized_jacobian(
            jac_dict[output_label], absolute_norm=args.abs_norm
        )

    # Grab the list of all units we use in an engagement on Gamebreaker (the list stored
    # unit_data.py as well as Xel Naga Towers, which are used for terrain
    gamebreaker_units = list(all_units()) + [units.Neutral.XelNagaTower]

    # For each label that we predict on, plot the jacobians
    for output_label in abs_jac_dict:
        # Plot a heatmap of the value of the jacobian w.r.t. units and features.
        # Start by creating the labels for the y-axis
        y = []
        unit_count = {}

        # Here, the y-axis is corresponds to individual units (i.e., row 1 is a zergling, row 2 is a
        # marine, etc.). Plotly also requires axis labels to be unique, so we assign each unit a
        # number (separate from the tag, because that's ugly)
        for unit in unit_data[0]:
            # Determine the unit's type (zergling, marine, adept,...)
            unit_name = [
                enum_unit.name
                for enum_unit in gamebreaker_units
                if int(unit[FeatureUnit.unit_type]) == enum_unit
            ]

            # Track how many of these units we've seen of this type
            if unit_name[0] in unit_count:
                unit_count[unit_name[0]] += 1
            else:
                unit_count[unit_name[0]] = 0

            # Also provide the team the unit belongs to
            if unit[FeatureUnit.alliance] == PlayerRelative.SELF:
                team = "Blue"
            elif unit[FeatureUnit.alliance] == PlayerRelative.ENEMY:
                team = "Red"
            else:
                team = "Neutral"

            # Append the name to the list of units (ex.: Blue Zergling  1)
            y.append(f"{team} {unit_name[0]} {unit_count[unit_name[0]]: 3d}")

        # In this case, the x-axis is the features of a unit (stats, health, shields, etc.). We can
        # use get_features_infos() to grab the names of each feature
        features_info = get_features_infos(args.x_max, args.y_max)
        x = [stat_name for stat_name in MAX_STATS] + [
            features_info[key].name for key in features_info if key != "unit_type"
        ]

        # Sort the jacobians so that the most important unit appears at the top of the plot
        sorted_jac, sorted_y = get_sorted_jacobian(
            abs_jac_dict[output_label], np.asarray(y), sort_dim=0
        )

        # Sort the jacobians so the most important feature appears on the left
        sorted_jac, sorted_x = get_sorted_jacobian(sorted_jac, np.asarray(x), sort_dim=1)

        # Plotly cannot display all 512 possible units clearly so we truncate to 40
        if sorted_jac.shape[0] > 21:
            truncated_jac = sorted_jac[0:21, :]
            truncated_y = sorted_y[0:21]
        else:
            truncated_jac = sorted_jac
            truncated_y = sorted_y

        # Finally, plot the jacobian w.r.t. the unit list
        units_fig = get_jacobian_fig(
            torch.flip(truncated_jac, (0,)),
            xlabels=sorted_x,
            ylabels=np.flip(truncated_y, 0),
            title=f"Jacobian of {output_label} w.r.t. Units",
            x_title="Unit Features",
            y_title="Unit Number",
        )

        units_fig.show()


if __name__ == "__main__":
    main(parse_args())
