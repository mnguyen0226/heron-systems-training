import os

import numpy as np
import torch
from adept.preprocess import CPUPreprocessor
from adept.preprocess import GPUPreprocessor
from adept.preprocess.ops import CastToFloat
from adept.preprocess.ops import FromNumpy
from pysc2.lib.features import FeatureUnit

from gamebreaker.classifier.utils.common_utils import create_upgrades_vec
from gamebreaker.classifier.utils.common_utils import UPGRADES_MAP
from gamebreaker.env.base.ops import CopyOverScalarFeatures
from gamebreaker.env.base.ops import CreateEmptyArray
from gamebreaker.env.base.ops import FilterForNet
from gamebreaker.env.base.ops import PermuteToFS
from gamebreaker.env.base.ops import ProcessCategoricalFeatures
from gamebreaker.env.base.ops import ProcessScalarFeatures

X_MAX = 64
Y_MAX = 64

observation_space = {"raw_units": (None, len(FeatureUnit))}
observation_dtypes = {"raw_units": np.int64}

UNIT_MAX = 512

cpu_preprocessor = CPUPreprocessor(
    [
        FromNumpy("raw_units", "raw_units"),
        CreateEmptyArray(UNIT_MAX, "raw_units", "proc_units", creep=True),
        ProcessCategoricalFeatures(X_MAX, Y_MAX, ["raw_units", "proc_units"], ["proc_units"]),
        CopyOverScalarFeatures(["raw_units", "proc_units"], ["proc_units"], creep=True),
        FilterForNet("raw_units", "raw_units"),
    ],
    observation_space,
    observation_dtypes,
)
gpu_preprocessor = GPUPreprocessor(
    [
        ProcessScalarFeatures(X_MAX, Y_MAX, "proc_units", "proc_units", creep=True),
        CastToFloat("proc_units", "proc_units"),
        PermuteToFS("proc_units", "proc_units"),
    ],
    cpu_preprocessor.observation_space,
    cpu_preprocessor.observation_dtypes,
)


def process_game_data(data, cpu_preprocessor=cpu_preprocessor, gpu_preprocessor=gpu_preprocessor):
    """Process the data portion of the game

    This method takes in the data vector of a game and performs preprocessing

    Parameters
    ----------
    data : List
        information stored in game["data"]
    cpu_preprocessor : CPUPreprocessor
        Input CPU preprocessor, by default cpu_preprocessor
    gpu_preprocessor : GPUPreprocessor
        Input GPU preprocessor, by default gpu_preprocessor

    Returns
    -------
    Numpy Array
        numpy array of the processed game data information
    """
    game = torch.zeros(size=(len(data), *cpu_preprocessor.observation_space["proc_units"]))
    for i, step in enumerate(data):
        obs = {"raw_units": step}
        obs = cpu_preprocessor(obs)
        game[i] = obs["proc_units"]
    obs = {"proc_units": game}
    obs = gpu_preprocessor(obs)
    return obs["proc_units"].numpy()


def process_game(
    game_path,
    upgrades_map=UPGRADES_MAP,
    cpu_preprocessor=cpu_preprocessor,
    gpu_preprocessor=gpu_preprocessor,
):
    """Process entire match data for a given game

    This method loads and processes a saved raw game and uses the cpu and gpu preprocessors to
    convert the raw data into the state expected by the model.

    Parameters
    ----------
    game_path : string
        path to the game
    upgrades_map : Dict
        the dictionary mapping of upgrades for the match, by default UPGRADES_MAP
    cpu_preprocessor : CPUPreprocessor
        Input CPU preprocessor, by default cpu_preprocessor
    gpu_preprocessor : GPUPreprocessor
        Input GPU preprocessor, by default gpu_preprocessor

    Returns
    -------
    processed_game : Dict
        dictionary that contains all the data in the proper format
    """
    game = np.load(game_path, allow_pickle=True)[0]
    processed_game = {}
    for key in game:
        if key == "upgrades":
            processed_game[key] = create_upgrades_vec(game[key], upgrades_map=upgrades_map)
        elif key == "data":
            processed_game[key] = process_game_data(
                game[key], cpu_preprocessor=cpu_preprocessor, gpu_preprocessor=gpu_preprocessor,
            )
        else:
            processed_game[key] = game[key]
    processed_game["winner"] = int(game_path.split("_")[-1].split(".")[0])
    return processed_game


def save_game(path, ep_num, data):
    """Save a game at the input path

    This method stores the game data at the given path under the name of the given episode number,
    using np.save

    Parameters
    ----------
    path : string
        Path to save processed file
    ep_num : int
        episode number of the match
    data : np.array
        Array of the processed match data
    """
    dir_num = (ep_num // 500) * 500
    curr_path = os.path.join(path, str(dir_num))
    if not os.path.isdir(curr_path):
        os.mkdir(curr_path)

    filename = os.path.join(curr_path, f"{ep_num:05d}.npy")
    print(filename)
    np.save(filename, data)


def process_dir(RAW_DIR, PROC_DIR, **kwargs):
    """Process the files in the given raw directory and save it in the processed directory

    Parameters
    ----------
    RAW_DIR : string
        Path to the raw directory of matches
    PROC_DIR : string
        Path to save the processed matches
    """
    if not os.path.isdir(PROC_DIR):
        os.mkdir(PROC_DIR)

    for mode in ["Training", "Validation", "Testing"]:
        path = os.path.join(RAW_DIR, mode)
        list_dir = [int(milestone) for milestone in os.listdir(path)]
        list_dir = [str(milestone) for milestone in sorted(list_dir)]
        if not os.path.isdir(os.path.join(PROC_DIR, mode)):
            os.mkdir(os.path.join(PROC_DIR, mode))
        for idx in list_dir:
            idx_path = os.path.join(path, idx)
            list_ep = sorted(os.listdir(idx_path))
            for episode in list_ep:
                ep_num = episode.split("_")[0]
                ep_path = os.path.join(idx_path, episode)
                try:
                    data = np.asarray([process_game(ep_path, **kwargs)])
                    save_game(os.path.join(PROC_DIR, mode), int(ep_num), data)
                except TypeError as e:
                    print(f"Skipped {mode} {ep_num} because {e}")
                    continue
                except RuntimeError as e:
                    print(f"Skipped {mode} {ep_num} because {e}")
                    continue


def main():
    """Run preprocessing for the dataset

    This program performs preprocessing on the dataset contained in the datadir and saves the
    processed data in the specified proc_dir
    """
    datadir = "/media/banshee/gb_winprob/Data/raw_dataset_v3/"
    proc_dir = "/media/banshee/gb_winprob/Data/proc_dataset_v3/"
    process_dir(
        datadir,
        proc_dir,
        upgrades_map=UPGRADES_MAP,
        cpu_preprocessor=cpu_preprocessor,
        gpu_preprocessor=gpu_preprocessor,
    )


if __name__ == "__main__":
    main()
