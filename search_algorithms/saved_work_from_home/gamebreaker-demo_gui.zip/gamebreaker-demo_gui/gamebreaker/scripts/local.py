"""
This script is the used to train agents for SC2. See adeptRL/adept/scripts/local.py
for instructions documentation on configurable parameters.

The main parameters you should concern yourself with are:
nb_env - the number of environments to run. For testing, you want to use only
two or three.
logdir - Where to save your logs. Logs contain tensorboard plots,
args.json, and other stuff.

Local Mode

Train an agent with a single GPU.

Usage:
    local [options]
    local --resume <path>
    local (-h | --help)

Agent Options:
    --agent <str>           Name of agent class [default: ACCollectMinerals]

Environment Options:
    --env <str>                 Environment name [default: CollectMineralShards]
    --rwd-norm <str>            Reward normalizer name [default: Clip]
    --manager <str>             Manager to use [default: SubProcEnvManager]

Script Options:
    --gpu-id <int>              CUDA device ID of GPU [default: 0]
    --nb-env <int>              Number of parallel env [default: 2]
    --seed <int>                Seed for random variables [default: 0]
    --nb-step <int>             Number of steps to train for [default: 10e6]
    --load-network <path>       Path to network file (for pretrained weights)
    --load-optim <path>         Path to optimizer file
    --resume <path>             Resume training from log ID .../<logdir>/<env>/<log-id>/
    --config <path>             Use a JSON config file for arguments
    --eval                      Run an evaluation after training
    --prompt                    Prompt to modify arguments

Network Options:
    --net1d <str>               Network to use for 1d input [default: Identity1D]
    --net2d <str>               Network to use for 2d input [default: FiveConvSeq]
    --net3d <str>               Network to use for 3d input [default: FourConv]
    --net4d <str>               Network to use for 4d input [default: Identity4D]
    --netbody <str>             Network to use on merged inputs [default: LSTM]
    --head1d <str>              Network to use for 1d output [default: Identity1D]
    --head2d <str>              Network to use for 2d output [default: UnitTagHead]
    --head3d <str>              Network to use for 3d output [default: Identity3D]
    --head4d <str>              Network to use for 4d output [default: Identity4D]
    --custom-network <str>      Name of custom network class
    --training <bool>           Whether or not we're training [default: True]
    --x_max <int>               X dimension of the map [default: 22]
    --y_max <int>               Y dimension of the map [default: 17]
    --entropy-weight <float>    How heavily to weight the entropy [default: 0.001]
    --nb_encoders <int>         How many encoders to use [default: 1]

Optimizer Options:
    --optim <str>               Name of optimizer [default: RMSprop]
    --lr <float>                Learning rate [default: 0.0007]
    --grad-norm-clip <float>    Clip gradient norms [default: 0.5]
    --warmup <int>              Number of steps to warm up for [default: 100]

Logging Options:
    --tag <str>                 Name your run [default: Transformer_1]
    --logdir <path>             Path to logging directory [default: /tmp/adept_logs/]
    --epoch-len <int>           Save a model every <int> frames [default: 1e6]
    --nb-eval-env <int>         Evaluate agent in a separate thread [default: 0]
    --summary-freq <int>        Tensorboard summary frequency [default: 10]

Troubleshooting Options:
    --profile                   Profile this script
"""
from absl import flags
from adept.scripts.local import main
from adept.utils.util import DotDict

from gamebreaker.agent.ml.ac_alphastar import AlphaStar
from gamebreaker.agent.ml.collect_minerals import ACCollectMinerals
from gamebreaker.env import RawSC2Env
from gamebreaker.network.collect_minerals_network import CollectMineralsNetwork

# Hack to prevent absl from barfing

FLAGS = flags.FLAGS
FLAGS([""])


def parse_args():
    from gamebreaker.config import CFG

    args = DotDict(
        {k: tuple(v) if type(v) not in [int, float, str, bool] else v for k, v in CFG.items()}
    )

    return args


if __name__ == "__main__":
    """Train agents for SC2

    This script is the used to train agents for SC2. See adeptRL/adept/scripts/local.py
    for instructions documentation on configurable parameters.
    """
    import adept

    adept.register_env(RawSC2Env)
    adept.register_agent(ACCollectMinerals)
    adept.register_agent(AlphaStar)
    adept.register_network(CollectMineralsNetwork)

    args = parse_args()
    args.lstm_normalize = False
    args.custom_network = "CollectMineralsNetwork"
    main(args)
