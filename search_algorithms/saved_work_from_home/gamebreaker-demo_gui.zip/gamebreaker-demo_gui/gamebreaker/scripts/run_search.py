"""
Run a search given a selector, classifier, and search type
TODO: Fix adept options

Usage:
    run_search [options]

General Options:
    --algo <str>                Search type to run (full, genetic, or mc) [default: mc]
    --net_type <str>            Type of edge network (nn or logreg) [default: nn]

Selector Options:
    --race <str>                [default: terran]
    --x_min <int>               [default: 0]
    --x_max <int>               [default: 10]
    --y_min <int>               [default: 0]
    --y_max <int>               [default: 10]
    --minerals <int>            [default: 1000]
    --gas <int>                 [default: 200]
    --supply <int>              [default: 20]
    --units <int>               [default: 10]

Log Reg Options
    --model_path <str>          Path to model file

Neural Network Options
    --gpu_id <int>              Which GPU to run the classifier on [default: 0]
    --model_name <str>          Name to save the model under [default: None]
    --save_loc <str>            Directory path to save the model under [default: /media/banshee/gb_winprob/]
    --datadir <str>             Directory to pull data from [default: /media/banshee/gb_winprob/Data/proc_balanced_races]

Adept Options:
    --net1d <str>               Layer type for model [default: Linear]
    --linear_normalize <str>    normalization to use for a layer [default: bn]
    --linear_nb_hidden <int>    Number of hidden linear layers [default: 256]
    --nb_layer <int>            Number of layers [default: 1]
    --net2d <str>               Layer type for model [default: Identity2D]
    --net3d <str>               Layer type for model [default: Identity3D]
    --net4d <str>               Layer type for model [default: Identity4D]
    --netbody <str>             Layer type for body of network [default: Identity1D]
    --head1d <str>              Layer type for head of network [default: Identity1D]
    --head2d <str>              Layer type for head of network [default: Identity2D]
    --head3d <str>              Layer type for head of network [default: Identity3D]
    --head4d <str>              Layer type for head of network [default: Identity4D]

Monte Carlo Options:
    --nstates <int>             Number of random states to evaluate [default: 5]

Full Search Options:
    --max_tries <int>           Tries until deciding that all scenarios are found [default: 10]

Genetic Options:
    --npop <int>                [default: 50]
    --ngen <int>                [default: 40]
    --cxpb <flt>                [default: 0.5]
    --mutpb <flt>               [default: 0.2]
    --mutnb <int>               [default: 1]
"""
from adept.utils.util import DotDict
from pysc2.lib import units

from gamebreaker.classifier.logistic_regression import LogReg
from gamebreaker.classifier.trainer import Trainer
from gamebreaker.classifier.utils import DataDirHelper
from gamebreaker.classifier.utils import DataType
from gamebreaker.search.search import FullSearch
from gamebreaker.search.search import MonteCarloSearch
from gamebreaker.selector.selector import GeneralUniformSelector
from gamebreaker.unit_data import available_units


def parse_args():
    """This method parses the arguments according to the command line args

    Returns
    -------
    args: DocDict
        parsed dictionary of arguments
    """
    from docopt import docopt

    args = docopt(__doc__)
    args = {k.strip("--").replace("-", "_"): v for k, v in args.items()}

    args = DotDict(args)
    for key in args:
        arg = str(args[key]).lower()
        if arg == "none":
            args[key] = None
        elif arg == "true":
            args[key] = True
        elif arg == "false":
            args[key] = False
        elif str(args[key]).isnumeric():
            args[key] = int(args[key])

    if args.race.lower() == "terran":
        args.unit_list = units.Terran
    elif args.race.lower() == "zerg":
        args.unit_list = units.Zerg
    elif args.race.lower() == "protoss":
        args.unit_list = units.Protoss

    return args


def create_net(ntype, path):
    """Creates a network based on the ntype and loads it

    Based on if ntype is "nn" or "logreg", create a trainer, or a LogReg network, and return it

    Parameters
    ----------
    ntype : string
        "nn" for Trainer, "logreg" for LogReg
    path : Path for the LogReg argument
        Path to save the Logistic Regression model

    Returns
    -------
    net:LogReg or Trainer
        The network created based on the arguments
    """
    if ntype.lower() == "nn":
        net = Trainer(args)
    elif ntype.lower() == "logreg":
        net = LogReg(path)
        net.load()
    else:
        raise ("network type not recognized")
    return net


if __name__ == "__main__":
    args = parse_args()
    helper = DataDirHelper("/media/banshee/gb_winprob/Data/proc_balanced_races", DataType.TRAIN)
    network = create_net(args.net_type, args.net_path)
    state = helper.read_episode(0)[0][5]
    selector = GeneralUniformSelector(
        available_units(args.race),
        (args.x_min, args.x_max),
        (args.y_min, args.y_max),
        args.minerals,
        args.gas,
        args.supply,
        args.units,
    )

    if args.algo.lower() == "full":
        search = FullSearch(network, state, selector, args.max_tries)
    elif args.algo.lower() == "genetic":
        raise ("algo not supported yet")
    elif args.algo.lower() == "mc" or args.algo.lower() == "monte carlo":
        search = MonteCarloSearch(network, state, selector, args.nstates)
    else:
        raise (f"algo not recognized: {args.algo}")

    ally, wp = search.search()
    print(wp)
    for ally_unit in ally:
        print("unit type:", ally_unit["unit_type"], "position:", ally_unit["pos"])
