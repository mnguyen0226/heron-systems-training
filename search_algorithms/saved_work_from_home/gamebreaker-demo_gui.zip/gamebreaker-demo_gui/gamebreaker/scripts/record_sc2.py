# Copyright (C) 2020 Heron Systems, Inc.
"""
Record an agent scenario.

Usage:
    record_sc2 [options]

Agent Options:
    --agent <str>                   Python path to an agent class. [default: gamebreaker.agent.scripted.FocusFire]
    --agent_name <str>              Name of agent in replays [default: None]
    --agent_race <str>              Agent 1's race [default: terran]
    --agent2 <str>                  Python path to an agent class for agent 2. [default: gamebreaker.agent.scripted.FocusFire]
    --agent2_name <str>             Name of agent2 in replays [default: None]
    --agent2_race <str>             Agent 2's race [default: zerg]

Selector Options:
    --minerals1 <int>               How many minerals to start player 1 with for building an army [default: 500]
    --gas1 <int>                    How much gas to start player 1 with for building an army [default: 150]
    --minerals2 <int>               How many minerals to start player 2 with for building an army [default: 350]
    --gas2 <int>                    How much gas to start player 2 with for building an army [default: 125]
    --x_min1 <int>                  [default: 16]
    --x_max1 <int>                  [default: 18]
    --y_min1 <int>                  [default: 16]
    --y_max1 <int>                  [default: 18]
    --x_min2 <int>                  [default: 20]
    --x_max2 <int>                  [default: 22]
    --y_min2 <int>                  [default: 16]
    --y_max2 <int>                  [default: 18]


SC2 Options:
    --render <bool>                 Whether to render with pygame. [default: True]
    --feature_screen_size <int>     Resolution for screen feature layers. [default: 84]
    --feature_minimap_size <int>    Resolution for minimap feature layers. [default: 64]
    --rgb_screen_size <int>         Resolution for rendered screen. [default: None]
    --rgb_minimap_size <int>        Resolution for rendered minimap. [default: None]
    --action_space <str>            Which action space to use. [default: RAW]
    --use_feature_units <bool>      Whether to include feature units [default: False]
    --use_raw_units <bool>          Whether to include raw units [default: True]
    --disable_fog <bool>            Whether to disable Fog of War [default: True]
    --max_episodes <int>            Total episodes [default: 100]
    --step_mul <int>                Game steps per agent step. [default: 8]
    --profile <bool>                Whether to turn on code profiling [default: False]
    --trace <bool>                  Whether to trace the code execution [default: False]
    --save_replay <bool>            Whether to save a replay at the end [default: True]
    --map <str>                     Name of a map to use [default: Flat32-Gamebreaker-NoFog]
    --battle_net_map <bool>         Use the battle.net map version [default: False]
    --save_path <str>               Path to save recordings to [default: /media/banshee/gb_winprob/Data/initial_state_raw/Training]
"""
import importlib
import os
import shutil
from pathlib import Path

import numpy as np
from absl import flags
from adept.utils.util import DotDict
from pysc2 import maps
from pysc2.env import sc2_env
from pysc2.lib import stopwatch
from pysc2.lib import units

from gamebreaker import unit_data
from gamebreaker.classifier.utils.dataset_utils import GameRecorder
from gamebreaker.env.spectate_env import SpectateEnv
from gamebreaker.selector.selector import GeneralUniformSelector

TEAM = ["Red", "Blue"]
FLAGS = flags.FLAGS
FLAGS([""])

# Install Flat32-Gamebreaker
install_path = os.path.join(
    Path.home(), "StarCraftII", "Maps", "Melee", "Flat32-Gamebreaker-NoFog.SC2Map"
)

globals()["Flat32-Gamebreaker-NoFog"] = type(
    "Flat32-Gamebreaker-NoFog", (maps.melee.Melee,), dict(filename="Flat32-Gamebreaker-NoFog"),
)

if not os.path.exists(install_path):
    source_path = os.path.join("..", "..", "resources", "Flat32-Gamebreaker-NoFog.SC2Map")
    assert os.path.exists(source_path)

    shutil.copyfile(source_path, install_path)


def parse_args():
    """Parse the file arguments

    Returns
    -------
    DocDict
        parsed arguments for the file
    """
    from docopt import docopt

    args = docopt(__doc__)
    args = {k.strip("--").replace("-", "_"): v for k, v in args.items()}
    args = DotDict(args)

    for key in args:
        if args[key] == "None":
            args[key] = None
        elif args[key] == "True":
            args[key] = True
        elif args[key] == "False":
            args[key] = False
        elif str(args[key]).isnumeric():
            args[key] = int(args[key])

    return args


def run_loop(agents, env, recorder, max_episodes=0, bal=0.0):
    """Run a loop of the interaction between agents and the environment


    Parameters
    ----------
    agents : List
        The agents to interact
    env : MicroBattleEnv
        The environment to run
    recorder : GameRecorder
        GameRecorder for the game
    max_episodes : int, optional
        The maximum number of frames to run, by default 0
    bal : float, optional
        The balance, by default 0.0

    Returns
    -------
    bal : float
        Ratio of games won
    """
    total_frames = 0
    total_episodes = 0

    observation_spec = env.observation_spec()
    action_spec = env.action_spec()
    for agent, obs_spec, act_spec in zip(agents, observation_spec, action_spec):
        agent.setup(obs_spec, act_spec)

    timesteps = env.reset()
    while total_episodes < max_episodes:
        for a in agents:
            a.reset()
        record_data = None
        while True:
            total_frames += 1
            if record_data is None:
                record_data = env.grab_units(timesteps)

            actions = [agent.step(timestep) for agent, timestep in zip(agents, timesteps)]
            # Trying to stop the "available_actions" keyerror
            timesteps, result = env.step(actions)
            if result != -1:
                bal += result
                total_episodes += 1
                ep_num = recorder.save_episode(result, np.asarray(record_data))
                print(f"{ep_num}: {TEAM[result]} won! {bal/total_episodes:.3f}")
                break
    return bal


def main(args):
    """Run interactions of agents and record the results"""
    if args.trace:
        stopwatch.sw.trace()
    elif args.profile:
        stopwatch.sw.enable()

    matchups = [
        {"agent1": "terran", "min1": 150, "agent2": "protoss", "min2": 150},
        {"agent1": "terran", "min1": 150, "agent2": "terran", "min2": 150},
        {"agent1": "terran", "min1": 150, "agent2": "zerg", "min2": 100},
        {"agent1": "protoss", "min1": 150, "agent2": "terran", "min2": 150},
        {"agent1": "protoss", "min1": 150, "agent2": "protoss", "min2": 150},
        {"agent1": "protoss", "min1": 150, "agent2": "zerg", "min2": 140},
        {"agent1": "zerg", "min1": 100, "agent2": "terran", "min2": 150},
        {"agent1": "zerg", "min1": 100, "agent2": "zerg", "min2": 100},
        {"agent1": "zerg", "min1": 140, "agent2": "protoss", "min2": 150},
    ]

    minimum_resources = 100
    maximum_resources = 300

    bal = 0.0

    for match in matchups:
        agent1_resources = maximum_resources
        while agent1_resources >= minimum_resources:
            agent_classes = []
            players = []
            args.agent_race = match["agent1"]
            args.agent2_race = match["agent2"]
            args.minerals1 = agent1_resources
            args.minerals2 = minimum_resources + maximum_resources - agent1_resources
            args.gas1 = agent1_resources
            args.gas2 = minimum_resources + maximum_resources - agent1_resources
            if args.agent_race.lower() == "terran":
                args.unit_list = units.Terran
            elif args.agent_race.lower() == "zerg":
                args.unit_list = units.Zerg
            elif args.agent_race.lower() == "protoss":
                args.unit_list = units.Protoss

            if args.agent2_race.lower() == "terran":
                args.unit2_list = units.Terran
            elif args.agent2_race.lower() == "zerg":
                args.unit2_list = units.Zerg
            elif args.agent2_race.lower() == "protoss":
                args.unit2_list = units.Protoss

            print(f"{args.agent_race}/{args.minerals1} vs. {args.agent2_race}/{args.minerals2}")

            agent_module, agent_name = args.agent.rsplit(".", 1)
            agent_cls = getattr(importlib.import_module(agent_module), agent_name)
            agent_classes.append(agent_cls)
            players.append(
                sc2_env.Agent(sc2_env.Race[args.agent_race], args.agent_name or agent_name)
            )

            agent_module, agent_name = args.agent2.rsplit(".", 1)
            agent_cls = getattr(importlib.import_module(agent_module), agent_name)
            agent_classes.append(agent_cls)
            players.append(
                sc2_env.Agent(sc2_env.Race[args.agent2_race], args.agent2_name or agent_name)
            )

            selectors = [
                GeneralUniformSelector(
                    unit_data.available_units(args.unit_list),
                    minerals=args.minerals1,
                    gas=args.gas1,
                    x_area=(args.x_min1, args.x_max1),
                    y_area=(args.y_min1, args.y_max1),
                ),
                GeneralUniformSelector(
                    unit_data.available_units(args.unit2_list),
                    minerals=args.minerals2,
                    gas=args.gas2,
                    x_area=(args.x_min2, args.x_max2),
                    y_area=(args.y_min2, args.y_max2),
                ),
            ]
            """Run one thread worth of the environment with agents."""
            with SpectateEnv(
                selectors,
                map_name=args.map,
                battle_net_map=args.battle_net_map,
                players=players,
                agent_interface_format=sc2_env.parse_agent_interface_format(
                    feature_screen=args.feature_screen_size,
                    feature_minimap=args.feature_minimap_size,
                    rgb_screen=args.rgb_screen_size,
                    rgb_minimap=args.rgb_minimap_size,
                    action_space=args.action_space,
                    use_feature_units=args.use_feature_units,
                    use_raw_units=args.use_raw_units,
                ),
                step_mul=args.step_mul,
                game_steps_per_episode=args.game_steps_per_episode,
                disable_fog=args.disable_fog,
                visualize=args.render,
            ) as env:

                agents = [agent_cls() for agent_cls in agent_classes]
                recorder = GameRecorder(args.save_path)
                bal = run_loop(agents, env, recorder, args.max_episodes, bal)

            if args.profile:
                print(stopwatch.sw)

            agent1_resources -= 20


if __name__ == "__main__":
    main(parse_args())
