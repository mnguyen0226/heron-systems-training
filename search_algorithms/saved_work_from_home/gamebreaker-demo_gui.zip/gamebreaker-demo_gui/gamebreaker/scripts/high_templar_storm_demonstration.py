# Copyright (C) 2020 Heron Systems, Inc.
# TODO: remove, potentially no longer needed, our ability to demonstrate abilities is quite clear now
# and well documented
import os
import shutil
import time
from pathlib import Path

from absl import flags
from pysc2 import maps
from pysc2.env import sc2_env
from pysc2.lib import units

from gamebreaker import unit_data
from gamebreaker.agent.scripted import AttackAtDestination
from gamebreaker.agent.scripted import StormAtDestination
from gamebreaker.env.action_postprocessor import ActionPostprocessor
from gamebreaker.env.base import AddCreep
from gamebreaker.env.base import AddWall
from gamebreaker.env.micro_battle_env import MicroBattleEnv
from gamebreaker.selector.selector import GeneralUniformSelector
from gamebreaker.selector.selector import MultiSelector

ENV = "Flat32-Gamebreaker-NoFog"
STEP_MUL = 8
NB_STEP = 100000

# Hack to prevent sound card-related error messages
os.environ["SDL_AUDIODRIVER"] = "dsp"

# Hack to prevent absl from barfing
FLAGS = flags.FLAGS
FLAGS([""])

# Install Flat32-Gamebreaker
install_path = os.path.join(Path.home(), "StarCraftII", "Maps", "Melee", f"{ENV}.SC2Map",)
if not os.path.exists(install_path):
    source_path = os.path.join("..", "..", "resources", f"{ENV}.SC2Map")
    assert os.path.exists(source_path)

    shutil.copyfile(source_path, install_path)

globals()[ENV] = type(ENV, (maps.melee.Melee,), dict(filename=ENV),)


def run_loop(agents, env, max_frames=0, max_episodes=0):
    """Run a loop of the interaction between agents and the environment


    Parameters
    ----------
    agents : List
        The agents to interact
    env : MicroBattleEnv
        The environment to run
    max_frames : int, optional
        The maximum number of frames to run, by default 0
    max_episodes : int, optional
        The maximum number of episodes to run, by default 0
    """
    total_frames = 0
    total_episodes = 0
    start_time = time.time()

    env.save_replay_info = {"replay_dir": "videos", "replay_prefix": "storms"}

    action_postprocessor = ActionPostprocessor(env)
    observation_spec = env.observation_spec()
    action_spec = env.action_spec()
    for agent, obs_spec, act_spec in zip(agents, observation_spec, action_spec):
        agent.setup(obs_spec, act_spec)

    try:
        while not max_episodes or total_episodes < max_episodes:
            total_episodes += 1
            timesteps = env.reset()
            observation = timesteps[0]

            for a in agents:
                a.reset()

            is_done = False
            while not is_done:
                total_frames += 1
                actions = [agent.step(timestep) for agent, timestep in zip(agents, timesteps)]
                actions = action_postprocessor.postprocess(actions)
                if max_frames and total_frames >= max_frames:
                    return
                if timesteps[0].last():
                    break

                timesteps, _, is_done, _ = env.step(actions)
    except KeyboardInterrupt:
        pass
    finally:
        elapsed_time = time.time() - start_time
        print(
            "Took %.3f seconds for %s steps: %.3f fps"
            % (elapsed_time, total_frames, total_frames / elapsed_time)
        )


def main():
    """Runs the pysc2 environment to demonstrate high templar storm activation

    Raises
    ------
    ValueError
        If an unexpected number of players is selected
    """
    players = [
        sc2_env.Agent(sc2_env.Race.terran),
        sc2_env.Agent(sc2_env.Race.zerg),
    ]

    agents = [
        StormAtDestination((11, 13)),
        AttackAtDestination(unit_data.all_units(), (16, 16)),
    ]

    selectors = [
        # Spawn 3 high templars
        GeneralUniformSelector(
            [units.Protoss.HighTemplar],
            minerals=150,
            gas=450,
            supply=6,
            x_area=(0, 32),
            y_area=(0, 0),
        ),
        # Spawn a bunch of zerglings and banelings
        GeneralUniformSelector(
            [units.Zerg.Baneling, units.Zerg.Zergling],
            minerals=2000,
            gas=2000,
            supply=20,
            x_area=(8, 8),
            y_area=(13, 13),
        ),
    ]

    # Run map checks
    expected_players = maps.get(ENV).players
    print(f"Environment {ENV} has {expected_players} players")

    if expected_players != len(players):
        raise ValueError(
            f"Expected {expected_players} players, but received {len(players)} players instead."
        )

    world_size = (32, 32)

    with MicroBattleEnv(
        world_size,
        selectors,
        terrain_modifiers=[
            AddWall(start_xy=(5, 10), length=4, orientation="right",),
            AddWall(start_xy=(5, 16), length=4, orientation="right",),
            AddWall(start_xy=(3, 10), length=4, orientation="up",),
            AddWall(start_xy=(13, 10), length=4, orientation="up",),
        ],
        map_name=ENV,
        players=players,
        agent_interface_format=sc2_env.AgentInterfaceFormat(
            feature_dimensions=sc2_env.Dimensions(screen=84, minimap=84,),
            action_space=sc2_env.ActionSpace.RAW,
            use_raw_units=True,
            raw_crop_to_playable_area=True,
        ),
        step_mul=STEP_MUL,
        game_steps_per_episode=STEP_MUL * NB_STEP,
        visualize=True,
    ) as env:
        run_loop(agents, env, NB_STEP)


if __name__ == "__main__":
    main()
