# Configuration is accessible via a global gamebreaker.config.CFG object
# Lowest priority defaults are defined gamebreaker/config/base.yml
# Second lowest priority defaults are defined in gamebreaker/scripts/<scriptname>.yml
# Medium priority defaults are passed via a configuration file config=<config>.yml
# Second highest priority parameters are passed via commandline
# Highest priority parameters are passed directly as arguments
# Import CFG within scope to prevent circular dependencies. This is only an
# issue if gamebreaker.config module depends on other modules.
# TODO: remove, most likely redundant at this point as a number of files we have are demonstrating
# the CFG method of arguments
def configurable_function(logdir: str = None, batch_size: int = None):
    """Example configurable function for getting parameters from CFG

    Parameters
    ----------
    logdir : str, optional
        example parameter, by default None
    batch_size : int, optional
        example parameter, by default None

    Returns
    -------
    args
        example arguments from either CFG or the command line, or direct arguments
    """
    from gamebreaker.config import CFG

    logdir = logdir or CFG.logdir
    batch_size = batch_size or CFG.batch_size

    # do some stuff

    return logdir, batch_size


class ConfigurableClass:
    """Example configurable class that takes arguments in __init__

    This class demonstrates proper usage of CFG to collect arguments
    """

    def __init__(self, logdir: str = None, batch_size: int = None):
        from gamebreaker.config import CFG

        self.logdir = logdir or CFG.logdir
        self.batch_size = batch_size or CFG.batch_size


if __name__ == "__main__":
    # function using default configuration
    logdir, batch_size = configurable_function()
    print(logdir, batch_size)

    # initialize a class with defaults
    configured_object = ConfigurableClass()
    print(configured_object.logdir, configured_object.batch_size)

    # override defaults by passing values in directly
    configured_object = ConfigurableClass("/home", 32)
    print(configured_object.logdir, configured_object.batch_size)

    # pass command line arguments
    # python -m gamebreaker.scripts.cfg_example logdir=/tmp/abc

    # pass config file
    # python -m gamebreaker.scripts.cfg_example config=../resources/test_config.yml
