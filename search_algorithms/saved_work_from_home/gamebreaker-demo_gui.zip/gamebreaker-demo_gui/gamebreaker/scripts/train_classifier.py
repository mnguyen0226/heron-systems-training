import os
from typing import Any
from typing import Dict
from typing import List
from typing import Tuple
from typing import Union

import numpy as np
import torch
import torch.nn as nn
from adept.network import ModularNetwork
from adept.utils.util import DotDict

from gamebreaker.classifier.utils.common_utils import ALL_INDICES
from gamebreaker.classifier.utils.common_utils import DASHBOARD_INDICES
from gamebreaker.classifier.utils.common_utils import get_network
from gamebreaker.classifier.utils.common_utils import get_path_from_args
from gamebreaker.classifier.utils.common_utils import save_args
from gamebreaker.classifier.utils.training_utils import GBDataset
from gamebreaker.classifier.utils.training_utils import ModelResultsLogger
from gamebreaker.classifier.utils.training_utils import rolling_average


def get_batch_results(
    network: ModularNetwork,
    loss: List[Union[nn.BCELoss, nn.MSELoss]],
    units: torch.Tensor,
    labels: torch.Tensor,
) -> Tuple[Dict[str, torch.Tensor], Dict[str, torch.Tensor], Dict[str, torch.Tensor]]:
    """Returns the accuracy results of a model when given a batch of matches

    This method takes in the input units matrix and context vector of the match and the end result,
    and compares that to the prediction made by the network. It then calculates the batch accuracy
    and loss.

    Parameters
    ----------
    network : ModularNetwork
        Input Modular network to test the batch results on
    args : DotDict
        Arguments that contain information to build the model.
    units : torch.Tensor
        2-D tensor that contains each unit and the features for each unit.
        Dimensions: (512, Feature_length)
    context : torch.Tensor
        1-D tensor that contains the races, upgrades, and agents
    labels : torch.Tensor
        True labels of the data

    Returns
    -------
    Tuple[Dict[str, torch.Tensor], Dict[str, float], Dict[str, torch.Tensor]]
        Tuple of the batch accuracies, batch loss, and predictions
    """
    temp = network.forward({"units": units}, {})

    # Grab and reformat the output predictions of the model
    predictions = {}
    for key in temp[0]:
        pred = temp[0][key].squeeze(-1)
        pred = torch.sigmoid(pred)
        pred = pred.double()
        predictions[key] = pred

    # Record the loss and accuracy for this batch
    batch_loss = {}
    batch_accuracies = {}
    for ix, (label, key) in enumerate(zip(labels, predictions)):
        batch_accuracies[str(key)] = 1 - torch.mean(torch.abs(predictions[str(key)] - label))

        batch_loss[str(key)] = loss[ix](predictions[key], label)

    return batch_accuracies, batch_loss, predictions


def evaluate_over_dataset(
    network: ModularNetwork,
    dataset: GBDataset,
    output_labels: List[str],
    loss: List[Union[nn.BCELoss, nn.MSELoss]],
    optim: Any,
    logger: ModelResultsLogger,
    epoch: int,
    train_step: bool = False,
) -> Tuple[Dict[str, float], Dict[str, float]]:
    """Evaluates the accuracy and loss of a model across an entire dataset

    Given a dataset, this method iterates over each batch for a given number of epochs and generates
    an average accuracy and an average loss

    Parameters
    ----------
    network : ModularNetwork
        The ModularNetwork to evaulate the accuracy and loss for
    dataset : GBDataset
        The GBDataset object that contains the stored matches
    args : DotDict
        Arguments that contain information to build the model
    optim : Any
        Optimizer to use for the backpropation if in a training epoch
    logger : ModelResultsLogger
        ModelResultsLogger object that writes the reseults to tensorboard and stdout
    epoch : int
        ID number of the epoch for logging
    train_step : bool, optional
        Defines if we are training the model or not, by default False

    Returns
    -------
    Tuple[Dict[str, float], Dict[str, float]]
        Tuple containing a Dictionary of the epoch accuracies, and a Dictionary of the epoch loss
    """
    # Dictionary for recording average accuracy over an epoch
    epoch_accuracies = {key: 0 for key in output_labels}

    # Dictionary for recording average loss over an epoch
    epoch_loss = {key: 0 for key in output_labels}
    epoch_loss["total"] = 0

    # Iterate over each batch in the epoch
    for nb_batches, (units, _, labels) in enumerate(dataset):
        # Run the batch and grab the accuracies, loss, and predictions
        batch_accuracies, batch_loss, predictions = get_batch_results(network, loss, units, labels)

        # Determine the total loss as the sum of all the loss functions for this batch
        batch_loss["total"] = torch.sum(torch.stack([batch_loss[i] for i in batch_loss]))

        # Record the average accuracy and loss
        for key in epoch_accuracies:
            epoch_accuracies[key] = rolling_average(
                epoch_accuracies[key], float(batch_accuracies[key]), nb_batches
            )

            epoch_loss[key] = rolling_average(epoch_loss[key], batch_loss[key].item(), nb_batches)

        epoch_loss["total"] = rolling_average(
            epoch_loss["total"], batch_loss["total"].item(), nb_batches
        )

        # Log the results to tensorboard
        logger.log_to_tensorboard(batch_accuracies, batch_loss, train_step)

        # Print out the epoch results to stdout
        logger.print_results(
            epoch_accuracies, epoch_loss, nb_batches, len(dataset), epoch, train_step,
        )

        # If this is a training epoch, then we do backprop
        if train_step:
            optim.zero_grad()
            batch_loss["total"].backward()
            optim.step()

    return epoch_accuracies, epoch_loss


def save_network(network: ModularNetwork, path: str, name: str):
    """Saves the models weights

    This method will use torch save to store the state of the network at the specified path

    Parameters
    ----------
    network : ModularNetwork
        Network to save
    path : str
        Path to the save location
    name : str
        Name to save the model as
    """
    torch.save(network.state_dict(), os.path.join(path, name))


def parse_args():
    """Grabs the arguments from either command line or the yml file

    This method takes in the yml file config as default arguments, and accepts command line argument
    overrides

    Returns
    -------
    args : DocDict
        DocDict that holds all the arguments neccessary to run the model
    """
    from gamebreaker.config import CFG

    args = {
        "tag": CFG.tag,
        "gpu_id": CFG.gpu_id,
        "logdir": CFG.logdir,
        "datadir": CFG.datadir,
        "feature_indices": CFG.feature_indices,
        "batch_size": CFG.batch_size,
        "learning_rate": CFG.learning_rate,
        "n_epoch": CFG.n_epoch,
        "patience": CFG.patience,
        "sensitivity": CFG.sensitivity,
        "net1d": CFG.net1d,
        "net2d": CFG.net2d,
        "netbody": CFG.netbody,
        "output_labels": CFG.output_labels,
        "loss": CFG.loss,
        "conv_nb_hidden": CFG.conv_nb_hidden,
        "linear_normalize": CFG.linear_normalize,
        "linear_nb_hidden": CFG.linear_nb_hidden,
        "nb_conv_layer": CFG.nb_conv_layer,
        "nb_layer": CFG.nb_layer,
        "nb_units": CFG.nb_units,
        "head1d": CFG.head1d,
        "head2d": CFG.head2d,
        "dropout": CFG.dropout,
        "nb_heads": CFG.nb_heads,
        "nb_encoders": CFG.nb_encoders,
        "ram_size": CFG.ram_size,
    }

    args = DotDict(args)

    if str(args.feature_indices) == "ALL_INDICES":
        args.feature_indices = ALL_INDICES
    elif str(args.feature_indices) == "DASHBOARD_INDICES":
        args.feature_indices = DASHBOARD_INDICES

    args.loss = list(args.loss)
    args.output_labels = list(args.output_labels)
    return DotDict(args)


def main():
    """Train the classifier based on the input arguments

    This method trains the input classifier and logs the result of the training to Tensorboard and
    the command line
    """
    # Get args
    args = parse_args()

    # Get the path to the save directory (and create it, if it doesn't exist)
    model_path = get_path_from_args(args)

    # Build the network (all of the arguments should be specified here by default, so
    # we don't have to bother searching for the old arguments)
    network = get_network(args, model_path)

    # Save the arguments as a json file so they can be loaded later
    save_args(args, model_path)

    # Convert the loss functions from strings to the actual functions
    for ix, loss_function in enumerate(args["loss"]):
        if loss_function == "bce":
            args["loss"][ix] = torch.nn.BCELoss()
        elif loss_function == "mse":
            args["loss"][ix] = torch.nn.MSELoss()

    # Build the logger
    network_logger = ModelResultsLogger(model_path)

    # Load the dataset
    training_set = GBDataset(
        os.path.join(args.datadir, "Training"),
        args.batch_size,
        gpu_id=args.gpu_id,
        indices=args.feature_indices,
        ram_size=args.ram_size,
    )
    validation_set = GBDataset(
        os.path.join(args.datadir, "Validation"),
        args.batch_size,
        gpu_id=args.gpu_id,
        indices=args.feature_indices,
        ram_size=args.ram_size,
    )

    # Train the model
    optim = torch.optim.Adam(network.parameters(), args.learning_rate)

    minimum_val_loss = None
    epochs_since_improvement = 0

    print(f"Trainable Parameters: {sum(p.numel() for p in network.parameters())}")

    for epoch in range(args.n_epoch):
        # Train step
        # We don't need the returns here, as the training accuracy and losses aren't
        # important for early stopping
        _, _ = evaluate_over_dataset(
            network,
            training_set,
            args.output_labels,
            args.loss,
            optim,
            network_logger,
            epoch,
            train_step=True,
        )

        # Validation step
        with torch.no_grad():
            # We DO want the returns here, as validation loss is important
            _, validation_loss = evaluate_over_dataset(
                network,
                validation_set,
                args.output_labels,
                args.loss,
                optim,
                network_logger,
                epoch,
                train_step=False,
            )

        save_network(network, model_path, f"network_epoch_{epoch:03d}.pt")

        # Check to see if we have a new best model or if we have to stop
        if not minimum_val_loss or validation_loss["total"] <= minimum_val_loss:
            minimum_val_loss = validation_loss["total"]
            epochs_since_improvement = 0
            save_network(network, model_path, "model_best.pt")
        elif epochs_since_improvement >= args.patience != 0:
            break

        epochs_since_improvement += 1
    print("")


if __name__ == "__main__":
    main()
