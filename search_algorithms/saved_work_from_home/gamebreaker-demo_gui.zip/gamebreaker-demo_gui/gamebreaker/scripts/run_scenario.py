# Copyright (C) 2020 Heron Systems, Inc.
"""
Record an agent scenario.

Usage:
    run_scenario [options]

Script Options:
    --blue_agent <str>              Python path to an agent class. [default: gamebreaker.agent.scripted.FocusFire]
    --blue_name <str>               Name of agent in replays [default: None]
    --red_agent <str>               Python path to an agent class for agent 2. [default: gamebreaker.agent.scripted.FocusFire]
    --red_name <str>                Name of agent2 in replays [default: None]
    --json_path <str>               Path to JSON file with perturbations [default: None]

SC2 Options:
    --render <bool>                 Whether to render with pygame. [default: True]
    --feature_screen_size <int>     Resolution for screen feature layers. [default: 84]
    --feature_minimap_size <int>    Resolution for minimap feature layers. [default: 64]
    --rgb_screen_size <int>         Resolution for rendered screen. [default: None]
    --rgb_minimap_size <int>        Resolution for rendered minimap. [default: None]
    --action_space <str>            Which action space to use. [default: RAW]
    --use_feature_units <bool>      Whether to include feature units [default: False]
    --use_raw_units <bool>          Whether to include raw units [default: True]
    --disable_fog <bool>            Whether to disable Fog of War [default: True]
    --max_episodes <int>            Total episodes [default: 100]
    --step_mul <int>                Game steps per agent step. [default: 1]
    --profile <bool>                Whether to turn on code profiling [default: False]
    --trace <bool>                  Whether to trace the code execution [default: False]
    --save_replay <bool>            Whether to save a replay at the end [default: True]
    --map <str>                     Name of a map to use [default: Flat32-Gamebreaker-Empty]
    --battle_net_map <bool>         Use the battle.net map version [default: False]
    --save_path <str>               Path to save recordings to [default: /media/banshee/gb_winprob/Data/test]
"""
import importlib
import json
import os
import shutil
from pathlib import Path

from absl import flags
from adept.utils.util import DotDict
from pysc2 import maps
from pysc2.env import sc2_env
from pysc2.lib import stopwatch

from gamebreaker.env.json_battle_env import JSONBattleEnv


TEAM = ["Red", "Blue"]
FLAGS = flags.FLAGS
FLAGS([""])

# Install Flat32-Gamebreaker
install_path = os.path.join(
    Path.home(), "StarCraftII", "Maps", "Melee", "Flat32-Gamebreaker-Empty.SC2Map",
)

globals()["Flat32-Gamebreaker-Empty"] = type(
    "Flat32-Gamebreaker-Empty", (maps.melee.Melee,), dict(filename="Flat32-Gamebreaker-Empty"),
)

if not os.path.exists(install_path):
    source_path = os.path.join("..", "..", "resources", "Flat32-Gamebreaker-Empty.SC2Map")
    assert os.path.exists(source_path)

    shutil.copyfile(source_path, install_path)


def parse_args():
    """This method parses the arguments according to the command line args

    Returns
    -------
    args: DocDict
        parsed dictionary of arguments
    """
    from docopt import docopt

    args = docopt(__doc__)
    args = {k.strip("--").replace("-", "_"): v for k, v in args.items()}
    args = DotDict(args)

    for key in args:
        if args[key] == "None":
            args[key] = None
        elif args[key] == "True":
            args[key] = True
        elif args[key] == "False":
            args[key] = False
        elif str(args[key]).isnumeric():
            args[key] = int(args[key])

    return args


def run_loop(agents, env, max_episodes=0):
    """A run loop to have agents and an environment interact.

    Parameters
    ----------
    agents : List
        List of agents in the interaction
    env : MicroBattleEnv
        pysc2 environment to run
    max_episodes : int, optional
        maximum number of episodes to run, by default 0
    """
    total_frames = 0
    total_episodes = 0
    bal = 0.0

    observation_spec = env.observation_spec()
    action_spec = env.action_spec()
    for agent, obs_spec, act_spec in zip(agents, observation_spec, action_spec):
        agent.setup(obs_spec, act_spec)

    timesteps = env.reset()
    print("")
    while total_episodes < max_episodes:
        for a in agents:
            a.reset()

        while True:
            total_frames += 1
            actions = [agent.step(timestep) for agent, timestep in zip(agents, timesteps)]
            # Trying to stop the "available_actions" keyerror
            timesteps, result = env.step(actions)
            if result != -1:
                print("")
                bal += result
                total_episodes += 1
                print(f"{total_episodes}: {TEAM[result]} won! {bal/total_episodes:.3f}")


def get_perturbed_values(json_path):
    """Returns the perturbed values from the input json file

    Parameters
    ----------
    json_path : string
        path to the json file that contains the perturbations

    Returns
    -------
    final_values : Dict
        Dictionary of the final values for the perturbation json
    """
    with open(json_path, "r") as fp:
        perturbations = json.load(fp)
    perturbations = perturbations["game_parameters"]

    final_values = {}
    for key in perturbations:
        if "perturb" in perturbations[key]:
            final_values[key] = perturbations[key]["perturb"]
        else:
            final_values[key] = perturbations[key]["default"]

    races = [
        "terran",
        "zerg",
        "protoss",
    ]
    for key in final_values["agent_race"]:
        final_values["agent_race"][key] = races[final_values["agent_race"][key] - 1]
    return final_values


def main(args):
    """This runs a sc2 scenario based on the input perturbations given in the json file"""
    if args.trace:
        stopwatch.sw.trace()
    elif args.profile:
        stopwatch.sw.enable()

    # Grab the perturbations from the JSON file
    perturbations = get_perturbed_values(args.json_path)

    agent_classes = []
    players = []

    blue_module, blue_name = args.blue_agent.rsplit(".", 1)
    agent_cls = getattr(importlib.import_module(blue_module), blue_name)
    agent_classes.append(agent_cls)
    players.append(
        sc2_env.Agent(
            sc2_env.Race[perturbations["agent_race"]["blue"]], args.blue_name or blue_name,
        )
    )

    red_module, red_name = args.red_agent.rsplit(".", 1)
    agent_cls = getattr(importlib.import_module(red_module), red_name)
    agent_classes.append(agent_cls)
    players.append(
        sc2_env.Agent(sc2_env.Race[perturbations["agent_race"]["red"]], args.red_name or red_name,)
    )

    """Run one thread worth of the environment with agents."""
    with JSONBattleEnv(
        perturbations,
        map_name=args.map,
        battle_net_map=args.battle_net_map,
        players=players,
        agent_interface_format=sc2_env.parse_agent_interface_format(
            feature_screen=args.feature_screen_size,
            feature_minimap=args.feature_minimap_size,
            rgb_screen=args.rgb_screen_size,
            rgb_minimap=args.rgb_minimap_size,
            action_space=args.action_space,
            use_feature_units=args.use_feature_units,
            use_raw_units=args.use_raw_units,
        ),
        step_mul=args.step_mul,
        game_steps_per_episode=args.game_steps_per_episode,
        disable_fog=args.disable_fog,
        visualize=args.render,
    ) as env:

        agents = [agent_cls() for agent_cls in agent_classes]

        run_loop(agents, env, args.max_episodes)

    if args.profile:
        print(stopwatch.sw)


if __name__ == "__main__":
    main(parse_args())
