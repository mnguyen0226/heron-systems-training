# Copyright (C) 2021 Heron Systems, Inc.
from collections import namedtuple

from pysc2.lib import units

_AVAILABLE_UNITS = [
    # Terran
    units.Terran.Marine,
    units.Terran.Marauder,
    units.Terran.Reaper,
    units.Terran.SiegeTank,
    units.Terran.Hellion,
    units.Terran.Cyclone,
    units.Terran.Thor,
    # Protoss
    units.Protoss.Zealot,
    units.Protoss.Stalker,
    units.Protoss.Sentry,
    units.Protoss.Adept,
    units.Protoss.Immortal,
    units.Protoss.Colossus,
    units.Protoss.HighTemplar,
    # Zerg
    units.Zerg.Zergling,
    units.Zerg.Baneling,
    units.Zerg.Roach,
    units.Zerg.Hydralisk,
    units.Zerg.Ultralisk,
    units.Zerg.Infestor,
]


def all_units():
    """Returns a set of all the units

    Returns
    -------
    Set[pysc2.lib.units]
        The set of Terran, Protoss, and Zerg units
    """
    return set([u for u in units.Terran] + [u for u in units.Protoss] + [u for u in units.Zerg])


def available_units(races):
    """Returns a list of the available units

    Parameters
    ----------
    races :
        The races to check available units for

    Returns
    -------
    List[pysc2.lib.units]
        List of all the available units for the given races
    """
    if type(races) not in [list, tuple]:
        races = [races]
    return [u for u in _AVAILABLE_UNITS if type(u) in races]


# TODO: fields to incorporate: game_speed, armor, {ground,air}_attack, {ground,air}_dps,
# bonus_dps, attack_mod, speed, range, sight
UnitMetadata = namedtuple(
    "UnitMetadata", ["supply", "minerals", "gas", "health", "shield", "range"],
)

_UNIT_DATA = {
    # Protoss
    units.Protoss.Zealot: UnitMetadata(
        supply=2, minerals=100, gas=0, health=100, shield=50, range=0.1
    ),
    units.Protoss.Sentry: UnitMetadata(
        supply=2, minerals=50, gas=100, health=40, shield=40, range=5
    ),
    units.Protoss.Stalker: UnitMetadata(
        supply=2, minerals=125, gas=50, health=80, shield=80, range=6
    ),
    units.Protoss.Adept: UnitMetadata(
        supply=2, minerals=100, gas=25, health=70, shield=70, range=4
    ),
    units.Protoss.Immortal: UnitMetadata(
        supply=4, minerals=275, gas=100, health=200, shield=100, range=6
    ),
    units.Protoss.Colossus: UnitMetadata(
        supply=6, minerals=300, gas=200, health=200, shield=150, range=7
    ),
    units.Protoss.HighTemplar: UnitMetadata(
        # NOTE: attack range is 6, but psionic storm range is 9
        supply=2,
        minerals=50,
        gas=150,
        health=40,
        shield=40,
        range=6,
    ),
    # Terran
    units.Terran.Marine: UnitMetadata(supply=1, minerals=50, gas=0, health=45, shield=0, range=5),
    units.Terran.Marauder: UnitMetadata(
        supply=2, minerals=100, gas=25, health=125, shield=0, range=6
    ),
    units.Terran.Reaper: UnitMetadata(supply=1, minerals=50, gas=50, health=60, shield=0, range=5),
    # NOTE: attack range for siegetank is 13 in siege mode
    units.Terran.SiegeTank: UnitMetadata(
        supply=3, minerals=150, gas=125, health=175, shield=0, range=7
    ),
    units.Terran.Hellion: UnitMetadata(supply=2, minerals=100, gas=0, health=90, shield=0, range=5),
    units.Terran.Cyclone: UnitMetadata(
        supply=3, minerals=150, gas=100, health=120, shield=0, range=5
    ),
    units.Terran.Thor: UnitMetadata(
        supply=6, minerals=300, gas=200, health=400, shield=0, range=10
    ),
    # Zerg
    units.Zerg.Zergling: UnitMetadata(
        supply=0.5, minerals=25, gas=0, health=35, shield=0, range=0.1
    ),
    units.Zerg.Baneling: UnitMetadata(
        supply=0.5, minerals=25, gas=25, health=30, shield=0, range=2.2
    ),
    units.Zerg.Roach: UnitMetadata(supply=2, minerals=75, gas=25, health=145, shield=0, range=4),
    units.Zerg.Hydralisk: UnitMetadata(
        supply=2, minerals=100, gas=50, health=90, shield=0, range=5
    ),
    units.Zerg.Ultralisk: UnitMetadata(
        supply=6, minerals=300, gas=200, health=500, shield=0, range=1
    ),
    units.Zerg.Infestor: UnitMetadata(
        supply=2, minerals=100, gas=150, health=90, shield=0, range=0
    ),
}


def unit_data(unit):
    """Returns the unit data for the input unit

    Parameters
    ----------
    unit : pysc2.lib.unit
        the unit to get the data for

    Returns
    -------
    UnitMetadata
        The data for the unit
    """
    return _UNIT_DATA[unit]


def unit_race(unit_type):
    """Returns the race for the input unit

    Parameters
    ----------
    unit_type : pysc2.lib.unit
        unit to check the race of

    Returns
    -------
    Race of the unit, either units.Terran, units.Protoss, or units.Zerg
    """
    for race in [units.Terran, units.Protoss, units.Zerg]:
        if unit_type in list(race):
            return race
