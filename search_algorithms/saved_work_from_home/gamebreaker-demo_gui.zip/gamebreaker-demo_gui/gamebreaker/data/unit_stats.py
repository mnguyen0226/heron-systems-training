from collections import namedtuple

import numpy as np
from adept.utils.util import DotDict
from pysc2.lib import units
from pysc2.lib.buffs import Buffs
from pysc2.lib.features import PlayerRelative
from pysc2.lib.named_array import NamedNumpyArray

from gamebreaker.env.base.obs_idx import ContextObsIdx

UnitMetadata = namedtuple(
    "UnitMetadata",
    [
        "supply",
        "minerals",
        "gas",
        "health",
        "shield",
        "speed",
        "g_range",
        "g_dps",
        "g_damage",
        "a_range",
        "a_dps",
        "a_damage",
    ],
)

MAX_STATS = DotDict(
    supply=6.0,
    minerals=300.0,
    gas=200.0,
    health=500.0,
    shield=150.0,
    speed=10.0,
    g_range=7.0,
    g_dps=90.0,
    g_damage=44.0,
    a_range=10.0,
    a_dps=28.0,
    a_damage=18.0,
)

BASE_STATS = {
    # Protoss
    units.Protoss.Zealot: DotDict(
        supply=2,
        minerals=100,
        gas=0,
        health=100,
        shield=50,
        speed=3.15,
        g_range=0.1,
        g_dps=18.6,
        g_damage=8,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Protoss.Sentry: DotDict(
        supply=2,
        minerals=50,
        gas=100,
        health=40,
        shield=40,
        speed=3.15,
        g_range=5,
        g_dps=8.4,
        g_damage=6,
        a_range=5,
        a_dps=8.4,
        a_damage=6,
    ),
    units.Protoss.Stalker: DotDict(
        supply=2,
        minerals=125,
        gas=50,
        health=80,
        shield=80,
        speed=4.13,
        g_range=6,
        g_dps=9.7,
        g_damage=13,
        a_range=6,
        a_dps=9.7,
        a_damage=13,
    ),
    units.Protoss.Adept: DotDict(
        supply=2,
        minerals=100,
        gas=25,
        health=70,
        shield=70,
        speed=3.5,
        g_range=4,
        g_dps=6.2,
        g_damage=10,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Protoss.Immortal: DotDict(
        supply=4,
        minerals=275,
        gas=100,
        health=200,
        shield=100,
        speed=3.15,
        g_range=6,
        g_dps=19.2,
        g_damage=20,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Protoss.Colossus: DotDict(
        supply=6,
        minerals=300,
        gas=200,
        health=200,
        shield=150,
        speed=3.15,
        g_range=7,
        g_dps=18.7,
        g_damage=10,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Protoss.HighTemplar: DotDict(
        # NOTE: attack range is 6, but psionic storm range is 9
        supply=2,
        minerals=50,
        gas=150,
        health=40,
        shield=40,
        speed=6,
        g_range=6,
        g_dps=3.2,
        g_damage=4,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Protoss.Archon: DotDict(
        supply=4,
        minerals=100,
        gas=300,
        health=10,
        shield=350,
        speed=3.94,
        g_range=3,
        g_dps=20,
        g_damage=25,
        a_range=3,
        a_dps=20,
        a_damage=25,
    ),
    units.Protoss.Probe: DotDict(
        supply=1,
        minerals=50,
        gas=0,
        health=20,
        shield=20,
        speed=3.94,
        g_range=0.1,
        g_dps=4.67,
        g_damage=5,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    # Terran
    units.Terran.Marine: DotDict(
        supply=1,
        minerals=50,
        gas=0,
        health=45,
        shield=0,
        speed=3.15,
        g_range=5,
        g_dps=9.8,
        g_damage=6,
        a_range=5,
        a_dps=9.8,
        a_damage=6,
    ),
    units.Terran.Marauder: DotDict(
        supply=2,
        minerals=100,
        gas=25,
        health=125,
        shield=0,
        speed=3.15,
        g_range=6,
        g_dps=9.3,
        g_damage=10,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Terran.Reaper: DotDict(
        supply=1,
        minerals=50,
        gas=50,
        health=60,
        shield=0,
        speed=5.25,
        g_range=5,
        g_dps=10.1,
        g_damage=4,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    # NOTE: attack range for siegetank is 13 in siege mode
    units.Terran.SiegeTank: DotDict(
        supply=3,
        minerals=150,
        gas=125,
        health=175,
        shield=0,
        speed=3.15,
        g_range=7,
        g_dps=20.27,
        g_damage=15,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Terran.Hellion: DotDict(
        supply=2,
        minerals=100,
        gas=0,
        health=90,
        shield=0,
        speed=5.95,
        g_range=5,
        g_dps=4.48,
        g_damage=8,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Terran.Cyclone: DotDict(
        supply=3,
        minerals=150,
        gas=100,
        health=120,
        shield=0,
        speed=4.73,
        g_range=5,
        g_dps=25.2,
        g_damage=18,
        a_range=5,
        a_dps=25.2,
        a_damage=18,
    ),
    units.Terran.Thor: DotDict(
        supply=6,
        minerals=300,
        gas=200,
        health=400,
        shield=0,
        speed=2.62,
        g_range=7,
        g_dps=65.9,
        g_damage=30,
        a_range=10,
        a_dps=11.2,
        a_damage=6,
    ),
    units.Terran.SCV: DotDict(
        supply=1,
        minerals=50,
        gas=0,
        health=45,
        shield=0,
        speed=3.94,
        g_range=0.1,
        g_dps=4.67,
        g_damage=5,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Terran.Hellbat: DotDict(
        supply=2,
        minerals=100,
        gas=0,
        health=135,
        shield=0,
        speed=3.15,
        g_range=2,
        g_dps=12.6,
        g_damage=18,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Terran.Ghost: DotDict(
        supply=2,
        minerals=150,
        gas=125,
        health=100,
        shield=0,
        speed=3.94,
        g_range=6,
        g_dps=9.3,
        g_damage=10,
        a_range=6,
        a_dps=9.3,
        a_damage=10,
    ),
    # Zerg
    units.Zerg.Zergling: DotDict(
        supply=0.5,
        minerals=25,
        gas=0,
        health=35,
        shield=0,
        speed=4.13,
        g_range=0.1,
        g_dps=10,
        g_damage=5,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Zerg.Baneling: DotDict(
        supply=0.5,
        minerals=25,
        gas=25,
        health=30,
        shield=0,
        speed=3.5,
        g_range=2.2,
        g_dps=0,
        g_damage=16,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Zerg.Roach: DotDict(
        supply=2,
        minerals=75,
        gas=25,
        health=145,
        shield=0,
        speed=3.15,
        g_range=4,
        g_dps=11.2,
        g_damage=16,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Zerg.Hydralisk: DotDict(
        supply=2,
        minerals=100,
        gas=50,
        health=90,
        shield=0,
        speed=3.15,
        g_range=5,
        g_dps=20.4,
        g_damage=12,
        a_range=5,
        a_dps=20.4,
        a_damage=12,
    ),
    units.Zerg.Ultralisk: DotDict(
        supply=6,
        minerals=300,
        gas=200,
        health=500,
        shield=0,
        speed=4.13,
        g_range=1,
        g_dps=57.38,
        g_damage=35,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Zerg.Infestor: DotDict(
        supply=2,
        minerals=100,
        gas=150,
        health=90,
        shield=0,
        speed=3.15,
        g_range=0,
        g_dps=0,
        g_damage=0,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Zerg.Queen: DotDict(
        supply=2,
        minerals=150,
        gas=0,
        health=175,
        shield=0,
        speed=1.31,
        g_range=5,
        g_dps=11.2,
        g_damage=4,
        a_range=7,
        a_dps=12.6,
        a_damage=9,
    ),
    units.Zerg.Ravager: DotDict(
        supply=1,
        minerals=25,
        gas=75,
        health=120,
        shield=0,
        speed=3.85,
        g_range=6,
        g_dps=14.04,
        g_damage=16,
        a_range=0,
        a_dps=0,
        a_damage=0,
    ),
    units.Zerg.InfestedTerran: DotDict(
        supply=1,
        minerals=50,
        gas=75,
        health=50,
        shield=0,
        speed=1.31,
        g_range=5,
        g_dps=10,
        g_damage=6,
        a_range=6,
        a_dps=12.3,
        a_damage=14,
    ),
}


def stats_to_ndarray(stats: DotDict) -> np.ndarray:
    return np.asarray(
        [
            stats.supply,
            stats.minerals,
            stats.gas,
            stats.health,
            stats.shield,
            stats.speed,
            stats.g_range,
            stats.g_dps,
            stats.g_damage,
            stats.a_range,
            stats.a_dps,
            stats.a_damage,
        ]
    )


def get_stats(unit: NamedNumpyArray, upgrade_list: np.ndarray) -> DotDict:
    """
    Uses the unit type, buffs applied to that unit, and the upgrades available to calculate a unit's
    stats.

    Parameters
    ----------
    unit: NamedNumpyArray
        The unit to be converted. Needs at least the features unit_type, buff_id_0, buff_id_1,
        attack_upgrade_level, and on_creep
    upgrade_list: np.ndarray
        The current upgrades available to each unit

    Returns
    -------
    DotDict
        DotDict with fields supply, minerals, gas, health, shield, g_range (ground attack range),
        g_dps, g_damage, a_range (air attack range), a_dps, a_damage
    """
    stats = DotDict(
        supply=0,
        minerals=0,
        gas=0,
        health=0,
        shield=0,
        speed=0,
        g_range=0,
        g_dps=0,
        g_damage=0,
        a_range=0,
        a_dps=0,
        a_damage=0,
    )

    if unit.unit_type in BASE_STATS:
        for key in stats:
            stats[key] += BASE_STATS[unit.unit_type][key]

    if unit.unit_type == units.Protoss.Zealot:
        if unit.buff_id_0 == Buffs.Charging or unit.buff_id_1 == Buffs.Charging:
            stats.speed += 5.67

        stats.g_damage += unit.attack_upgrade_level
        stats.g_dps += 2.33 * unit.attack_upgrade_level

    elif unit.unit_type == units.Protoss.Sentry:
        stats.g_damage += unit.attack_upgrade_level
        stats.g_dps += 1.4 * unit.attack_upgrade_level

        stats.a_damage += unit.attack_upgrade_level
        stats.a_dps += 1.4 * unit.attack_upgrade_level

    elif unit.unit_type == units.Protoss.Stalker:
        stats.g_damage += unit.attack_upgrade_level
        stats.g_dps += 0.75 * unit.attack_upgrade_level

        stats.a_damage += unit.attack_upgrade_level
        stats.a_dps += 0.75 * unit.attack_upgrade_level

    elif unit.unit_type == units.Protoss.Adept:
        stats.g_damage += unit.attack_upgrade_level
        if (
            unit.alliance == PlayerRelative.SELF
            and upgrade_list[ContextObsIdx.blue_resonating_glaives]
        ) or (
            unit.alliance == PlayerRelative.ENEMY
            and upgrade_list[ContextObsIdx.red_resonating_glaives]
        ):
            stats.g_dps = 9 + 0.9 * unit.attack_upgrade_level
        else:
            stats.g_dps += 0.75 * unit.attack_upgrade_level

    elif unit.unit_type == units.Protoss.Immortal:
        stats.g_damage += 2 * unit.attack_upgrade_level
        stats.g_dps += 1.92 * unit.attack_upgrade_level

    elif unit.unit_type == units.Protoss.Colossus:
        stats.g_damage += unit.attack_upgrade_level
        stats.g_dps += 1.87 * unit.attack_upgrade_level

    elif unit.unit_type == units.Protoss.HighTemplar:
        stats.g_damage += unit.attack_upgrade_level
        stats.g_dps += 0.8 * unit.attack_upgrade_level

    elif unit.unit_type == units.Protoss.Archon:
        stats.g_damage += 3 * unit.attack_upgrade_level
        stats.g_dps += 2.5 * unit.attack_upgrade_level

        stats.a_damage += 3 * unit.attack_upgrade_level
        stats.a_dps += 2.5 * unit.attack_upgrade_level

    elif unit.unit_type == units.Terran.Marine:
        stats.g_damage += unit.attack_upgrade_level
        stats.a_damage += unit.attack_upgrade_level

        if unit.buff_id_0 == Buffs.Stimpack or unit.buff_id_1 == Buffs.Stimpack:
            stats.g_dps = 14.7 + 2.4 * unit.attack_upgrade_level
            stats.a_dps = 14.7 + 2.4 * unit.attack_upgrade_level
            stats.speed += 1.57
        else:
            stats.g_dps += 1.6 * unit.attack_upgrade_level
            stats.a_dps += 1.6 * unit.attack_upgrade_level

    elif unit.unit_type == units.Terran.Marauder:
        stats.g_damage += unit.attack_upgrade_level

        if unit.buff_id_0 == Buffs.Stimpack or unit.buff_id_1 == Buffs.Stimpack:
            stats.g_dps = 14.1 + 1.4 * unit.attack_upgrade_level
            stats.a_dps = 14.1 + 1.4 * unit.attack_upgrade_level
            stats.speed += 1.57
        else:
            stats.g_dps += 1.4 * unit.attack_upgrade_level
            stats.a_dps += 1.4 * unit.attack_upgrade_level

    elif unit.unit_type == units.Terran.Reaper:
        stats.g_damage += unit.attack_upgrade_level
        stats.g_dps += 2.5 * unit.attack_upgrade_level

    elif unit.unit_type == units.Terran.SiegeTank:
        stats.g_damage += 2 * unit.attack_upgrade_level
        stats.g_dps += 2.7 * unit.attack_upgrade_level

    elif unit.unit_type == units.Terran.Hellion:
        stats.g_damage += unit.attack_upgrade_level
        stats.g_dps += 0.56 * unit.attack_upgrade_level

    elif unit.unit_type == units.Terran.Cyclone:
        stats.g_damage += 2 * unit.attack_upgrade_level
        stats.g_dps += 2.8 * unit.attack_upgrade_level

    elif unit.unit_type == units.Terran.Thor:
        stats.g_damage += 3 * unit.attack_upgrade_level
        stats.g_dps += 6.59 * unit.attack_upgrade_level

        stats.a_damage += unit.attack_upgrade_level
        stats.a_dps += unit.attack_upgrade_level

    elif unit.unit_type == units.Terran.Hellbat:
        if (
            upgrade_list[ContextObsIdx.blue_infernal_preigniter] == 1.0
            and unit.alliance == PlayerRelative.SELF
        ) or (
            upgrade_list[ContextObsIdx.red_infernal_preigniter] == 1.0
            and unit.alliance == PlayerRelative.ENEMY
        ):
            stats.g_damage += 12 + unit.attack_upgrade_level
            stats.g_dps += 8.4 + 0.7 * unit.attack_upgrade_level

        stats.g_damage += 2 * unit.attack_upgrade_level
        stats.g_dps += 1.4 * unit.attack_upgrade_level

    elif unit.unit_type == units.Terran.Ghost:
        stats.g_damage += unit.attack_upgrade_level
        stats.g_dps += 0.93 * unit.attack_upgrade_level

        stats.a_damage += unit.attack_upgrade_level
        stats.a_dps += 0.93 * unit.attack_upgrade_level

    elif unit.unit_type == units.Zerg.Zergling:
        stats.g_damage += unit.attack_upgrade_level

        if unit.alliance == PlayerRelative.SELF:
            if upgrade_list[ContextObsIdx.blue_adrenal_glands] == 1.0:
                stats.g_dps = 14.3 + (2.86 * unit.attack_upgrade_level)
            else:
                stats.g_dps = 10 + (2 * unit.attack_upgrade_level)
        elif unit.alliance == PlayerRelative.ENEMY:
            if upgrade_list[ContextObsIdx.red_adrenal_glands] == 1.0:
                stats.g_dps = 14.3 + (2.86 * unit.attack_upgrade_level)
            else:
                stats.g_dps = 10 + (2 * unit.attack_upgrade_level)

        if unit.on_creep:
            stats.speed += 3.18

    elif unit.unit_type == units.Zerg.Baneling:
        stats.g_damage += 2 * unit.attack_upgrade_level

        if unit.on_creep:
            stats.speed += 0.63

    elif unit.unit_type == units.Zerg.Roach:
        stats.g_damage += 2 * unit.attack_upgrade_level
        stats.g_dps += 1.4 * unit.attack_upgrade_level

        if unit.on_creep:
            stats.speed += 1.05

    elif unit.unit_type == units.Zerg.Hydralisk:
        stats.g_damage += unit.attack_upgrade_level
        stats.g_dps += 1.7 * unit.attack_upgrade_level

        stats.a_damage += unit.attack_upgrade_level
        stats.a_dps += 1.7 * unit.attack_upgrade_level

        if unit.on_creep:
            stats.speed += 1.0275

    elif unit.unit_type == units.Zerg.Ultralisk:
        stats.g_damage += 3 * unit.attack_upgrade_level
        stats.g_dps += 4.9 * unit.attack_upgrade_level

        if unit.on_creep:
            stats.speed += 0.82

    elif unit.unit_type == units.Zerg.Infestor:
        if unit.on_creep:
            stats.speed *= 1.3

    elif unit.unit_type == units.Zerg.Queen:
        if unit.on_creep:
            stats.speed = 3.5
        stats.g_damage += unit.attack_upgrade_level
        stats.g_dps += 2.8 * unit.attack_upgrade_level

        stats.a_damage += unit.attack_upgrade_level
        stats.a_dps += 1.4 * unit.attack_upgrade_level

    elif unit.unit_type == units.Zerg.Ravager:
        stats.g_damage += 2 * unit.attack_upgrade_level
        stats.g_dps += 1.75 * unit.attack_upgrade_level

        if unit.on_creep:
            stats.speed = 5

    elif unit.unit_type == units.Zerg.InfestedTerran:
        stats.g_damage += unit.attack_upgrade_level
        stats.g_dps += 1.6 * unit.attack_upgrade_level

        stats.a_damage += unit.attack_upgrade_level
        stats.a_dps += 0.9 * unit.attack_upgrade_level

        if unit.on_creep:
            stats.speed *= 1.3

    for stat_name, stat in stats.items():
        stats[stat_name] = stat / MAX_STATS[stat_name]
    return stats
