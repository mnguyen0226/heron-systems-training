# Copyright (C) 2020 Heron Systems, Inc.
from collections import namedtuple

from pysc2.lib import units
from pysc2.lib.upgrades import Upgrades

# Certain upgrades were not implemented, as researching them did not add them to the
# list of applied upgrades in PySCII. Several of these upgrades would not have affected
# our units anyways.
# Unimplemented upgrades:
# - Research_InterceptorGravitonCatapult_quick
# - Research_AdvancedBallistics_quick
# - Research_CycloneRapidFireLaunchers_quick
# - Research_EnhancedShockwaves_quick
# - Research_HighCapacityFuelTanks_quick
# - Research_RavenRecalibratedExplosives_quick
# - Research_AdaptiveTalons_quick
# - Research_GroovedSpines_quick
# - Research_MuscularAugments_quick

_UPGRADE_BUILDINGS = {
    # Terran
    units.Terran.Armory,
    units.Terran.Barracks,
    units.Terran.EngineeringBay,
    units.Terran.Factory,
    units.Terran.FusionCore,
    units.Terran.GhostAcademy,
    units.Terran.PlanetaryFortress,
    units.Terran.Starport,
    # Protoss
    units.Protoss.CyberneticsCore,
    units.Protoss.DarkShrine,
    units.Protoss.FleetBeacon,
    units.Protoss.Forge,
    units.Protoss.RoboticsBay,
    units.Protoss.TemplarArchive,
    units.Protoss.TwilightCouncil,
    # Zerg
    units.Zerg.BanelingNest,
    units.Zerg.EvolutionChamber,
    units.Zerg.Hatchery,
    units.Zerg.Hive,
    units.Zerg.HydraliskDen,
    units.Zerg.InfestationPit,
    units.Zerg.Lair,
    units.Zerg.SpawningPool,
    units.Zerg.RoachWarren,
    units.Zerg.Spire,
    units.Zerg.UltraliskCavern,
}


def upgrade_buildings(races):
    """Returns a list of the upgrade buildings for the input race

    Parameters
    ----------
    races :
        Race to get upgrades for, either units.Terran, units.Protoss, or units.Zerg

    Returns
    -------
    List
        Sorted list of the upgrade buildings
    """
    if type(races) not in [list, tuple]:
        races = [races]

    return sorted([u for u in _UPGRADE_BUILDINGS if type(u) in races])


def all_buildings():
    """Returns the set of the Upgrade Buildings

    Returns
    -------
    Set
        Set of upgrade buildings
    """
    return _UPGRADE_BUILDINGS


UpgradeMetadata = namedtuple("UpgradeMetadata", ["minerals", "gas", "time", "upgrade", "building"],)


_PROTOSS_UPGRADES = {
    "Research_AdeptResonatingGlaives_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=100,
        upgrade=Upgrades.ResonatingGlaives,
        building=units.Protoss.TwilightCouncil,
    ),
    "Research_Blink_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=121,
        upgrade=Upgrades.Blink,
        building=units.Protoss.TwilightCouncil,
    ),
    "Research_Charge_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=100,
        upgrade=Upgrades.Charge,
        building=units.Protoss.TwilightCouncil,
    ),
    "Research_ExtendedThermalLance_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=140,
        upgrade=Upgrades.ExtendedThermalLance,
        building=units.Protoss.RoboticsBay,
    ),
    "Research_GraviticBooster_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=80,
        upgrade=Upgrades.GraviticBooster,
        building=units.Protoss.RoboticsBay,
    ),
    "Research_GraviticDrive_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=80,
        upgrade=Upgrades.GraviticDrive,
        building=units.Protoss.RoboticsBay,
    ),
    "Research_PhoenixAnionPulseCrystals_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=90,
        upgrade=Upgrades.AnionPulseCrystals,
        building=units.Protoss.FleetBeacon,
    ),
    "Research_ProtossAirArmorLevel1_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=129,
        upgrade=Upgrades.ProtossAirArmorsLevel1,
        building=units.Protoss.CyberneticsCore,
    ),
    "Research_ProtossAirArmorLevel2_quick": UpgradeMetadata(
        minerals=225,
        gas=225,
        time=154,
        upgrade=Upgrades.ProtossAirArmorsLevel2,
        building=units.Protoss.CyberneticsCore,
    ),
    "Research_ProtossAirArmorLevel3_quick": UpgradeMetadata(
        minerals=300,
        gas=300,
        time=179,
        upgrade=Upgrades.ProtossAirArmorsLevel3,
        building=units.Protoss.CyberneticsCore,
    ),
    "Research_ProtossAirWeaponsLevel1_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=129,
        upgrade=Upgrades.ProtossAirWeaponsLevel1,
        building=units.Protoss.CyberneticsCore,
    ),
    "Research_ProtossAirWeaponsLevel2_quick": UpgradeMetadata(
        minerals=175,
        gas=175,
        time=154,
        upgrade=Upgrades.ProtossAirWeaponsLevel2,
        building=units.Protoss.CyberneticsCore,
    ),
    "Research_ProtossAirWeaponsLevel3_quick": UpgradeMetadata(
        minerals=250,
        gas=250,
        time=179,
        upgrade=Upgrades.ProtossAirWeaponsLevel3,
        building=units.Protoss.CyberneticsCore,
    ),
    "Research_ProtossGroundArmorLevel1_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=129,
        upgrade=Upgrades.ProtossGroundArmorsLevel1,
        building=units.Protoss.Forge,
    ),
    "Research_ProtossGroundArmorLevel2_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=154,
        upgrade=Upgrades.ProtossGroundArmorsLevel2,
        building=units.Protoss.Forge,
    ),
    "Research_ProtossGroundArmorLevel3_quick": UpgradeMetadata(
        minerals=200,
        gas=200,
        time=179,
        upgrade=Upgrades.ProtossGroundArmorsLevel3,
        building=units.Protoss.Forge,
    ),
    "Research_ProtossGroundWeaponsLevel1_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=129,
        upgrade=Upgrades.ProtossGroundWeaponsLevel1,
        building=units.Protoss.Forge,
    ),
    "Research_ProtossGroundWeaponsLevel2_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=154,
        upgrade=Upgrades.ProtossGroundWeaponsLevel2,
        building=units.Protoss.Forge,
    ),
    "Research_ProtossGroundWeaponsLevel3_quick": UpgradeMetadata(
        minerals=200,
        gas=200,
        time=179,
        upgrade=Upgrades.ProtossGroundWeaponsLevel3,
        building=units.Protoss.Forge,
    ),
    "Research_ProtossShieldsLevel1_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=129,
        upgrade=Upgrades.ProtossShieldsLevel1,
        building=units.Protoss.Forge,
    ),
    "Research_ProtossShieldsLevel2_quick": UpgradeMetadata(
        minerals=225,
        gas=225,
        time=154,
        upgrade=Upgrades.ProtossShieldsLevel2,
        building=units.Protoss.Forge,
    ),
    "Research_ProtossShieldsLevel3_quick": UpgradeMetadata(
        minerals=300,
        gas=300,
        time=179,
        upgrade=Upgrades.ProtossShieldsLevel3,
        building=units.Protoss.Forge,
    ),
    "Research_PsiStorm_quick": UpgradeMetadata(
        minerals=200,
        gas=200,
        time=110,
        upgrade=Upgrades.PsiStorm,
        building=units.Protoss.TemplarArchive,
    ),
    # NOTE: This is actually Shadow Stride, possibly a typo in PySC2
    "Research_ShadowStrike_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=100,
        upgrade=Upgrades.ShadowStrike,
        building=units.Protoss.DarkShrine,
    ),
}

_TERRAN_UPGRADES = {
    "Research_BansheeCloakingField_quick": UpgradeMetadata(
        minerals=200,
        gas=200,
        time=110,
        upgrade=Upgrades.CloakingField,
        building=units.Terran.StarportTechLab,
    ),
    "Research_BansheeHyperflightRotors_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=121,
        upgrade=Upgrades.HyperflightRotors,
        building=units.Terran.StarportTechLab,
    ),
    "Research_BattlecruiserWeaponRefit_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=100,
        upgrade=Upgrades.WeaponRefit,
        building=units.Terran.FusionCore,
    ),
    "Research_CombatShield_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=100,
        upgrade=Upgrades.CombatShield,
        building=units.Terran.BarracksTechLab,
    ),
    "Research_ConcussiveShells_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=79,
        upgrade=Upgrades.ConcussiveShells,
        building=units.Terran.BarracksTechLab,
    ),
    # TODO: This ugrade does not appear on Liquidpedia
    "Research_CycloneLockOnDamage_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=100,
        upgrade=Upgrades.LockOn,
        building=units.Terran.FactoryTechLab,
    ),
    "Research_DrillingClaws_quick": UpgradeMetadata(
        minerals=75,
        gas=75,
        time=79,
        upgrade=Upgrades.DrillingClaws,
        building=units.Terran.FactoryTechLab,
    ),
    "Research_HiSecAutoTracking_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=57,
        upgrade=Upgrades.HiSecAutoTracking,
        building=units.Terran.EngineeringBay,
    ),
    "Research_InfernalPreigniter_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=79,
        upgrade=Upgrades.InfernalPreigniter,
        building=units.Terran.FactoryTechLab,
    ),
    "Research_PersonalCloaking_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=86,
        upgrade=Upgrades.PersonalCloaking,
        building=units.Terran.GhostAcademy,
    ),
    "Research_RavenCorvidReactor_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=79,
        upgrade=Upgrades.CorvidReactor,
        building=units.Terran.StarportTechLab,
    ),
    "Research_SmartServos_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=79,
        upgrade=Upgrades.SmartServos,
        building=units.Terran.FactoryTechLab,
    ),
    "Research_Stimpack_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=100,
        upgrade=Upgrades.Stimpack,
        building=units.Terran.BarracksTechLab,
    ),
    "Research_TerranInfantryArmorLevel1_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=114,
        upgrade=Upgrades.TerranInfantryArmorsLevel1,
        building=units.Terran.EngineeringBay,
    ),
    "Research_TerranInfantryArmorLevel2_quick": UpgradeMetadata(
        minerals=175,
        gas=175,
        time=136,
        upgrade=Upgrades.TerranInfantryArmorsLevel2,
        building=units.Terran.EngineeringBay,
    ),
    "Research_TerranInfantryArmorLevel3_quick": UpgradeMetadata(
        minerals=250,
        gas=250,
        time=157,
        upgrade=Upgrades.TerranInfantryArmorsLevel3,
        building=units.Terran.EngineeringBay,
    ),
    "Research_TerranInfantryWeaponsLevel1_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=114,
        upgrade=Upgrades.TerranInfantryWeaponsLevel1,
        building=units.Terran.EngineeringBay,
    ),
    "Research_TerranInfantryWeaponsLevel2_quick": UpgradeMetadata(
        minerals=175,
        gas=175,
        time=136,
        upgrade=Upgrades.TerranInfantryWeaponsLevel2,
        building=units.Terran.EngineeringBay,
    ),
    "Research_TerranInfantryWeaponsLevel3_quick": UpgradeMetadata(
        minerals=250,
        gas=250,
        time=157,
        upgrade=Upgrades.TerranInfantryWeaponsLevel3,
        building=units.Terran.EngineeringBay,
    ),
    "Research_TerranShipWeaponsLevel1_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=114,
        upgrade=Upgrades.TerranShipWeaponsLevel1,
        building=units.Terran.Armory,
    ),
    "Research_TerranShipWeaponsLevel2_quick": UpgradeMetadata(
        minerals=175,
        gas=175,
        time=136,
        upgrade=Upgrades.TerranShipWeaponsLevel2,
        building=units.Terran.Armory,
    ),
    "Research_TerranShipWeaponsLevel3_quick": UpgradeMetadata(
        minerals=250,
        gas=250,
        time=157,
        upgrade=Upgrades.TerranShipWeaponsLevel3,
        building=units.Terran.Armory,
    ),
    "Research_TerranStructureArmorUpgrade_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=100,
        upgrade=Upgrades.TerranStructureArmor,
        building=units.Terran.EngineeringBay,
    ),
    "Research_TerranVehicleAndShipPlatingLevel1_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=114,
        upgrade=Upgrades.TerranVehicleAndShipArmorsLevel1,
        building=units.Terran.Armory,
    ),
    "Research_TerranVehicleAndShipPlatingLevel2_quick": UpgradeMetadata(
        minerals=175,
        gas=175,
        time=136,
        upgrade=Upgrades.TerranVehicleAndShipArmorsLevel2,
        building=units.Terran.Armory,
    ),
    "Research_TerranVehicleAndShipPlatingLevel3_quick": UpgradeMetadata(
        minerals=250,
        gas=250,
        time=157,
        upgrade=Upgrades.TerranVehicleAndShipArmorsLevel3,
        building=units.Terran.Armory,
    ),
    "Research_TerranVehicleWeaponsLevel1_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=160,
        upgrade=Upgrades.TerranVehicleWeaponsLevel1,
        building=units.Terran.Armory,
    ),
    "Research_TerranVehicleWeaponsLevel2_quick": UpgradeMetadata(
        minerals=175,
        gas=175,
        time=190,
        upgrade=Upgrades.TerranVehicleWeaponsLevel2,
        building=units.Terran.Armory,
    ),
    "Research_TerranVehicleWeaponsLevel3_quick": UpgradeMetadata(
        minerals=250,
        gas=250,
        time=220,
        upgrade=Upgrades.TerranVehicleWeaponsLevel3,
        building=units.Terran.Armory,
    ),
}

_ZERG_UPGRADES = {
    "Research_AnabolicSynthesis_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=42.9,
        upgrade=Upgrades.AnabolicSynthesis,
        building=units.Zerg.UltraliskCavern,
    ),
    "Research_Burrow_quick": UpgradeMetadata(
        minerals=100, gas=100, time=71, upgrade=Upgrades.Burrow, building=units.Zerg.Hatchery,
    ),
    "Research_CentrifugalHooks_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=110,
        upgrade=Upgrades.CentrificalHooks,
        building=units.Zerg.BanelingNest,
    ),
    # Note: Time is different between expansions
    "Research_ChitinousPlating_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=79,
        upgrade=Upgrades.ChitinousPlating,
        building=units.Zerg.UltraliskCavern,
    ),
    "Research_GlialRegeneration_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=110,
        upgrade=Upgrades.GlialReconstitution,
        building=units.Zerg.RoachWarren,
    ),
    "Research_NeuralParasite_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=79,
        upgrade=Upgrades.NeuralParasite,
        building=units.Zerg.InfestationPit,
    ),
    "Research_PathogenGlands_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=80,
        upgrade=Upgrades.PathogenGlands,
        building=units.Zerg.InfestationPit,
    ),
    "Research_PneumatizedCarapace_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=60,
        upgrade=Upgrades.PneumatizedCarapace,
        building=units.Zerg.Hatchery,
    ),
    "Research_TunnelingClaws_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=110,
        upgrade=Upgrades.TunnelingClaws,
        building=units.Zerg.RoachWarren,
    ),
    "Research_ZergFlyerArmorLevel1_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=114,
        upgrade=Upgrades.ZergFlyerArmorsLevel1,
        building=units.Zerg.Spire,
    ),
    "Research_ZergFlyerArmorLevel2_quick": UpgradeMetadata(
        minerals=225,
        gas=225,
        time=136,
        upgrade=Upgrades.ZergFlyerArmorsLevel2,
        building=units.Zerg.Spire,
    ),
    "Research_ZergFlyerArmorLevel3_quick": UpgradeMetadata(
        minerals=300,
        gas=300,
        time=157,
        upgrade=Upgrades.ZergFlyerArmorsLevel3,
        building=units.Zerg.Spire,
    ),
    "Research_ZergFlyerAttackLevel1_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=114,
        upgrade=Upgrades.ZergFlyerWeaponsLevel1,
        building=units.Zerg.Spire,
    ),
    "Research_ZergFlyerAttackLevel2_quick": UpgradeMetadata(
        minerals=175,
        gas=175,
        time=136,
        upgrade=Upgrades.ZergFlyerWeaponsLevel2,
        building=units.Zerg.Spire,
    ),
    "Research_ZergFlyerAttackLevel3_quick": UpgradeMetadata(
        minerals=250,
        gas=250,
        time=157,
        upgrade=Upgrades.ZergFlyerWeaponsLevel3,
        building=units.Zerg.Spire,
    ),
    "Research_ZergGroundArmorLevel1_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=114,
        upgrade=Upgrades.ZergGroundArmorsLevel1,
        building=units.Zerg.EvolutionChamber,
    ),
    "Research_ZergGroundArmorLevel2_quick": UpgradeMetadata(
        minerals=225,
        gas=225,
        time=136,
        upgrade=Upgrades.ZergGroundArmorsLevel2,
        building=units.Zerg.EvolutionChamber,
    ),
    "Research_ZergGroundArmorLevel3_quick": UpgradeMetadata(
        minerals=300,
        gas=300,
        time=157,
        upgrade=Upgrades.ZergGroundArmorsLevel3,
        building=units.Zerg.EvolutionChamber,
    ),
    "Research_ZergMeleeWeaponsLevel1_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=114,
        upgrade=Upgrades.ZergMeleeWeaponsLevel1,
        building=units.Zerg.EvolutionChamber,
    ),
    "Research_ZergMeleeWeaponsLevel2_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=136,
        upgrade=Upgrades.ZergMeleeWeaponsLevel2,
        building=units.Zerg.EvolutionChamber,
    ),
    "Research_ZergMeleeWeaponsLevel3_quick": UpgradeMetadata(
        minerals=200,
        gas=200,
        time=157,
        upgrade=Upgrades.ZergMeleeWeaponsLevel3,
        building=units.Zerg.EvolutionChamber,
    ),
    "Research_ZergMissileWeaponsLevel1_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=114,
        upgrade=Upgrades.ZergMissileWeaponsLevel1,
        building=units.Zerg.EvolutionChamber,
    ),
    "Research_ZergMissileWeaponsLevel2_quick": UpgradeMetadata(
        minerals=150,
        gas=150,
        time=136,
        upgrade=Upgrades.ZergMissileWeaponsLevel2,
        building=units.Zerg.EvolutionChamber,
    ),
    "Research_ZergMissileWeaponsLevel3_quick": UpgradeMetadata(
        minerals=200,
        gas=200,
        time=157,
        upgrade=Upgrades.ZergMissileWeaponsLevel3,
        building=units.Zerg.EvolutionChamber,
    ),
    "Research_ZerglingAdrenalGlands_quick": UpgradeMetadata(
        minerals=200,
        gas=200,
        time=93,
        upgrade=Upgrades.AdrenalGlands,
        building=units.Zerg.SpawningPool,
    ),
    "Research_ZerglingMetabolicBoost_quick": UpgradeMetadata(
        minerals=100,
        gas=100,
        time=79,
        upgrade=Upgrades.MetabolicBoost,
        building=units.Zerg.SpawningPool,
    ),
}


def all_upgrades():
    """Returns the list of all possible upgrades for all three races

    Returns
    -------
    list
        The list of all possible upgrades
    """
    return (
        [u for u in _PROTOSS_UPGRADES] + [u for u in _TERRAN_UPGRADES] + [u for u in _ZERG_UPGRADES]
    )


def upgrade_data(upgrade):
    """Returns the UpgradeMetadata for a specific upgrade

    Parameters
    ----------
    upgrade : pysc2.lib.upgrade
        the upgrade to obtain the metadata of

    Returns
    -------
    UpgradeMetadata
        The metadata for the upgrade

    Raises
    ------
    ValueError
        if the upgrade is not in the upgrade list
    """
    for upgrade_list in [_PROTOSS_UPGRADES, _TERRAN_UPGRADES, _ZERG_UPGRADES]:
        if upgrade in upgrade_list:
            return upgrade_list[upgrade]

    raise ValueError("Upgrade command not in any upgrade list!")


def upgrade_race(upgrade):
    """Returns the race that an upgrade applies to

    Parameters
    ----------
    upgrade : pysc2.lib.upgrades
        the upgrade to check the race of

    Returns
    -------
    Race of the unit, either units.Terran, units.Protoss, or units.Zerg

    Raises
    ------
    ValueError
        if the upgrade is not in the upgrade list
    """
    if upgrade in _PROTOSS_UPGRADES:
        return units.Protoss
    elif upgrade in _TERRAN_UPGRADES:
        return units.Terran
    elif upgrade in _ZERG_UPGRADES:
        return units.Zerg

    raise ValueError("Upgrade not in any upgrade list!")
