from collections import OrderedDict
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pysc2.lib.actions as sc2_actions
import torch
from adept.actor import ACRolloutActorTrain
from adept.actor.base.ac_helper import ACActorHelperMixin
from adept.agent import AgentModule
from adept.container.base.updater import Updater
from adept.exp import ExpSpecBuilder
from adept.exp import Rollout
from adept.learner import ACRolloutLearner
from adept.network import NetworkModule
from adept.rewardnorm.base.rewnorm_module import RewardNormModule
from adept.utils.util import DotDict

from gamebreaker.env.base import actions as gb_actions
from gamebreaker.env.base import ObsIdx

FUNCTION_TYPE_MAP = {
    sc2_actions.raw_no_op: 0,
    sc2_actions.raw_cmd: 1,
    sc2_actions.raw_cmd_pt: 2,
    sc2_actions.raw_cmd_unit: 3,
}

RAW_FUNCTIONS_NUMPY = np.asarray(
    [FUNCTION_TYPE_MAP[function.function_type] for function in gb_actions._RAW_FUNCTIONS]
)


def compute_selected_units_exp(
    obs: torch.Tensor, pred: torch.Tensor, action: torch.Tensor
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Handles getting the log probs, entropy values, and action choice relating to selecting units
    to complete an action

    Parameters
    ----------
    obs: torch.Tensor
        The current observations/state
    pred: torch.Tensor
        The predictions from the network
    action: torch.Tensor
        The action selected by the network

    Returns
    -------
    Tuple[torch.Tensor, torch.Tensor, torch.Tensor]
    """
    # Mask out all the units that do not belong to the agent (this also masks units that do not
    # exist)
    unit_mask = torch.prod(
        obs[:, ObsIdx.alliance_bit0 : ObsIdx.alliance_bit2 + 1, :].permute(0, 2, 1)
        == torch.cat(
            (
                torch.zeros(obs.shape[0], obs.shape[-1], 1),
                torch.zeros(obs.shape[0], obs.shape[-1], 1),
                torch.ones(obs.shape[0], obs.shape[-1], 1),
            ),
            dim=-1,
        ).to(obs.device),
        dim=-1,
    )

    # Determine the probability distribution of each unit
    selected_units_softmax = torch.stack([1 - torch.sigmoid(pred), torch.sigmoid(pred)]).permute(
        1, 2, 0
    )

    # Calculate the log probs
    selected_units_log_softmax = torch.log(selected_units_softmax)

    # Anywhere there's an inf, swap it with a zero (just for safety)
    selected_units_log_softmax = torch.where(
        torch.isinf(selected_units_log_softmax),
        torch.zeros_like(selected_units_softmax),
        selected_units_log_softmax,
    )

    # Calculate the entropy of the distribution of each unit and zero out entropies if they aren't
    # units the agent owns
    selected_units_entropy = unit_mask * torch.sum(
        -selected_units_softmax * selected_units_log_softmax, dim=2
    )

    # Take the mean of the entropies, ignoring the parts we don't own
    selected_units_entropy = torch.true_divide(
        torch.sum(selected_units_entropy, dim=-1), torch.sum(unit_mask, dim=-1)
    ).unsqueeze(-1)

    # Of all the units we've selected, zero out the ones we don't own
    action = unit_mask * action

    # Grab the log probs of selecting/not selecting all the units we've selected
    selected_units_log_prob = unit_mask * torch.where(
        action == 1, selected_units_log_softmax[:, :, 1], selected_units_log_softmax[:, :, 0],
    )

    return selected_units_log_prob, selected_units_entropy, action.cpu()


class AlphaStar(AgentModule, ACActorHelperMixin):
    args = {**ACRolloutActorTrain.args, **ACRolloutLearner.args}

    def __init__(
        self,
        reward_normalizer: RewardNormModule,
        action_space: Dict[str, Tuple[int]],
        spec_builder: ExpSpecBuilder,
        rollout_len: int,
        discount: float,
        normalize_advantage: bool,
        entropy_weight: float,
        x_max: Optional[int] = 64,
        y_max: Optional[int] = 64,
    ):
        """The Alphastar Agent for playing Starcraft II

        Parameters
        ----------
        reward_normalizer: RewardNormModule
            Normalizer for the reward
        action_space: Dict[str, Tuple[int]]
            What the action space looks like
        spec_builder: ExpSpecBuilder
            Experience replay builder
        rollout_len: int
            The length of the rollout
        discount: float
            The discount rate for the reward
        normalize_advantage: bool
            Whether or not to normalize the advantage function
        entropy_weight: float
            How heavily to weight the entropy loss
        x_max: Optional[int]
            The maximum x value on the map
        y_max: Optional[int]
            The maximum y value of the map
        """
        super().__init__(reward_normalizer, action_space)

        self.discount = discount
        self.normalize_advantage = normalize_advantage
        self.entropy_weight = entropy_weight

        self._exp_cache = Rollout(spec_builder, rollout_len)

        # Mapping to show which output's are used for each command type in SCII
        self._active_ah_map = {
            sc2_actions.raw_no_op: ["func_id"],
            sc2_actions.raw_cmd: ["func_id", "selected_units"],
            sc2_actions.raw_cmd_pt: ["func_id", "selected_units", "x", "y"],
            sc2_actions.raw_cmd_unit: ["func_id", "selected_units", "target_unit",],
        }

        # Maps if an output head is active. [Func_id, x, y, target]
        self._active_ah_idx = np.asarray(
            [
                [1.0, 0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0, 0.0],
                [1.0, 1.0, 1.0, 0.0],
                [1.0, 0.0, 0.0, 1.0],
            ]
        )

        # Units need to be selected for any action other than no_op
        self._selected_units_idx = np.asarray([0.0, 1.0, 1.0, 1.0])

        self.x_max = x_max
        self.y_max = y_max

    @classmethod
    def from_args(
        cls,
        args: DotDict,
        reward_normalizer: RewardNormModule,
        action_space: Dict[str, Tuple],
        spec_builder: ExpSpecBuilder,
        **kwargs: Optional[Dict],
    ) -> "AlphaStar":
        """Creates the network from arguments

        Parameters
        ----------
        args: DotDict
            Arguments for building the network. Requires normalize_advantage, entropy_weight, x_max,
            and y_max
        reward_normalizer: RewardNormModule
            Normalizes reward
        action_space: Dict[str, Tuple]
            Describe the shape of the action space
        spec_builder: ExpSpecBuilder
            Used to create the rollouts
        kwargs: Optional[Dict]
            Unused

        Returns
        -------
        AlphaStar
        """
        return cls(
            reward_normalizer,
            action_space,
            spec_builder,
            rollout_len=args.rollout_len,
            discount=0.9,
            normalize_advantage=args.normalize_advantage,
            entropy_weight=args.entropy_weight,
            x_max=args.x_max,
            y_max=args.y_max,
        )

    @property
    def exp_cache(self) -> Rollout:
        """Returns the exp_cache"""
        return self._exp_cache

    @classmethod
    def _exp_spec(
        cls,
        exp_len: int,
        batch_sz: int,
        obs_space: Dict[str, Tuple[int, ...]],
        action_space: Dict[str, Tuple[int, ...]],
        internal_space: Dict[str, torch.Tensor],
    ) -> Dict[str, Tuple[int, ...]]:
        """Specifies the shape of the each of the output heads

        Parameters
        ----------
        exp_len: int
            Length of the experience replay
        batch_sz: int
            Batch Size
        obs_space: Dict[str, Tuple[int, ...]]
            Defines what the observation space looks like
        action_space: Dict[str, Tuple[int, ...]]
            Defines what the action space looks like
        internal_space: Dict[str, torch.Tensor]
            What the internals look like

        Returns
        -------
        Dict[str, Tuple[int, ...]]
        """
        return {
            "func_id_log_probs": (exp_len, batch_sz),
            "x_log_probs": (exp_len, batch_sz),
            "y_log_probs": (exp_len, batch_sz),
            "selected_units_log_probs": (exp_len, batch_sz, 512),
            "target_unit_log_probs": (exp_len, batch_sz),
            "func_id_entropies": (exp_len, batch_sz),
            "x_entropies": (exp_len, batch_sz),
            "y_entropies": (exp_len, batch_sz),
            "selected_units_entropies": (exp_len, batch_sz, 512),
            "target_unit_entropies": (exp_len, batch_sz),
            "critic": (exp_len, batch_sz),
            # Actions
            "func_id": (exp_len, batch_sz),
            "x": (exp_len, batch_sz),
            "y": (exp_len, batch_sz),
            "selected_units": (exp_len, batch_sz, 512),
            "target_unit": (exp_len, batch_sz),
        }

    @staticmethod
    def output_space(action_space: Dict[str, Tuple]):
        """Defines what the output space looks like"""
        return {"critic": (1,), **action_space}

    def compute_simple_action_exp(
        self, pred: torch.Tensor, action: torch.Tensor, mask: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Function for calculating log probs, and entropy values of 1-D distributions

        Parameters
        ----------
        pred: torch.Tensor
            The prediction from the network
        action: torch.Tensor
            The selected action
        mask: Optional[torch.Tensor]
            An optional mask to specify the valid choices
        Returns
        -------
        Tuple[torch.Tensor, torch.Tensor, torch.Tensor]
            The log probs, entropy values, and CPU action, respectively
        """
        if mask is None:
            # If the mask is not provided, calculate the log softmax and the softmax
            masked_pred = torch.clone(pred)
        else:
            # With a mask, send all invalid options to 0 (by first sending them to negative big)
            masked_pred = torch.where(mask, pred, torch.zeros_like(pred) - (10 ** 10))

        log_softmax = self.log_softmax(masked_pred)
        softmax = self.softmax(masked_pred)

        # Calculate the entropy and log probs
        entropy = self.entropy(log_softmax, softmax)
        log_prob = self.log_probability(log_softmax, action)

        return log_prob, entropy, action.cpu()

    def compute_action_exp(
        self,
        predictions: Dict[str, torch.Tensor],
        internals: OrderedDict,
        obs: torch.Tensor,
        available_actions: Optional[Any] = None,
    ) -> Tuple[OrderedDict, Dict[str, torch.Tensor]]:
        """Function for getting network output for probabilities of actions and choosing the action

        Parameters
        ----------
        predictions: Dict[str, torch.Tensor]
            The predictions output by the network
        internals: OrderedDict
            The internals needed for an LSTM
        obs: torch.Tensor
            The current states
        available_actions: Optional[Any]
            Unused

        Returns
        -------
        Tuple[OrderedDict, Dict[str, torch.Tensor]]
            Actions, log_probs/entropies/actions
        """
        # Critic value
        critic = predictions["critic"].squeeze(1)

        actions = OrderedDict()

        # What action we're taking
        func_id_log_prob, func_id_entropy, actions["func_id"] = self.compute_simple_action_exp(
            predictions["func_id"], torch.argmax(predictions["func_id_chosen"], dim=-1)
        )

        # The targeted x location
        x_log_prob, x_entropy, actions["x"] = self.compute_simple_action_exp(
            predictions["x"], torch.argmax(predictions["x_chosen"], dim=-1)
        )

        # The targeted y location
        y_log_prob, y_entropy, actions["y"] = self.compute_simple_action_exp(
            predictions["y"], torch.argmax(predictions["y_chosen"], dim=-1)
        )

        # The units we'd like to perform this action
        (
            selected_units_log_prob,
            selected_units_entropy,
            actions["selected_units"],
        ) = compute_selected_units_exp(
            obs, predictions["selected_units"], predictions["selected_units_chosen"]
        )

        # The targeted unit (and a mask of all non-zero units)
        nonzero_units = torch.sum(obs, dim=1)
        target_unit_mask = nonzero_units != torch.zeros_like(nonzero_units)
        (
            target_unit_log_prob,
            target_unit_entropy,
            actions["target_unit_tag"],
        ) = self.compute_simple_action_exp(
            predictions["target_unit"],
            torch.argmax(predictions["target_unit_chosen"], dim=-1),
            mask=target_unit_mask,
        )

        return (
            actions,
            {
                "func_id_log_probs": func_id_log_prob,
                "x_log_probs": x_log_prob,
                "y_log_probs": y_log_prob,
                "selected_units_log_probs": selected_units_log_prob,
                "target_unit_log_probs": target_unit_log_prob,
                "func_id_entropies": func_id_entropy,
                "x_entropies": x_entropy,
                "y_entropies": y_entropy,
                "selected_units_entropies": selected_units_entropy,
                "target_unit_entropies": target_unit_entropy,
                "critic": critic,
                "func_id": actions["func_id"],
                "x": actions["x"],
                "y": actions["y"],
                "selected_units": actions["selected_units"],
                "target_unit": actions["target_unit_tag"],
            },
        )

    def learn_step(
        self,
        updater: Updater,
        network: NetworkModule,
        next_obs: Dict[str, torch.Tensor],
        internals: Dict[str, torch.Tensor],
    ) -> Tuple[Dict[str, torch.Tensor], Dict[str, torch.Tensor]]:
        """The learn step for the agent

        Parameters
        ----------
        updater: Updater
            Updater for the network
        network: NetworkModule
            The network
        next_obs: Dict[str, torch.Tensor]
            The next observations the network would see
        internals: Dict[str, torch.Tensor]
            The internals needed for the LSTM

        Returns
        -------
        Tuple[Dict[str, torch.Tensor, Dict[str, torch.Tensor]]
        """
        # Get the experience replay
        experiences = self._exp_cache.read()

        # Normalize rewards
        rewards = self._reward_normalizer(torch.stack(experiences.rewards))

        # We have to remove selected units from the other action heads as it is the only
        # 2D output head and requires separate code to function properly
        action_heads = ["func_id", "x", "y", "target_unit"]

        # Get the log probs for each output head
        r_log_probs_action = [
            torch.stack(getattr(experiences, f"{ah}_log_probs")) for ah in action_heads
        ]

        r_selected_units_log_probs = torch.stack(experiences.selected_units_log_probs)

        r_entropies = [torch.stack(getattr(experiences, f"{ah}_entropies")) for ah in action_heads]

        r_selected_units_entropies = torch.stack(experiences.selected_units_entropies)

        r_values = torch.stack(experiences.critic)

        # estimate value of next state
        with torch.no_grad():
            results, _, _ = network.forward(next_obs, internals)
            last_values = results["critic"].squeeze(1).data

        # compute nstep return and advantage over batch
        r_tgt_returns = self.compute_returns(last_values, rewards, experiences.terminals)

        r_advantages = r_tgt_returns - r_values.data

        # TODO: Comment below is taken from original, slightly unclear
        # normalize advantage so that an even number of actions are reinforced and
        # penalized
        if self.normalize_advantage:
            r_advantages = (r_advantages - r_advantages.mean()) / (r_advantages.std() + 1e-5)

        # Fill in the masks
        func_idx = torch.stack(experiences.func_id)

        policy_loss_mask = torch.from_numpy(self._active_ah_idx[RAW_FUNCTIONS_NUMPY[func_idx]]).to(
            r_selected_units_log_probs.device
        )

        selected_units_policy_loss_mask = (
            torch.from_numpy(self._selected_units_idx[RAW_FUNCTIONS_NUMPY[func_idx]])
            .unsqueeze(-1)
            .to(r_selected_units_log_probs.device)
        )

        policy_loss = [
            -r_log_probs_action[i]
            * r_advantages.unsqueeze(-1)
            * policy_loss_mask[:, :, i].unsqueeze(-1)
            for i, ah in enumerate(action_heads)
        ]

        r, b = r_advantages.size()
        selected_units_policy_loss = (
            -r_selected_units_log_probs
            * r_advantages.view(r, b, 1).expand(-1, -1, r_selected_units_log_probs.shape[-1])
            * selected_units_policy_loss_mask.expand(-1, -1, r_selected_units_log_probs.shape[-1])
        )

        # Average over actions, seq, batch
        policy_loss = (
            sum([pl.mean() for pl in policy_loss]) + selected_units_policy_loss.mean()
        ) / 5

        # entropy_loss = self.entropy_weight * (
        #     sum([-re.mean() for re in r_entropies]) + -r_selected_units_entropies.mean()
        # )

        # mean over the actions, seq, batch
        value_loss = 0.5 * (r_tgt_returns - r_values).pow(2).mean()

        # updater.step(value_loss + policy_loss + entropy_loss)
        updater.step(value_loss + policy_loss)
        losses = {
            "value_loss": value_loss,
            "policy_loss": policy_loss,
            # "entropy_loss": entropy_loss,
            "entropy_loss": torch.zeros_like(policy_loss),
        }

        metrics = {}
        return losses, metrics

    def compute_returns(
        self, bootstrap_value: torch.Tensor, rewards: torch.Tensor, terminals: List[torch.Tensor],
    ) -> torch.Tensor:
        """Compute the n-step returns

        Parameters
        ----------
        bootstrap_value: torch.Tensor
            The initial target return
        rewards: torch.Tensor
            What the reward is at every step
        terminals: List[torch.Tensor]
            Booleans for where the environment reset

        Returns
        -------
        torch.Tensor
            The n-step target returns
        """
        # First step of nstep reward target is estimated value of t+1
        target_return = bootstrap_value
        rollout_len = len(rewards)
        nstep_target_returns = []
        for i in reversed(range(rollout_len)):
            reward = rewards[i]
            terminal_mask = 1.0 - terminals[i].float()

            target_return = reward + (self.discount * target_return * terminal_mask)
            nstep_target_returns.append(target_return)

        # reverse lists
        nstep_target_returns = torch.stack(list(reversed(nstep_target_returns))).data

        return nstep_target_returns
