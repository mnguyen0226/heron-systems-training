from collections import defaultdict
from collections import OrderedDict

import pysc2.lib.actions as sc2_actions
import torch
from adept.actor import ACRolloutActorTrain
from adept.actor.base.ac_helper import ACActorHelperMixin
from adept.agent import AgentModule
from adept.exp import Rollout
from adept.learner import ACRolloutLearner
from torch.nn import functional as F

from gamebreaker.env.base import actions as gb_actions


class ActorCriticSC2(AgentModule, ACActorHelperMixin):
    """Creates an Actor Critic for SC2

    Creates an Actor Critic module for an Agent, based off of Adept Framework.
    Used in gamebreaker/scripts/local.py

    Parameters
    ----------
    AgentModule : AgentModule
        The Adept Agent
    ACActorHelperMixin : ACActorHelperMixin
        Helper class for actor critic actors

    """

    args = {**Rollout.args, **ACRolloutActorTrain.args, **ACRolloutLearner.args}

    def __init__(
        self,
        reward_normalizer,
        action_space,
        spec_builder,
        rollout_len,
        discount,
        normalize_advantage,
        entropy_weight,
    ):
        """Initialize an Actor Critic, contact Joe or view the Adept documentation for more
           information
        TODO: Verify these

        Parameters
        ----------
        reward_normalizer :
            Normalizes rewards to keep learning consistent
        action_space :
            the action space for the environment
        spec_builder : dict
            specification builder
        rollout_len : int
            Amount of steps to conduct rollout across
        discount :
            Discount value
        normalize_advantage :
            Normalize advantage or not
        entropy_weight :
            Amount to weight entropy
        """
        super().__init__(reward_normalizer, action_space)
        self.discount = discount
        self.normalize_advantage = normalize_advantage
        self.entropy_weight = entropy_weight

        self._exp_cache = Rollout(spec_builder, rollout_len)

        self._active_ah_map = {
            sc2_actions.raw_no_op: ["func_id"],
            sc2_actions.raw_cmd: ["func_id", "unit_tag"],
            sc2_actions.raw_cmd_pt: ["func_id", "unit_tag", "x", "y"],
            sc2_actions.raw_cmd_unit: ["func_id", "unit_tag", "target_unit_tag",],
        }

    @classmethod
    def from_args(cls, args, reward_normalizer, action_space, spec_builder, **kwargs):
        """Class Factory constructor from arguments

        Parameters
        ----------
        args : Dict
            Arguments
        reward_normalizer :
            Normalizes rewards to keep learning consistent
        action_space :
            the action space for the environment
        spec_builder : dict
            specification builder

        Returns
        -------
        Object of class ActorCriticSC2
        """
        return cls(
            reward_normalizer,
            action_space,
            spec_builder,
            rollout_len=args.rollout_len,
            discount=args.discount,
            normalize_advantage=args.normalize_advantage,
            entropy_weight=args.entropy_weight,
        )

    @property
    def exp_cache(self):
        """Get the exp cache

        Returns
        -------
        self._exp_cache
        """
        return self._exp_cache

    @classmethod
    def _exp_spec(cls, exp_len, batch_sz, obs_space, act_space, internal_space):
        """Returns the experience specs

        Parameters
        ----------
        exp_len : int
            length of the experience
        batch_sz : int
            batch size
        obs_space :
            observation space
        act_space :
            action space
        internal_space :
            internal space

        Returns
        -------
        Dict
            a Dictionary of the experience specs
        """
        return {
            "func_id_log_probs": (exp_len, batch_sz),
            "x_log_probs": (exp_len, batch_sz),
            "y_log_probs": (exp_len, batch_sz),
            "unit_tag_log_probs": (exp_len, batch_sz, 512),
            "target_unit_tag_log_probs": (exp_len, batch_sz),
            "func_id_entropies": (exp_len, batch_sz),
            "x_entropies": (exp_len, batch_sz),
            "y_entropies": (exp_len, batch_sz),
            "unit_tag_entropies": (exp_len, batch_sz, 512),
            "target_unit_tag_entropies": (exp_len, batch_sz),
            "critic": (exp_len, batch_sz),
            # Actions
            "func_id": (exp_len, batch_sz),
            "x": (exp_len, batch_sz),
            "y": (exp_len, batch_sz),
            "unit_tags": (exp_len, batch_sz, 512),
            "target_unit_tag": (exp_len, batch_sz),
        }

    @staticmethod
    def output_space(action_space):
        """Create a dictionary containing the critic and the unpacked action space

        Parameters
        ----------
        action_space :
            action space for the actor

        Returns
        -------
        Dict
            The output space dictionary
        """
        return {"critic": (1,), **action_space}

    def compute_action_exp(self, predictions, internals, obs, available_actions):
        """Computes the best action to take for an actor

        Parameters
        ----------
        predictions : dict[str, torch.Tensor]
            contains the predictions
        internals : dict[str, torch.Tensor]
            internal values
        obs : dict[str, torch.Tensor]
            Observations of the timestep
        available_actions
            The available actions for the agent to take

        Returns
        -------
        Tuple[OrderedDict[String, Any], Dict[String, Any]]
            The actions, and the relevant action stats
        """
        critic = predictions["critic"].squeeze(1)

        func_id_log_softmax = self.log_softmax(predictions["func_id"])
        x_log_softmax = self.log_softmax(predictions["x"])
        y_log_softmax = self.log_softmax(predictions["y"])
        unit_tag_log_softmax = F.log_softmax(predictions["unit_tags"], dim=2)
        target_unit_log_softmax = self.log_softmax(predictions["target_unit_tag"])

        func_id_softmax = self.softmax(predictions["func_id"])
        x_softmax = self.softmax(predictions["x"])
        y_softmax = self.softmax(predictions["y"])
        unit_tag_softmax = F.softmax(predictions["unit_tags"], dim=2)
        target_unit_softmax = self.softmax(predictions["target_unit_tag"])

        func_id_entropy = self.entropy(func_id_log_softmax, func_id_softmax)
        x_entropy = self.entropy(x_log_softmax, x_softmax)
        y_entropy = self.entropy(y_log_softmax, y_softmax)
        unit_tag_entropy = -(unit_tag_log_softmax * unit_tag_softmax).sum(2, keepdim=True)
        target_unit_entropy = self.entropy(target_unit_log_softmax, target_unit_softmax)

        func_id_action = self.sample_action(func_id_softmax)
        x_action = self.sample_action(x_softmax)
        y_action = self.sample_action(y_softmax)
        b, s, f = unit_tag_softmax.size()
        unit_tag_action = unit_tag_softmax.view(b * s, f).multinomial(1).view(b, s)
        target_unit_action = self.sample_action(target_unit_softmax)

        func_id_log_prob = self.log_probability(func_id_log_softmax, func_id_action)
        x_log_prob = self.log_probability(x_log_softmax, x_action)
        y_log_prob = self.log_probability(y_log_softmax, y_action)
        unit_tag_log_prob = unit_tag_log_softmax.gather(f, unit_tag_action.view(b, s, 1))
        target_unit_log_prob = self.log_probability(target_unit_log_softmax, target_unit_action)

        actions = OrderedDict()
        actions["func_id"] = func_id_action.cpu()
        actions["x"] = x_action.cpu()
        actions["y"] = y_action.cpu()
        actions["unit_tags"] = unit_tag_action.cpu()
        actions["target_unit_tag"] = target_unit_action.cpu()

        return (
            actions,
            {
                "func_id_log_probs": func_id_log_prob,
                "x_log_probs": x_log_prob,
                "y_log_probs": y_log_prob,
                "unit_tag_log_probs": unit_tag_log_prob,
                "target_unit_tag_log_probs": target_unit_log_prob,
                "func_id_entropies": func_id_entropy,
                "x_entropies": x_entropy,
                "y_entropies": y_entropy,
                "unit_tag_entropies": unit_tag_entropy,
                "target_unit_tag_entropies": target_unit_entropy,
                "critic": critic,
                "func_id": func_id_action.cpu(),
                "x": x_action.cpu(),
                "y": y_action.cpu(),
                "unit_tags": unit_tag_action.cpu(),
                "target_unit_tag": target_unit_action.cpu(),
            },
        )

    def learn_step(self, updater, network, next_obs, internals):
        """Calculates losses and updates the network weights.

        Parameters
        ----------
        updater : adept.container.Updater
            Updater contains the backprop logic
        network : adept.network.NetworkModule
            Adept network
        next_obs : dict[str, torch.Tensor]
            Next observation (outside the rollout)
        internals : dict[str, torch.Tensor]
            Internal network states (e.g. for LSTMs)

        Returns
        -------
        Tuple[dict[str, torch.Tensor], dict[str, torch.Tensor]]
            Losses and metrics
        """
        experiences = self._exp_cache.read()
        # normalize rewards
        rewards = self._reward_normalizer(torch.stack(experiences.rewards))

        action_heads = ["func_id", "x", "y", "target_unit_tag"]

        # torch stack rollouts
        r_log_probs_action = [
            torch.stack(getattr(experiences, f"{ah}_log_probs")) for ah in action_heads
        ]
        r_unit_tag_log_probs = torch.stack(experiences.unit_tag_log_probs)
        r_entropies = [torch.stack(getattr(experiences, f"{ah}_entropies")) for ah in action_heads]
        r_unit_tag_entropies = torch.stack(experiences.unit_tag_entropies)
        r_values = torch.stack(experiences.critic)

        # estimate value of next state
        with torch.no_grad():
            results, _, _ = network(next_obs, internals)
            last_values = results["critic"].squeeze(1).data

        # compute nstep return and advantage over batch
        r_tgt_returns = self.compute_returns(last_values, rewards, experiences.terminals)
        r_advantages = r_tgt_returns - r_values.data

        # normalize advantage so that an even number
        # of actions are reinforced and penalized
        if self.normalize_advantage:
            r_advantages = (r_advantages - r_advantages.mean()) / (r_advantages.std() + 1e-5)

        # batched losses
        hierarchical_action_space = True
        n_steps, n_envs = r_advantages.shape

        if not hierarchical_action_space:
            policy_loss_mask = [1.0 for _ in range(len(action_heads))]
            unit_tag_policy_loss_mask = 1.0
        else:
            # Initialize the masks
            policy_loss_mask = [
                torch.zeros(n_steps, n_envs, 1, device=r_unit_tag_log_probs.device)
                for _ in range(len(action_heads))
            ]

            unit_tag_policy_loss_mask = torch.zeros(
                n_steps, n_envs, 1, 1, device=r_unit_tag_log_probs.device
            )

            # Fill in the masks
            for step_ix in range(n_steps):
                for env_ix in range(n_envs):
                    # Use the function id to determine the which heads are active.
                    func_id = experiences.func_id[step_ix][env_ix]
                    ftype = gb_actions._RAW_FUNCTIONS[func_id].function_type
                    active_ah = self._active_ah_map[ftype]

                    # Fill in the mask entries associated with the step taken in this
                    # env.
                    for i, ah in enumerate(action_heads):
                        if ah in active_ah:
                            policy_loss_mask[i][step_ix, env_ix] = 1.0

                    if "unit_tag" in active_ah:
                        unit_tag_policy_loss_mask[step_ix, env_ix] = 1.0

        policy_loss = [
            -r_log_probs_action[i] * r_advantages.unsqueeze(-1) * policy_loss_mask[i]
            for i, ah in enumerate(action_heads)
        ]

        r, b = r_advantages.size()
        unit_tag_policy_loss = (
            -r_unit_tag_log_probs * r_advantages.view(r, b, 1, 1) * unit_tag_policy_loss_mask
        )

        # mean over actions, seq, batch
        policy_loss = sum([pl.mean() for pl in policy_loss]) + unit_tag_policy_loss.mean()

        # Notice that the entropy and value losses have the same form regardless of
        # whether we employ hierarchical action spaces.
        # TODO: check whether this is correct
        entropy_loss = self.entropy_weight * (
            sum([-re.mean() for re in r_entropies]) + -r_unit_tag_entropies.mean()
        )

        # mean over actions, seq, batch
        value_loss = 0.5 * (r_tgt_returns - r_values).pow(2).mean()

        updater.step(value_loss + policy_loss + entropy_loss)

        losses = {
            "value_loss": value_loss,
            "policy_loss": policy_loss,
            "entropy_loss": entropy_loss,
        }
        metrics = {}
        return losses, metrics

    def compute_returns(self, bootstrap_value, rewards, terminals):
        """Compute the returns from the nstep rollout

        Parameters
        ----------
        bootstrap_value : int
            initial value for target return
        rewards :
            rewards
        terminals :
            terminal points

        Returns
        -------
        nstep_target_returns : Torch.tensor
            target returns
        """
        # First step of nstep reward target is estimated value of t+1
        target_return = bootstrap_value
        rollout_len = len(rewards)
        nstep_target_returns = []
        for i in reversed(range(rollout_len)):
            reward = rewards[i]
            terminal_mask = 1.0 - terminals[i].float()

            target_return = reward + (self.discount * target_return * terminal_mask)
            nstep_target_returns.append(target_return)

        # reverse lists
        nstep_target_returns = torch.stack(list(reversed(nstep_target_returns))).data

        return nstep_target_returns
