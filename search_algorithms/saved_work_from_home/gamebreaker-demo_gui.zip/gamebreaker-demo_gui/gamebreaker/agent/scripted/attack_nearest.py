import numpy as np
from adept.utils.util import DotDict
from pysc2.agents import base_agent
from pysc2.lib.actions import RAW_FUNCTIONS
from pysc2.lib.features import PlayerRelative


def dist(unit1, unit2):
    distance = np.sqrt((unit1.x - unit2.x) ** 2 + (unit1.y - unit2.y) ** 2)
    return distance


class AttackNearest(base_agent.BaseAgent):
    """
    Focus fires on lowest health opponent unit
    """

    def step(self, obs):
        super().step(obs)

        units_to_order = [
            unit.tag for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.SELF
        ]

        if len(units_to_order) == 0:
            return RAW_FUNCTIONS.no_op()

        avg_x = np.mean(
            [unit.x for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.SELF]
        )

        avg_y = np.mean(
            [unit.y for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.SELF]
        )

        ally_com = DotDict({"x": avg_x, "y": avg_y})

        enemy_units = [
            unit for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.ENEMY
        ]

        if len(enemy_units) > 0:
            enemy = enemy_units[np.argmin([dist(ally_com, a) for a in enemy_units])]
        else:
            enemy = DotDict({"x": 16, "y": 16})

        return RAW_FUNCTIONS.Attack_pt("now", units_to_order, (enemy.x, enemy.y))
