import numpy as np
from pysc2.agents import base_agent
from pysc2.lib.actions import RAW_FUNCTIONS
from pysc2.lib.features import PlayerRelative


class StimToDeath(base_agent.BaseAgent):
    def __init__(self):
        super().__init__()
        self.moving = False
        self.stimmed = False
        self.keep_going = False
        self.count = 0

    def reset(self):
        super().reset()
        self.moving = False
        self.stimmed = False
        self.keep_going = False
        self.count = 0

    def step(self, obs):
        super().step(obs)

        stim_units = [
            unit.tag for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.SELF
        ]

        print(
            np.sum(
                [
                    unit.health
                    for unit in obs.observation.raw_units
                    if unit.alliance == PlayerRelative.SELF
                ]
            ),
            obs.observation.raw_units[0].buff_id_0,
            obs.observation.raw_units[0].buff_duration_max,
        )

        x = np.mean(
            [unit.x for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.SELF]
        )

        y = np.mean(
            [unit.y for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.SELF]
        )

        self.count += 1

        if (abs(x - 18) <= 4 and abs(y - 18) <= 4) or not self.moving:
            self.moving = True
            return RAW_FUNCTIONS.Move_pt("now", stim_units, (0, 0))
        elif x <= 4 and y <= 4:
            return RAW_FUNCTIONS.Move_pt("now", stim_units, (18, 18))
        elif self.count % 1000 == 0:
            self.stimmed = True
            return RAW_FUNCTIONS.Effect_Stim_Marine_quick("now", stim_units)
        else:
            return RAW_FUNCTIONS.no_op()
