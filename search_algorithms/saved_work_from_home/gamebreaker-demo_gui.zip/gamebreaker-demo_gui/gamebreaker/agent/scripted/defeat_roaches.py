import time
from collections import OrderedDict

import numpy as np
from pysc2.agents import base_agent
from pysc2.lib import actions
from pysc2.lib import features
from pysc2.lib import units
from transitions import Machine

_PLAYER_SELF = features.PlayerRelative.SELF
_PLAYER_NEUTRAL = features.PlayerRelative.NEUTRAL  # beacon/minerals
_PLAYER_ENEMY = features.PlayerRelative.ENEMY

FUNCTIONS = actions.FUNCTIONS
RAW_FUNCTIONS = actions.RAW_FUNCTIONS

MAX_MARINE_HEALTH = 45


class AttackRoachWithLowestHealth(base_agent.BaseAgent):
    """An agent specifically for solving DefeatRoaches using raw actions."""

    def setup(self, obs_spec, action_spec):
        super().setup(obs_spec, action_spec)
        if "raw_units" not in obs_spec:
            raise Exception("This agent requires the raw_units observation.")

    def step(self, obs):
        super().step(obs)

        marines = [unit for unit in obs.observation.raw_units if unit.alliance == _PLAYER_SELF]
        roaches = [unit for unit in obs.observation.raw_units if unit.alliance == _PLAYER_ENEMY]

        if not marines or not roaches:
            return FUNCTIONS.no_op()

        marines_com = np.mean(np.array([(m.x, m.y) for m in marines]), axis=0)
        roaches_com = np.mean(np.array([(r.x, r.y) for r in roaches]), axis=0)

        sign = 1 if marines_com[1] < roaches_com[1] else -1

        # Find the roach with minimum health; prefer roaches with lower values of y
        target = sorted(roaches, key=lambda r: r.health + sign * 1e-5 * r.y)[0].tag
        return RAW_FUNCTIONS.Attack_unit("now", [m.tag for m in marines], target)


class _MoonwalkInfo(object):
    states = ["escape", "return"]

    def __init__(self, marine, agent):
        self.marine = marine
        self.agent = agent
        self.escape_countdown = 30
        self.done = False
        self.action = None
        self.fsm = Machine(model=self, states=_MoonwalkInfo.states, initial="escape")
        self.fsm.add_transition(
            "step",
            "escape",
            "escape",
            conditions=lambda: not self.success_on_escape(),
            before=self.on_escape,
        )
        self.fsm.add_transition(
            "step", "escape", "return", conditions=self.success_on_escape, after=self.on_return,
        )

    def success_on_escape(self):
        return self.escape_countdown <= 0

    def on_escape(self):
        # We've already told the marine what to do; don't repeat ourselves
        if self.action is not None:
            self.action = FUNCTIONS.no_op()
            return

        # Find where the roaches are
        roaches_com = np.mean(np.array([(r.x, r.y) for r in self.agent.roaches.values()]), axis=0)

        # Find where the marine is
        marine_xy = np.array([self.marine.x, self.marine.y], dtype=np.float32)

        # Find a position that's directly in the opposite direction of the roaches
        unit_dir = marine_xy - roaches_com
        unit_dir /= np.linalg.norm(unit_dir)

        target_pos = np.maximum(np.array(marine_xy + 10 * unit_dir, dtype=np.int32), np.zeros(2))

        self.action = RAW_FUNCTIONS.Move_pt("now", [self.marine.tag], target_pos)

    def on_return(self):
        self.action = RAW_FUNCTIONS.Attack_unit(
            "now", [self.marine.tag], self.agent.cur_target_roach
        )
        self.done = True

    def tick(self):
        if self.state == "escape":
            self.escape_countdown -= 1


class _MarchStraightAndAttackFsm(object):
    states = ["march_straight", "attack"]

    def __init__(self):
        self.reset()

    def reset(self):
        self._fsm = Machine(
            model=self, states=_MarchStraightAndAttackFsm.states, initial="march_straight",
        )

        self._fsm.add_transition(
            "step",
            "march_straight",
            "march_straight",
            conditions=lambda: not self.success_march_straight(),
            before=self.on_march_straight,
        )

        self._fsm.add_transition(
            "step", "march_straight", "attack", conditions=self.success_march_straight,
        )

        self._fsm.add_transition(
            "step", "attack", "attack", after=self.on_attack,
        )

        self.action = None
        self.dest_map = {}
        self.march_direction = 0

        self.moonwalk_info = None
        self.has_moonwalked = set()

        self.cur_target_roach = None
        self.prev_target_roach = None

        self.started = False

    def inform_obs(self, obs):
        self.obs = obs
        self.marines = OrderedDict(
            [
                (unit.tag, unit)
                for unit in obs.observation.raw_units
                if unit.alliance == _PLAYER_SELF
            ]
        )
        self.n_marines = len(self.marines)

        self.roaches = OrderedDict(
            [
                (unit.tag, unit)
                for unit in obs.observation.raw_units
                if unit.alliance == _PLAYER_ENEMY
            ]
        )

        self.started = True

    def on_march_straight(self):
        # Don't do anything if we don't have a battle to fight
        if not self.marines or not self.roaches:
            self.action = FUNCTIONS.no_op()
            return

        # Determine whether we should march left or right
        if not self.march_direction:
            initial_marine_com = np.mean(
                np.array([(m.x, m.y) for m in self.marines.values()], dtype=np.float32,), axis=0,
            )
            initial_roach_com = np.mean(
                np.array([(r.x, r.y) for r in self.roaches.values()], dtype=np.float32,), axis=0,
            )

            self.march_direction = 1 if initial_marine_com[0] < initial_roach_com[0] else -1

            self.march_dist = 0.7 * np.linalg.norm(initial_marine_com - initial_roach_com)

            self.dest_map = {
                marine_tag: {
                    "dest": (meta.x + self.march_direction * self.march_dist, meta.y,),
                    "action_given": False,
                }
                for marine_tag, meta in self.marines.items()
            }

        for marine_tag, meta in self.dest_map.items():
            if not meta["action_given"]:
                self.action = RAW_FUNCTIONS.Move_pt("now", marine_tag, meta["dest"])
                meta["action_given"] = True
                return

        self.action = FUNCTIONS.no_op()

    def success_march_straight(self):
        if not self.dest_map or not self.marines or not self.roaches:
            return False

        for marine_tag, meta in self.dest_map.items():
            # A roach kills the marine as it's marching
            if marine_tag not in self.marines:
                continue

            actual = np.array(
                [self.marines[marine_tag].x, self.marines[marine_tag].y], dtype=np.float32,
            )
            expected = np.array(meta["dest"], dtype=np.float32)

            if np.linalg.norm(actual - expected) > 2.0:
                return False
        return True

    def compute_target_roach(self):
        marines_com = np.mean(
            np.array([(m.x, m.y) for m in self.marines.values()], dtype=np.float32,), axis=0,
        )
        roaches_com = np.mean(
            np.array([(r.x, r.y) for r in self.roaches.values()], dtype=np.float32,), axis=0,
        )

        sign = 1 if marines_com[1] < roaches_com[1] else -1

        # Find the roach with minimum health; prefer roaches with better y position to
        # get a slightly better flank
        return sorted(list(self.roaches.values()), key=lambda r: r.health + sign * 1e-5 * r.y,)[
            0
        ].tag

    def on_attack_moonwalk(self):
        # A marine is in the middle of moonwalking; so continue
        if self.moonwalk_info and not self.moonwalk_info.done:
            self.moonwalk_info.step()
            self.action = self.moonwalk_info.action
            return

        # If no marine is moonwalking, determine whether it makes sense to moonwalk
        if len(self.marines) <= 2:
            self.action = FUNCTIONS.no_op()
            return

        # Find the marine with the lowest health that hasn't moonwalked
        candidate_moonwalkers = [
            item
            for item in list(self.marines.items())
            if item[1].tag not in self.has_moonwalked and item[1].health < 0.5 * MAX_MARINE_HEALTH
        ]

        if len(candidate_moonwalkers) == 0:
            self.action = FUNCTIONS.no_op()
            return

        marine = sorted(candidate_moonwalkers, key=lambda item: item[1].health)[0][1]

        # If the selected marine hasn't taken damage, don't moonwalk
        if marine.health == MAX_MARINE_HEALTH:
            self.action = FUNCTIONS.no_op()
            return

        # Take record of the fact that a marine is moonwalking
        self.moonwalk_info = _MoonwalkInfo(marine, self)
        self.moonwalk_info.step()
        self.has_moonwalked.add(marine.tag)
        self.action = self.moonwalk_info.action

    def on_attack_attack(self):
        # Don't ask the moonwalking marine to attack
        marines_to_attack = [m.tag for m in self.marines.values()]

        if self.moonwalk_info:
            if self.moonwalk_info.marine.tag in marines_to_attack:
                marines_to_attack.remove(self.moonwalk_info.marine.tag)

        if len(marines_to_attack) > 0:
            self.action = RAW_FUNCTIONS.Attack_unit("now", marines_to_attack, self.cur_target_roach)
        else:
            self.action = FUNCTIONS.no_op()

    def on_attack(self):
        if not self.marines or not self.roaches:
            self.action = FUNCTIONS.no_op()
            return

        self.cur_target_roach = self.compute_target_roach()

        # If we don't have a target roach, or the current target roach is no longer the
        # previous target roach, then specify an attack command. We do this because we
        # only want to provide an attack command once. This frees time for marines to
        # moonwalk.
        if self.prev_target_roach and self.cur_target_roach == self.prev_target_roach:
            self.on_attack_moonwalk()
            if self.action == FUNCTIONS.no_op():
                self.on_attack_attack()
        else:
            self.on_attack_attack()

        if self.moonwalk_info:
            self.moonwalk_info.tick()

        self.prev_target_roach = self.cur_target_roach


class MarchStraightAndAttack(base_agent.BaseAgent):
    def setup(self, obs_spec, action_spec):
        super().setup(obs_spec, action_spec)
        if "raw_units" not in obs_spec:
            raise Exception("This agent requires the raw_units observation.")

    def reset(self):
        super().reset()
        self.reset_internal()

    def reset_internal(self):
        self.fsm = _MarchStraightAndAttackFsm()
        self.n_prev_marines = 0
        self.n_prev_roaches = 0

    def step(self, obs, env=None):
        time.sleep(0.1)
        super().step(obs)

        self.fsm.inform_obs(obs)

        # The DefeatRoaches environment is a little strange, since the game doesn't reset
        # even once there's a winner. Weirdly, for some reason, the number of marines can
        # touch 0, but the number of roaches can never touch 0. Let's detect such "soft"
        # resets by checking whether the number of marines / roaches on the previous step
        # is greater than the number of marines / roaches on the current step. If so,
        # let's reset our internal fsm.
        if (
            len(self.fsm.roaches) > self.n_prev_roaches
            or len(self.fsm.marines) > self.n_prev_marines
        ):
            self.reset_internal()
            self.fsm.inform_obs(obs)

        self.n_prev_marines = len(self.fsm.marines)
        self.n_prev_roaches = len(self.fsm.roaches)

        while not self.fsm.action:
            self.fsm.step()
        action = self.fsm.action
        self.fsm.action = None

        return action
