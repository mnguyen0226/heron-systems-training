import networkx as nx
import numpy as np
from adept.utils.util import DotDict
from pysc2.agents import base_agent
from pysc2.lib import units
from pysc2.lib.actions import RAW_FUNCTIONS
from pysc2.lib.features import PlayerRelative
from sklearn.cluster import KMeans

PSI_STORM_ENERGY = 75
MAX_DISTANCE = 10000


class StormProtoss(base_agent.BaseAgent):
    def __init__(self, map_size=(60, 60)):
        super().__init__()
        self.corners = [
            DotDict({"x": x, "y": y}) for x in [0, map_size[0]] for y in [0, map_size[1]]
        ]
        self.last_action = None
        self.storm_commands = []
        self.storm_issued = False

    def reset(self):
        self.last_action = None
        self.storm_commands = []
        self.storm_issued = False

    def step(self, obs):
        super().step(obs)

        allied_units = [
            unit for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.SELF
        ]

        high_templars = [
            unit for unit in allied_units if unit.unit_type == units.Protoss.HighTemplar
        ]

        if len(high_templars) == 0:
            self.last_action = "attack"

        psi_storm_units = [unit for unit in high_templars if unit.energy >= PSI_STORM_ENERGY]

        enemies = [
            unit for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.ENEMY
        ]

        if len(enemies) == 0 or len(allied_units) == 0:
            return RAW_FUNCTIONS.no_op()

        # Storm interrupts to the state machine
        if (len(psi_storm_units) > 0 or self.last_action == "storm") and not self.storm_issued:
            if self.last_action in [None, "move", "hold", "attack"]:
                self.storm_commands = self._get_storm_commands(psi_storm_units, enemies)
                self.last_action = "storm"
                return self.storm_commands.pop()
            elif len(self.storm_commands) > 0:
                self.last_action = "storm"
                while True:
                    action = self.storm_commands.pop()
                    target_units = action[1][1]
                    our_units = [unit.tag for unit in allied_units]
                    if all(t_unit in our_units for t_unit in target_units):
                        return action
                    elif len(self.storm_commands) == 0:
                        self.storm_issued = True
                        break
            else:
                self.storm_issued = True

        if self.storm_issued:
            if len(psi_storm_units) == 0:
                self.storm_issued = False

            if self.last_action == "storm":
                self.last_action = "move"
                return RAW_FUNCTIONS.Move_pt(
                    "queued", [unit.tag for unit in high_templars], self._get_move_point(enemies),
                )

        # The regular state machine
        if self.last_action is None:
            self.last_action = "move"
            return RAW_FUNCTIONS.Move_pt(
                "now", [unit.tag for unit in high_templars], self._get_move_point(enemies),
            )

        elif self.last_action == "move":
            self.last_action = "hold"
            return RAW_FUNCTIONS.HoldPosition_quick("queued", [unit.tag for unit in high_templars])

        elif self.last_action == "hold" or self.last_action == "attack":
            self.last_action = "attack"
            attack_units = [
                unit.tag for unit in allied_units if unit.unit_type != units.Protoss.HighTemplar
            ]
            if len(attack_units) == 0:
                return RAW_FUNCTIONS.no_op()

            lowest_health_enemy = np.argmin([unit.health for unit in enemies])
            return RAW_FUNCTIONS.Attack_unit(
                "now", attack_units, enemies[int(lowest_health_enemy)].tag
            )

    def _get_storm_commands(self, psi_storm_units, enemies):
        if len(psi_storm_units) < 1:
            return []
        # Where are the optimal storm placements? Use K-means to determine storm
        # destination.
        storm_locs = (
            KMeans(n_clusters=min(len(psi_storm_units), len(enemies)))
            .fit(np.asarray([(unit.x, unit.y) for unit in enemies]))
            .cluster_centers_
        )

        # Match each unit to a storm destination...
        templar_xy = np.array([(unit.x, unit.y) for unit in psi_storm_units])

        # ... we do this by identifying a matching which minimizes the sum of the
        # distances from the templars to the storm locations.
        g = nx.Graph()
        for templar_ix in range(len(templar_xy)):
            for storm_loc_ix in range(len(storm_locs)):
                dist = MAX_DISTANCE - np.linalg.norm(
                    templar_xy[templar_ix] - storm_locs[storm_loc_ix]
                )
                g.add_edge(
                    f"t_{templar_ix}", f"s_{storm_loc_ix}", weight=dist,
                )

        matching = [sorted(e)[::-1] for e in list(nx.algorithms.matching.max_weight_matching(g))]

        psi_storm_commands = []
        # Once we've identified the matching, populate the action_map...
        for templar_match, storm_match in matching:
            templar_tag = psi_storm_units[int(templar_match[templar_match.find("_") + 1 :])].tag
            storm_loc = storm_locs[int(storm_match[storm_match.find("_") + 1 :])]

            psi_storm_commands.append(
                RAW_FUNCTIONS.Effect_PsiStorm_pt("now", [templar_tag], storm_loc)
            )

        return psi_storm_commands

    def _get_move_point(self, enemies):
        enemy_position = np.mean([(unit.x, unit.y) for unit in enemies], axis=0)
        move_point = self.corners[
            int(
                np.argmax(
                    [
                        ((corner.x - enemy_position[0]) ** 2 + (corner.y - enemy_position[1]) ** 2)
                        ** (1 / 2)
                        for corner in self.corners
                    ]
                )
            )
        ]
        return move_point.x, move_point.y
