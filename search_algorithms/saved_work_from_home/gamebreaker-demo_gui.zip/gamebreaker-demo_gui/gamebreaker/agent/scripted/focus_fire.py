from pysc2.agents import base_agent
from pysc2.lib.actions import RAW_FUNCTIONS
from pysc2.lib.features import PlayerRelative


class FocusFire(base_agent.BaseAgent):
    """
    Focus fires on lowest health opponent unit
    """

    def step(self, obs):
        super().step(obs)

        units_to_order = [
            unit.tag for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.SELF
        ]

        units_to_attack = [
            unit for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.ENEMY
        ]

        if len(units_to_order) == 0:
            return RAW_FUNCTIONS.no_op()

        return RAW_FUNCTIONS.Attack_pt(
            "now", units_to_order, self._find_lowest_health(units_to_attack)
        )

    def _find_lowest_health(self, units_list):
        min_unit = None
        for unit in units_list:
            if (min_unit is None) or (unit.health < min_unit.health):
                min_unit = unit
        if min_unit is not None:
            return min_unit.x, min_unit.y
        else:
            return 16, 16
