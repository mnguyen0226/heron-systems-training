# Copyright (C) 2020 Heron Systems, Inc.
import networkx as nx
import numpy as np
from pysc2.agents import base_agent
from pysc2.lib import units
from pysc2.lib.actions import RAW_FUNCTIONS
from pysc2.lib.features import PlayerRelative
from sklearn.cluster import KMeans


class DoNothing(base_agent.BaseAgent):
    def step(self, obs):
        return RAW_FUNCTIONS.no_op()


class MoveToDestination(base_agent.BaseAgent):
    def __init__(self, destination=(0, 0)):
        super().__init__()
        self.destination = destination

    def step(self, obs):
        super().step(obs)

        units_to_order = [
            unit.tag for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.SELF
        ]

        return (
            RAW_FUNCTIONS.Move_pt("now", units_to_order, self.destination)
            if units_to_order
            else RAW_FUNCTIONS.no_op()
        )


class AttackAtDestination(base_agent.BaseAgent):
    def __init__(self, destination=(0, 0)):
        super().__init__()
        self.destination = destination

    def step(self, obs):
        super().step(obs)

        units_to_order = [
            unit.tag for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.SELF
        ]

        return (
            RAW_FUNCTIONS.Attack_pt("now", units_to_order, self.destination)
            if units_to_order
            else RAW_FUNCTIONS.no_op()
        )


class QueueExample(base_agent.BaseAgent):
    def __init__(self):
        super().__init__()
        self.actions = 0

    def step(self, obs):
        super().step(obs)
        allied_units = [
            unit.tag for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.SELF
        ]
        if self.actions == 0:
            self.actions += 1
            return RAW_FUNCTIONS.HoldPosition_quick("now", allied_units)
        elif self.actions == 1:
            self.actions += 1
            return RAW_FUNCTIONS.Move_pt("queued", allied_units, (28, 0))
        else:
            return RAW_FUNCTIONS.no_op()

    def reset(self):
        super().reset()
        self.actions = 0


class StormAtDestination(base_agent.BaseAgent):
    PSI_STORM_ENERGY = 75
    MAX_DISTANCE = 10000

    def __init__(self, destination=(0, 0)):
        super().__init__()
        self.destination = destination

    def step(self, obs):
        super().step(obs)

        # Select all high templars
        high_templars = [
            unit
            for unit in obs.observation.raw_units
            if unit.alliance == PlayerRelative.SELF
            and units.get_unit_type(unit.unit_type) == units.Protoss.HighTemplar
        ]

        # High templars with enough energy to psi storm
        high_templars_with_enough_energy = [
            unit for unit in high_templars if unit.energy >= StormAtDestination.PSI_STORM_ENERGY
        ]

        # Get enemy locations
        enemies = np.array(
            [
                (unit.x, unit.y)
                for unit in obs.observation.raw_units
                if unit.alliance == PlayerRelative.ENEMY
            ]
        )

        # If either templars have no energy or we don't see any enemies, then issue an
        # attack command towards the destination.
        if len(high_templars_with_enough_energy) == 0 or len(enemies) == 0:
            return RAW_FUNCTIONS.Attack_pt(
                "now", [unit.tag for unit in high_templars], self.destination
            )

        # Pre-fill the action map
        action_map = {
            unit.tag: RAW_FUNCTIONS.Attack_pt("now", [unit.tag], self.destination)
            for unit in high_templars
        }

        # Where are the optimal storm placements? Use K-means to determine storm
        # destination.
        storm_locs = (
            KMeans(n_clusters=min(len(high_templars_with_enough_energy), len(enemies)))
            .fit(enemies)
            .cluster_centers_
        )

        # Match each unit to a storm destination...
        templar_xy = np.array([(unit.x, unit.y) for unit in high_templars_with_enough_energy])

        # ... we do this by identifying a matching which minimizes the sum of the
        # distances from the templars to the storm locations.
        g = nx.Graph()
        for templar_ix in range(len(templar_xy)):
            for storm_loc_ix in range(len(storm_locs)):
                dist = StormAtDestination.MAX_DISTANCE - np.linalg.norm(
                    templar_xy[templar_ix] - storm_locs[storm_loc_ix]
                )
                g.add_edge(
                    f"t_{templar_ix}", f"s_{storm_loc_ix}", weight=dist,
                )

        matching = [sorted(e)[::-1] for e in list(nx.algorithms.matching.max_weight_matching(g))]

        # Once we've identified the matching, populate the action_map...
        for templar_match, storm_match in matching:
            templar_tag = high_templars_with_enough_energy[
                int(templar_match[templar_match.find("_") + 1 :])
            ].tag
            storm_loc = storm_locs[int(storm_match[storm_match.find("_") + 1 :])]

            action_map[templar_tag] = RAW_FUNCTIONS.Effect_PsiStorm_pt(
                "now", [templar_tag], storm_loc
            )

        # ... and return a randomly sampled action
        actions = list(action_map.values())

        return actions[int(np.random.rand() * len(actions))]
