import numpy as np
from adept.utils.util import DotDict
from pysc2.agents import base_agent
from pysc2.lib import units
from pysc2.lib.actions import RAW_FUNCTIONS
from pysc2.lib.features import PlayerRelative
from pysc2.lib.upgrades import Upgrades

from gamebreaker.unit_data import unit_data


def dist(unit1, unit2):
    distance = np.sqrt((unit1.x - unit2.x) ** 2 + (unit1.y - unit2.y) ** 2)
    return distance


def get_directions(unit, enemy_units, velocities):
    if len(enemy_units) == 0:
        return velocities

    directions = []
    threshold = 0
    while len(directions) == 0:
        directions = [
            direction
            for direction in velocities
            if not any(
                dist(direction, enemy) <= dist(unit, enemy) + threshold for enemy in enemy_units
            )
        ]
        threshold += 0.01

    return directions


# Goal of the Kiting Enemy should be to keep enemy just at its attack range
class KiteEnemy(base_agent.BaseAgent):
    """
    Shoots while walking away from the enemy's center of mass
    """

    def __init__(self, map_size=(60, 60), radius=5, nb_directions=16):
        super().__init__()

        self.map_center = DotDict({"x": map_size[0] // 2, "y": map_size[1] // 2})
        self.velocities = [
            DotDict(
                {
                    "x": radius * np.cos(np.pi * n / nb_directions),
                    "y": radius * np.sin(np.pi * n / nb_directions),
                }
            )
            for n in range(nb_directions)
        ]

        self.count = 0
        self.allied_units = []
        self.unit_dict = {}
        self.stop = False
        self.unit_groups = None

    def _unit_isnt_moving(self, unit):
        if unit.tag not in self.unit_dict:
            return True
        prev_x, prev_y = self.unit_dict[unit.tag]["prev_pos"]
        velocity = (unit.x - prev_x, unit.y - prev_y)
        return not any(velocity)

    def _update_unit_list(self, allied_units):
        for unit in allied_units:
            self.unit_dict[unit.tag] = {
                "prev_pos": (unit.x, unit.y),
            }

    def _find_unit_direction(self, unit, enemy_units):
        # Want to:
        # 1. maximize distance from the nearest enemies
        # 2. maximize distance from further enemies
        # 3. maximize distance from walls

        # Determine every position the unit could go to
        positions = [
            DotDict({"x": unit.x + velocity.x, "y": unit.y + velocity.y})
            for velocity in self.velocities
        ]

        # Account for the fact that the unit cannot go "out of bounds"
        positions = [
            DotDict(
                {
                    "x": max([1, min([position.x, 2 * self.map_center.x - 1])]),
                    "y": max([1, min([position.y, 2 * self.map_center.y - 1])]),
                }
            )
            for position in positions
        ]

        # Remove positions that are too close to the current position
        small_positions = [
            position
            for position in positions
            if abs(unit.x - position.x) > 0.5 or abs(unit.y - position.y) > 1
        ]

        # Remove positions that are too close to the edge of the map
        small_positions = [
            position
            for position in small_positions
            if dist(position, self.map_center) <= self.map_center.x
        ]

        # Group the enemy and get their center of masses
        enemy_groups = self._group_units(enemy_units)
        enemy_coms = [
            DotDict(
                {
                    "x": np.mean([enemy.x for enemy in group]),
                    "y": np.mean([enemy.y for enemy in group]),
                }
            )
            for group in enemy_groups
        ]

        # Find the closest enemy groups
        enemy_index = np.argmin([dist(unit, group) for group in enemy_coms])

        closest_enemy = enemy_coms[int(enemy_index)]

        # print(dist(unit, closest_enemy))
        if len(small_positions) < 1:
            small_positions = [self.map_center]

        best_index = np.argmax([dist(position, closest_enemy) for position in small_positions])

        best_position = positions[best_index]
        return best_position.x, best_position.y

    @staticmethod
    def _group_units(unit_list):
        unit_groups = {}
        for unit in unit_list:
            if unit.unit_type not in unit_groups:
                unit_groups[unit.unit_type] = [unit]
            else:
                unit_groups[unit.unit_type].append(unit)
        unit_types = [tag for tag in unit_groups]
        unit_types.sort()

        if len(unit_types) > 1:
            unit_groups = [unit_groups[unit_type] for unit_type in unit_types]
        else:
            n = len(unit_list)
            unit_groups = [
                unit_list[0 : n // 3],
                unit_list[n // 3 : 2 * n // 3],
                unit_list[2 * n // 3 :],
            ]
        return unit_groups

    def _update_groups(self, unit_list):
        return_groups = []
        for group in self.unit_groups:
            tag_list = [unit.tag for unit in group]

            temp = [unit for unit in unit_list if unit.tag in tag_list]
            return_groups.append(temp)
        return return_groups

    def _determine_unit_order(self, enemy_units, upgrades):
        # Group all the units by type
        if self.unit_groups is None:
            self.unit_groups = self._group_units(self.allied_units)
        else:
            self.unit_groups = self._update_groups(self.allied_units)

        # Determine if any of the groups needs priority
        interrupt_groups = [
            group for group in self.unit_groups if all(unit.order_length == 0 for unit in group)
        ]

        # We have a group with urgent need for attention
        if len(interrupt_groups) > 0:
            group = interrupt_groups[0]
        else:
            group = self.unit_groups[self.count % len(self.unit_groups)]

        if len(group) == 0:
            return RAW_FUNCTIONS.no_op()

        ally_center_of_mass = DotDict(
            {"x": np.mean([unit.x for unit in group]), "y": np.mean([unit.y for unit in group]),}
        )

        if len(enemy_units) == 0:
            return RAW_FUNCTIONS.Move_pt(
                "now", [unit.tag for unit in group], (self.map_center.x, self.map_center.y),
            )

        enemy = enemy_units[np.argmin([dist(ally_center_of_mass, a) for a in enemy_units])]

        if (
            any(
                unit.buff_id_0 == 0
                for unit in group
                if (
                    unit.unit_type == units.Terran.Marine or unit.unit_type == units.Terran.Marauder
                )
            )
            and Upgrades.Stimpack in upgrades
        ):
            return RAW_FUNCTIONS.Effect_Stim_Marine_quick(
                "now",
                [
                    unit.tag
                    for unit in group
                    if (
                        unit.unit_type == units.Terran.Marine
                        or unit.unit_type == units.Terran.Marauder
                    )
                ],
            )

        elif any(unit.weapon_cooldown == 0 for unit in group):
            target = self._find_lowest_health(enemy_units, enemy)

            order = RAW_FUNCTIONS.Attack_unit(
                "now",
                [unit.tag for unit in group if unit.weapon_cooldown == 0],
                target if target is not None else enemy,
            )
        elif self._unit_isnt_moving(ally_center_of_mass):
            order = RAW_FUNCTIONS.Move_pt(
                "now",
                [unit.tag for unit in group],
                (self._find_unit_direction(ally_center_of_mass, enemy_units)),
            )
        else:
            order = RAW_FUNCTIONS.no_op()

        return order

    @staticmethod
    def _find_lowest_health(units_list, min_unit=None):
        for unit in units_list:
            if (min_unit is None) or (unit.health < min_unit.health):
                min_unit = unit
        return min_unit.tag

    def step(self, obs):
        super().step(obs)

        self.allied_units = [
            unit for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.SELF
        ]

        enemy_units = [
            unit for unit in obs.observation.raw_units if unit.alliance == PlayerRelative.ENEMY
        ]

        order = self._determine_unit_order(enemy_units, obs.observation.upgrades)
        self._update_unit_list(self.allied_units)
        self.count += 1
        return order

    def reset(self):
        super().reset()

        self.count = 0
        self.allied_units = []
        self.unit_dict = {}
        self.stop = False
        self.unit_groups = None
