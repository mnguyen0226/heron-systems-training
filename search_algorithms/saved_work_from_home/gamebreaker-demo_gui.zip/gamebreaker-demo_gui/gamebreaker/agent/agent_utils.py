from typing import List

import torch
from pysc2.lib.features import FeatureUnit
from pysc2.lib.features import PlayerRelative

from gamebreaker.env.base import ObsIdx
from gamebreaker.env.base.obs_utils import bin_to_cat


def find_alliance(unit: torch.Tensor):
    """Find alliance of unit

    Parameters
    ----------
    unit : torch.Tensor
        tensor for unit observation

    Returns
    -------
    PlayerRelative
        enumerated alliance of unit
    """
    return PlayerRelative(bin_to_cat(unit, 3, start_idx=ObsIdx.alliance_bit0))
