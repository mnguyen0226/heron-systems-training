AGENT_LIST = [
    "gamebreaker.agent.scripted.StormProtoss",
    "gamebreaker.agent.scripted.FocusFire",
    "gamebreaker.agent.scripted.KiteEnemy",
    "gamebreaker.agent.scripted.AttackNearest",
]
