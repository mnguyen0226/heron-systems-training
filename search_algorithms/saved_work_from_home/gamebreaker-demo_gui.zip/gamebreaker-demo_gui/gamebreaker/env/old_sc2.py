# Copyright (C) 2020 Heron Systems, Inc.
from collections import OrderedDict
from functools import reduce

import numpy as np
import torch
from adept.env.base.env_module import EnvModule
from adept.preprocess.observation import ObsPreprocessor
from adept.preprocess.ops import CastToFloat
from adept.preprocess.ops import FlattenSpace
from adept.preprocess.ops import Operation
from pysc2.env import environment
from pysc2.env.sc2_env import SC2Env
from pysc2.lib import features
from pysc2.lib.actions import FUNCTION_TYPES
from pysc2.lib.actions import FunctionCall
from pysc2.lib.actions import FUNCTIONS
from pysc2.lib.features import MINIMAP_FEATURES
from pysc2.lib.features import parse_agent_interface_format
from pysc2.lib.features import SCREEN_FEATURES
from pysc2.lib.static_data import UNIT_TYPES


class AdeptSC2Env(EnvModule):
    args = {}

    def __init__(self, env):
        """Creates an AdeptSC2Env

        Parameters
        ----------
        env : sc2_env.SC2Env
            environment to use for Adept
        """
        self.sc2_env = env
        self._max_num_actions = len(FUNCTIONS)
        observation_space = {
            # 'single_select': (1, 7),
            # 'multi_select': ,
            # 'build_queue': ,
            # 'cargo': ,
            # 'cargo_slots_available': (1,),
            "screen": (24, 84, 84),
            # 'player': (11,),
            "control_groups": (10, 2),
            "available_actions": (self._max_num_actions,),
        }
        observation_dtypes = {
            "screen": torch.int16,
            "control_groups": torch.int32,
            "available_actions": torch.int32,
        }
        action_space = {
            "func_id": (524,),
            "screen_x": (84,),
            "screen_y": (84,),
            "minimap_x": (84,),
            "minimap_y": (84,),
            "screen2_x": (84,),
            "screen2_y": (84,),
            "queued": (2,),
            "control_group_act": (4,),
            "control_group_id": (10,),
            "select_point_act": (4,),
            "select_add": (2,),
            "select_unit_act": (4,),
            "select_unit_id": (500,),
            "select_worker": (4,),
            "unload_id": (500,),
            "build_queue_id": (10,),
        }
        # remove_feat_op = SC2RemoveFeatures({'player_id'})
        cpu_preprocessor = ObsPreprocessor(
            [FlattenSpace({"control_groups"})], observation_space, observation_dtypes,
        )

        gpu_preprocessor = SC2RemoveAvailableActions(
            [CastToFloat(), SC2ScaleChannels(24)],
            # [CastToFloat({'control_groups'}), SC2OneHot()],
            cpu_preprocessor.observation_space,
            cpu_preprocessor.observation_dtypes,
        )
        self._func_id_to_headnames = SC2ActionLookup()
        super(AdeptSC2Env, self).__init__(action_space, cpu_preprocessor, gpu_preprocessor)

    @classmethod
    def from_args(
        cls, args, seed, sc2_replay_dir=None, sc2_render=False,
    ):
        """Class factory constructor from arguments

        Parameters
        ----------
        args : Dict
            Arguments
        seed : int
            Random seed to use
        sc2_replay_dir : string, optional
            directory to save the replays to, by default None
        sc2_render : bool, optional
            whether or not to render the env, by default False

        Returns
        -------
        env
            The created AdeptSC2Env
        """
        agent_interface_format = parse_agent_interface_format(
            feature_screen=84, feature_minimap=84, action_space="FEATURES"
        )
        env = SC2Env(
            map_name=args.env,
            step_mul=8,
            game_steps_per_episode=0,
            discount=0.99,
            agent_interface_format=agent_interface_format,
            random_seed=seed,
            save_replay_episodes=1 if sc2_replay_dir is not None else 0,
            replay_dir=sc2_replay_dir,
            visualize=sc2_render,
        )
        env = AdeptSC2Env(env)
        return env

    def step(self, action):
        """Step the environment and execute the actions, then update the env

        Parameters
        ----------
        action : Tuple[FunctionCall]
            the actions to perform

        Returns
        -------
        Tuple[Timestep, float, boolean, Dict[String, int]]
            The observation, reward, whether the env is done, and the results info
        """
        timesteps = self.sc2_env.step(self._wrap_action(action))
        # pysc2 returns a tuple of timesteps, with one timestep inside
        # get first timestep
        pysc2_step = timesteps[0]
        reward = float(pysc2_step.reward)
        done = info = pysc2_step.step_type == environment.StepType.LAST
        return (
            self.cpu_preprocessor(self._wrap_observation(pysc2_step.observation)),
            reward,
            done,
            info,
        )

    def reset(self):
        """Resets the sc2 environment

        Returns
        -------
        Timestep with a reset env
        """
        timesteps = self.sc2_env.reset()
        assert len(timesteps) == 1
        # pysc2 returns a tuple of timesteps, with one timestep inside
        # get first timestep
        pysc2_step = timesteps[0]
        return self.cpu_preprocessor(self._wrap_observation(pysc2_step.observation))

    def close(self):
        """Closes the env"""
        self.sc2_env.close()

    def _wrap_observation(self, observation):
        """Wraps the observation using torch

        Parameters
        ----------
        observation :
            observations of the environment

        Returns
        -------
        obs : OrderedDict
            wrapped observation data
        """
        obs = OrderedDict()
        obs["screen"] = torch.cat(
            [
                torch.from_numpy(observation["feature_screen"]),
                torch.from_numpy(observation["feature_minimap"]),
            ]
        )
        obs["control_groups"] = torch.from_numpy(observation["control_groups"])
        avail_actions_one_hot = np.zeros(self._max_num_actions, dtype=np.int64)
        avail_actions_one_hot[observation["available_actions"]] = 1
        obs["available_actions"] = torch.from_numpy(avail_actions_one_hot)
        return obs

    def _wrap_action(self, action):
        """Wraps the action

        Parameters
        ----------
        action :
            the action to wrap

        Returns
        -------
        List
            The wrapped action call
        """
        func_id = action["func_id"].item()
        required_heads = self._func_id_to_headnames[func_id]
        args = []

        for headname in required_heads.keys():
            if "_y" in headname:
                continue
            elif "_x" in headname:
                args.append(
                    [action[headname].item(), action[headname[:-2] + "_y"].item(),]
                )
            else:
                args.append([action[headname].item()])

        return [FunctionCall(func_id, args)]


class SC2RemoveFeatures(Operation):
    def __init__(self, feats_to_remove, feats=SCREEN_FEATURES + MINIMAP_FEATURES):
        """This class removes the specified indexes from the features

        Parameters
        ----------
        feats_to_remove : List[String]
            the features to remove
        feats : List, optional
            the list of features, by default SCREEN_FEATURES+MINIMAP_FEATURES
        """
        super(SC2RemoveFeatures, self).__init__({"screen"})

        self.idxs = []
        self.features = []

        for i, feat in enumerate(feats):
            if feat.name not in feats_to_remove:
                self.idxs.append(i)
                self.features.append(feat)

    def update_shape(self, old_shape):
        """Updates the shape

        Parameters
        ----------
        old_shape :
            the old shape

        Returns
        -------
        Returns the shape of the output tensor
        """
        return (len(self.idxs),) + old_shape[1:]

    def update_dtype(self, old_dtype):
        """Updates the data type

        Parameters
        ----------
        old_dtype :
            the old data type

        Returns
        -------
        Returns the data type of the output tensor
        """
        return old_dtype

    def update_obs(self, obs):
        if obs.dim() == 3:
            return obs[self.idxs]
        elif obs.dim() == 4:
            return obs.index_select(1, torch.LongTensor(self.idxs, device=obs.device))
        else:
            raise ValueError(
                "Cannot remove SC2 features from a {}-dimensional tensor".format(obs.dim())
            )


class SC2OneHot(Operation):
    def __init__(self, feats=SCREEN_FEATURES + MINIMAP_FEATURES):
        """This class performs one hot encoding for the features

        Parameters
        ----------
        feats : Tuple, optional
            the features of the env, by default SCREEN_FEATURES+MINIMAP_FEATURES
        """
        super(SC2OneHot, self).__init__({"screen"})

        self.features = []
        self._ranges_by_feature_idx = {}
        self._scalar_idxs = []

        for i, feat in enumerate(feats):
            if feat.type == features.FeatureType.SCALAR:
                self._scalar_idxs.append(i)
                self.features.append(feat)
            if feat.type == features.FeatureType.CATEGORICAL:
                if feat.name == "unit_type":
                    self._ranges_by_feature_idx[i] = UNIT_TYPES
                elif feat.name == "visibility":
                    self._ranges_by_feature_idx[i] = list(range(3))
                elif feat.name == "effects":
                    self._ranges_by_feature_idx[i] = list(range(1, 13))
                elif feat.scale == 2:
                    self._ranges_by_feature_idx[i] = [1]
                else:
                    self._ranges_by_feature_idx[i] = list(range(feat.scale))

        scales = []
        for i, feat in enumerate(feats):
            if feat.type == features.FeatureType.SCALAR:
                scales.append(feat.scale)
        self._scales = 1.0 / torch.tensor(scales).float()

    def update_dtype(self, old_dtype):
        """Update the data type

        Parameters
        ----------
        old_dtype :
            the old data type

        Returns
        -------
        torch.float32
            the type is always torch.float32
        """
        return torch.float32

    def update_shape(self, old_shape):
        """Update the shape

        Parameters
        ----------
        old_shape :
            the old shape

        Returns
        -------
        new shape
            The updated output shape of the operation
        """
        new_shape = (
            len(self._scalar_idxs)
            + len(reduce(lambda prev, cur: prev + cur, self._ranges_by_feature_idx.values(),)),
        ) + old_shape[1:]
        return new_shape

    def update_obs(self, obs):
        """Update the observation using the one hot encoding

        Parameters
        ----------
        obs :
            current environment observations

        Returns
        -------
        The observations with the one hot encoding appended

        Raises
        ------
        ValueError
            if the input tensor cannot be converted to a one-hot
        """
        if self._scales.device != obs.device:
            self._scales = self._scales.to(obs.device)
        # TODO: warning, this is really slow
        if obs.dim() == 3:
            one_hot_channels = []
            for i, rngs in self._ranges_by_feature_idx.items():
                for rng in rngs:
                    one_hot_channels.append(obs[i] == rng)
            obs = obs[self._scalar_idxs]
            one_hot_channels = torch.stack(one_hot_channels)
            result = torch.cat(
                [obs, one_hot_channels.to(one_hot_channels.device, dtype=torch.int32),]
            )
            return result
        elif obs.dim() == 4:
            one_hot_channels = []
            for i, rngs in self._ranges_by_feature_idx.items():
                for rng in rngs:
                    one_hot_channels.append(obs[:, i, :, :] == rng)
            one_hot_channels = torch.stack(one_hot_channels, dim=1)
            return torch.cat(
                [
                    obs[:, self._scalar_idxs, :, :].float() * self._scales.view(1, -1, 1, 1),
                    one_hot_channels.float(),
                ],
                dim=1,
            )
        elif obs.dim() == 5:  # seq, batch, channel, x, y
            one_hot_channels = []
            for i, rngs in self._ranges_by_feature_idx.items():
                for rng in rngs:
                    one_hot_channels.append(obs[:, :, i, :, :] == rng)
            one_hot_channels = torch.stack(one_hot_channels, dim=2)
            return torch.cat(
                [
                    obs[:, :, self._scalar_idxs, :, :].float() * self._scales.view(1, 1, -1, 1, 1),
                    one_hot_channels.float(),
                ],
                dim=2,
            )
        else:
            raise ValueError("Cannot convert {}-dimensional tensor to one-hot".format(obs.dim()))


class SC2ScaleChannels(Operation):
    def __init__(self, nb_channel, feats=SCREEN_FEATURES + MINIMAP_FEATURES, mode="all"):
        """Scales the features to a standard range

        Parameters
        ----------
        nb_channel : int
            number of channels for scales
        feats : tuple, optional
            the features of the env, by default SCREEN_FEATURES+MINIMAP_FEATURES
        mode : str, optional
            'all' or 'scalar' to decide which type of features to scale, by default "all"
        """
        super(SC2ScaleChannels, self).__init__({"screen"})
        scales = torch.ones(nb_channel)
        for i, feat in enumerate(feats):
            if mode == "all":
                scales[i] = feat.scale
            elif mode == "scalar":
                if feat.type == features.FeatureType.SCALAR:
                    scales[i] = feat.scale
        self.scales = 1.0 / scales.float()

    def update_shape(self, old_shape):
        """Updates the shape

        Parameters
        ----------
        old_shape :
            The old shape

        Returns
        -------
        old_shape
            the output shape remains the same
        """
        return old_shape

    def update_dtype(self, old_dtype):
        """Updates the datatype

        Parameters
        ----------
        old_dtype :
            the old datatype

        Returns
        -------
        torch.float32
            This always is a torch.float32
        """
        return torch.float32

    def update_obs(self, obs):
        """Updates the observation by scaling the features

        Parameters
        ----------
        obs :
            current environment observation

        Returns
        -------
        obs
            scaled environment observation

        Raises
        ------
        ValueError
            If the dimensions are not supported
        """
        obs = obs.float()

        if self.scales.device != obs.device:
            self.scales = self.scales.to(obs.device)

        if obs.dim() == 3:
            obs *= self.scales.view(-1, 1, 1)
            return obs
        elif obs.dim() == 4:
            obs *= self.scales.view(1, -1, 1, 1)
            return obs
        else:
            raise ValueError("Unsupported dimensionality " + str(obs.dim()))


class SC2RemoveAvailableActions(ObsPreprocessor):
    def __init__(self, ops, observation_space, observation_dtypes=None):
        """Removes available actions from a Preprocessor

        Parameters
        ----------
        ops : list
            List of operations
        observation_space : dict
            Dictionary of the observation space items
        observation_dtypes : dict, optional
            Dictionary of the observation space items datatypes, by default None
        """
        super().__init__(ops, observation_space, observation_dtypes)
        filtered_space = {k: v for k, v in observation_space.items() if k != "available_actions"}
        self.observation_space = filtered_space

    def __call__(self, obs):
        """Calls ObsPreprocessor's call method and returns unavailable actions

        Parameters
        ----------
        obs :
            the current environment observations

        Returns
        -------
        Dict
            The dictionary of unavailable actions
        """
        result = super().__call__(obs)
        return {k: v for k, v in result.items() if k != "available_actions"}


class SC2ActionLookup(dict):
    def __init__(self):
        """Looks up actions in the SC2 env"""
        super().__init__()
        for func in FUNCTIONS:
            func_id = func.id
            arg_names = [arg.name for arg in FUNCTION_TYPES[func.function_type]]
            self[func_id] = self._arg_names_to_head_names(arg_names)

    def _arg_names_to_head_names(self, arg_names):
        """Converts the argument names to head names

        Parameters
        ----------
        arg_names : list
            the argument names

        Returns
        -------
        OrderedDict
            The ordered dict for the headnames
        """
        headnames = []
        for argname in arg_names:
            if argname == "screen":
                headnames.extend(["screen_x", "screen_y"])
            elif argname == "minimap":
                headnames.extend(["minimap_x", "minimap_y"])
            elif argname == "screen2":
                headnames.extend(["screen2_x", "screen2_y"])
            else:
                headnames.append(argname)
        # OrderedDict for constant time membership test while preserving order
        # TODO make an OrderedSet in utils
        return OrderedDict.fromkeys(headnames)
