# Copyright (C) 2020 Heron Systems, Inc.
from collections import Counter
from typing import Dict
from typing import List
from typing import Tuple

from pysc2.env import sc2_env
from pysc2.lib import features
from pysc2.lib import units
from pysc2.lib.actions import FunctionCall
from pysc2.lib.actions import RAW_FUNCTIONS

from gamebreaker.data import upgrade_data
from gamebreaker.env.base import SC2DebugMixin
from gamebreaker.env.base.obs_utils import on_creep_map
from gamebreaker.selector import RandomUpgradeSelector
from gamebreaker.selector import Selector
from gamebreaker.selector import TerrainSelector


class MicroBattleEnv(sc2_env.SC2Env, SC2DebugMixin):
    OBSERVER_SEP = 4

    def __init__(
        self,
        world_size: Tuple[int, int],
        selectors: Tuple[Selector],
        upgrade_selectors: List[RandomUpgradeSelector],
        create_kill_timeout: int = 200,
        terrain_selector: TerrainSelector = None,
        save_replay_info: Dict[str, str] = None,
        *args,
        **kwargs,
    ):
        """Construct a micro battle environment. We only support 2 player-games, so
        selectors and upgrades must both have length 2.


        Parameters
        ----------
        world_size : Tuple[int, int]
            Size of the world to generate
        selectors : Tuple[Selector]
            selector[i] is used to create the units for army i.
        upgrade_selectors : List[UpgradeSelector]
            upgrade_selector[i] is used to choose the upgrades for army i
        create_kill_timeout : int, optional
            the number of steps to wait to initialize the environment on a soft reset, by default
            200
        terrain_selector : TerrainSelector, optional
             a TerrainSelector that generates terrain, by default None
        save_replay_info : Dict[str, str], optional
            a dictionary that should contain keys "replay_dir" and
            optionally "replay_prefix." If save_replay_info is not None, a replay will be
            saved under the directory $HOME/StarCraftII/replay_dir/ with a file name prefix
            of replay_prefix, followed by metadata. This field can be changed while the
            environment is active; the next time a replay is saved, it will be saved using
            the newly specified information, by default None
        """

        super().__init__(*args, **kwargs)

        self.world_size = world_size
        self.selectors = selectors
        self.upgrade_selectors = upgrade_selectors
        self.create_kill_timeout = create_kill_timeout
        self.terrain_selector = terrain_selector
        self.player_ids = list(range(self._num_agents))
        self.owner_ids = list(range(1, 1 + len(self._players)))
        self.n_players = len(self._players)
        self.player_units = None
        self.timestep = None
        self.save_replay_info = save_replay_info
        self._terrain_modifiers = []
        self._reset_called_at_least_once = False
        self._n_steps_since_hard_reset = 0
        self._n_steps_since_soft_reset = 0
        self._is_done = False

    @property
    def neutral_owner_id(self):
        """Returns the value for a neutral unit owner

        Returns
        -------
        0
            the value of a neutral unit
        """
        return 0

    def reset(self, hard_reset: bool = False):
        """Resets the sc2 environment

        This either performs a soft reset by removing all the units on the field, or performs a hard
        reset to completely clear the environment

        Parameters
        ----------
        hard_reset : bool, optional
            whether or not to hard reset the environment instance, by default False

        Returns
        -------
        the timestep with all units killed and created
        """
        if (
            hard_reset
            or self._n_steps_since_hard_reset >= sc2_env.MAX_STEP_COUNT
            or not self._reset_called_at_least_once
        ):
            self.timestep = super().reset()

            # Research all upgrades
            self._generate_upgrades()
            self._n_steps_since_hard_reset = 0

        # Save replays
        if self.save_replay_info and self._reset_called_at_least_once:
            self.save_replay(
                self.save_replay_info["replay_dir"],
                self.save_replay_info.get("replay_prefix", None),
            )

        self.player_units = [selector.select() for selector in self.selectors]
        self._terrain_modifiers = self.terrain_selector.select() if self.terrain_selector else []
        self._reset_called_at_least_once = True
        self._is_done = False
        self._n_steps_since_soft_reset = 0

        return self._kill_and_create()

    def step(
        self, actions: Tuple[FunctionCall], step_mul: int = None, setup_env: bool = False,
    ):
        """Step the environment and execute the actions, then update the env

        Parameters
        ----------
        actions : Tuple[FunctionCall]
            The actions to perform
        step_mul : int, optional
            the amount to multiply the amount that we step the environment by, by default None
        setup_env : bool, optional
            true if we are currently setting up the env, by default False

        Returns
        -------
        Tuple[Timestep, float, boolean, Dict[String, int]]
            The observation, reward, whether the env is done, and the result info

        Raises
        ------
        ValueError
            if step is called on an environment whose current episode has already terminated
        """
        if self._is_done and not setup_env:
            raise ValueError(
                "Trying to call step() on an environment whose current episode has "
                "already terminated."
            )

        self.timestep = super().step(actions, step_mul=step_mul)
        self.timestep = on_creep_map(self.timestep, self.world_size)
        assert len(self.timestep) == self.n_players

        # The game ends when there's at most one player left standing; note that there
        # could potentially be zero players left standing if two units left standing
        # on opposing teams time things perfectly and kill each each other off.
        is_alives = [len(self._unit_counts(player_id)) > 0 for player_id in self.player_ids]

        self._n_steps_since_hard_reset += 1
        self._n_steps_since_soft_reset += 1
        self._is_done = sum(is_alives) <= 1

        if not self._is_done and self._n_steps_since_soft_reset >= 500:
            self._is_done = True

        info = {}
        if self._is_done:
            if not is_alives[0] and is_alives[1]:
                # Blue lost
                info["result"] = 0
            elif is_alives[0] and not is_alives[1]:
                # Blue won
                info["result"] = 1
            else:
                # Draw
                info["result"] = 2

        # observation, reward, done, info
        return self.timestep, 0.0, self._is_done, info

    def _unit_counts(self, player_id: int):
        """Returns a count of the units

        Parameters
        ----------
        player_id : int
            id of the player to count units for

        Returns
        -------
        dict
            count of the units
        """
        return dict(
            Counter(
                [
                    units.get_unit_type(unit.unit_type)
                    for unit in self.timestep[player_id].observation.raw_units
                    if unit.alliance == features.PlayerRelative.SELF
                ]
            )
        )

    def _wait_until(self, condition_fn, timeout_steps):
        """Wait at most timeout_steps for condition_fn to evaluate to true.

        Parameters
        ----------
        condition_fn :
            The condition we are checking the validity ofk
        timeout_steps : int
            amount to wait for

        Returns
        -------
        Boolean
            Return whether condition_fn was met.
        """
        for _ in range(timeout_steps):
            orders = []
            for agent_ix in range(self._num_agents):
                player_units = [
                    unit.tag
                    for unit in self.timestep[agent_ix].observation.raw_units
                    if unit.alliance == features.PlayerRelative.SELF
                ]
                # Issue the HoldPosition command for this player to prevent their units
                # from moving from their spots before the game officially begins
                orders.append(
                    RAW_FUNCTIONS.HoldPosition_quick("now", player_units)
                    if len(player_units) > 0
                    else RAW_FUNCTIONS.no_op()
                )

            self.step(
                orders, setup_env=True,
            )

            if condition_fn():
                return True

        return False

    def _kill_and_create(self):
        """Kill all remaining units, then spawn in the next set of units

        Returns
        -------
        timestep
            The updated observation

        Raises
        ------
        ValueError
            if the timestep isn't initialized
        RuntimeError
            if the observers did not finish being created
        RuntimeError
            if the non-observers did not die
        RuntimeError
            if the terrain could not be created
        RuntimeError
            if the observers could not be killed
        RuntimeError
            if the unit counts don't match
        """
        # Ensure that len(timestep) >= 1
        if not self.timestep:
            raise ValueError("timestep isn't initialized; have you called reset()?")

        # Killing units only works if the first player can observe them. The first player
        # thus needs to observe the full map if we wish to get rid of everything. So,
        # let's tile the map with surveillance-mode observers belonging to the first
        # player.
        observers_prev = set(
            [
                unit.tag
                for unit in self.timestep[0].observation.raw_units
                if units.get_unit_type(unit.unit_type) == units.Protoss.ObserverSurveillanceMode
                and unit.alliance == features.PlayerRelative.SELF
            ]
        )

        n_newly_created_observers = 0
        for i in range(0, self.world_size[0], MicroBattleEnv.OBSERVER_SEP):
            for j in range(0, self.world_size[1], MicroBattleEnv.OBSERVER_SEP):
                self.create_units(
                    units.Protoss.ObserverSurveillanceMode, self.owner_ids[0], (i, j), player=0,
                )
                n_newly_created_observers += 1

        def observers_done_creating():
            """Checks if the observers have finished being created

            Returns
            -------
            Boolean
                true if the number of observers created matches the expected number
            """
            all_observers = set(
                [
                    unit.tag
                    for unit in self.timestep[0].observation.raw_units
                    if units.get_unit_type(unit.unit_type) == units.Protoss.ObserverSurveillanceMode
                    and unit.alliance == features.PlayerRelative.SELF
                ]
            )
            newly_created_observers = all_observers.difference(observers_prev)

            return len(newly_created_observers) == n_newly_created_observers

        if not self._wait_until(observers_done_creating, self.create_kill_timeout):
            raise RuntimeError("Could not finish creating observers.")

        # Let's now kill off all units that are not observers in surveillance. Let's wait
        # until this is done. Note that we only look at the first player's observation,
        # since the first player is the only one with full map vision. Including the
        # other player's observations would be a mistake, since it may observe units that
        # don't exist, as it may have died and still see snapshots.
        def non_observers_die():
            """Checks that all units that are not observers are killed

            Returns
            -------
            Boolean
                True if the number of non-observer units left is 0
            """
            non_observers_left = [
                unit.tag
                for unit in self.timestep[0].observation.raw_units
                if units.get_unit_type(unit.unit_type) != units.Protoss.ObserverSurveillanceMode
            ]

            if len(non_observers_left) > 0:
                self.kill_units(non_observers_left)

            return len(non_observers_left) == 0

        if not self._wait_until(non_observers_die, self.create_kill_timeout):
            raise RuntimeError("Could not kill all non-observer units.")

        # While the observers are still alive, modify the terrain so that we can confirm
        # that the terrain has been built properly.
        expected_terrain_units = []
        for terrain_modifier in self._terrain_modifiers:
            expected_terrain_units.extend(terrain_modifier.modify(self))
        expected_terrain_units = dict(Counter(expected_terrain_units))

        def terrain_units_created():
            """Checks that the terrain units have all been created

            Returns
            -------
            Boolean
                true if the actual terrain units created match the expected units
            """
            actual_terrain_units = dict(
                Counter(
                    [
                        units.get_unit_type(unit.unit_type)
                        for unit in self.timestep[0].observation.raw_units
                        if unit.alliance == features.PlayerRelative.NEUTRAL
                    ]
                )
            )
            return actual_terrain_units == expected_terrain_units

        if not self._wait_until(terrain_units_created, self.create_kill_timeout):
            raise RuntimeError("Could not create terrain properly.")

        # Kill all remaining non-neutral units; these are just observers.
        def no_units_left():
            """Kills all remaining units

            Returns
            -------
            Boolean
                true if the amount of units left is 0
            """
            units_left = []

            for unit in self.timestep[0].observation.raw_units:
                # Don't kill off the terran units that we just spawned
                if unit.alliance == features.PlayerRelative.NEUTRAL:
                    continue

                # Ensure that the units left are just observers in surveillance mode
                # belonging to player 0. Iterating over timestep 0, i.e. player 0's view
                # is sufficient, since player 0 has full view of the map at this point.
                assert unit.alliance == features.PlayerRelative.SELF
                assert units.get_unit_type(unit.unit_type) == units.Protoss.ObserverSurveillanceMode
                units_left.append(unit.tag)

            if len(units_left) > 0:
                self.kill_units(units_left)

            return len(units_left) == 0

        if not self._wait_until(no_units_left, self.create_kill_timeout):
            raise RuntimeError("Could not kill the observers.")

        # Create units
        # Make units unkillable so they don't mess up our spawning.
        # NOTE: when banelings attack, they will still kill themselves even in god mode
        for player in range(self.n_players):
            self.god(player=player)

        expected_unit_counts = [{} for _ in range(self.n_players)]

        for player_id, owner_id, units_list in zip(
            self.player_ids, self.owner_ids, self.player_units
        ):
            cur_unit_counts = expected_unit_counts[player_id]
            for unit_desc in units_list:
                unit_type = unit_desc["unit_type"]
                self.create_units(
                    unit_type, owner_id, unit_desc["pos"], player=player_id,
                )

                cur_unit_counts[unit_type] = cur_unit_counts.get(unit_type, 0) + 1

        # Wait until all units have been created
        def unit_counts_match():
            """Wait until all units have been created and the unit counts match

            Returns
            -------
            Boolean
                True if all the expected unit counts are correct for both players
            """
            actual_unit_counts = [self._unit_counts(player_id) for player_id in self.player_ids]
            return all(
                [expected_unit_counts[_id] == actual_unit_counts[_id] for _id in self.player_ids]
            )

        if not self._wait_until(unit_counts_match, self.create_kill_timeout):
            raise RuntimeError("Not all unit counts match.")

        # Make units killable so we can play the game
        for player in range(self.n_players):
            self.god(player=player)

        return self.timestep

    def _generate_upgrades(self):
        """Generates the upgrades for a match

        Raises
        ------
        RuntimeError
            if all the upgrade buildings could not be spawned
        RuntimeError
            if all the upgrade buildings could not be killed
        """
        # Make things easier to build
        self.eliminate_costs()

        # Make all the buildings invincible (safety precaution)
        for player in range(self.n_players):
            self.god(player=player)

        # Grab the desired research commands
        research = [selector.select() for selector in self.upgrade_selectors]

        # From those commands, determine which races each player needs
        needed_races = [[] for _ in range(self.n_players)]
        for player_id, player_research in zip(self.player_ids, research):
            for upgrade in player_research:
                if upgrade_data.upgrade_race(upgrade) not in needed_races[player_id]:
                    needed_races[player_id].append(upgrade_data.upgrade_race(upgrade))

        # Break up generating the upgrades into races for each team (if one team needs
        # more races, than the other, then the team with less races will wait with no
        # buildings until everything is ready
        max_nb_races = max([len(race_list) for race_list in needed_races])
        for race_idx in range(max_nb_races):
            buildings_to_spawn = []
            player_races = [
                player_race_list[race_idx] if len(player_race_list) > race_idx else None
                for player_race_list in needed_races
            ]

            # Generate the buildings
            for player_id, owner_id in zip(self.player_ids, self.owner_ids):
                # If a player doesn't need any more races, then we just don't spawn
                # buildings for them
                if player_races[player_id] is None:
                    continue

                # Grab all the needed buildings
                buildings = upgrade_data.upgrade_buildings(player_races[player_id])
                for building_ix, building in enumerate(buildings):
                    # Some buildings require tech labs to be spawned it exactly the right
                    # position. Others need to be generated on creep, or close enough to
                    # a pylon. By spreading out the building spawns and grouping them
                    # by player, we ensure that every building's conditions for creating
                    # upgrades are met
                    position = (
                        (self.world_size[0] - 9) * player_id,
                        4 * building_ix,
                    )
                    self.create_units(
                        building, owner_id, position, 1, player_id,
                    )
                    buildings_to_spawn.append(building)

                    # Certain buildings (i.e. barracks and protoss buildings) require a
                    # second building before they can perform their actions. To spawn
                    # a barracks techlab, a techlab must be spawned at the bottom right
                    # corner of a barracks, otherwise it will just be a techlab w/ no
                    # actions.
                    # NOTE: Techlabs have different unit types based on their attachments
                    if (
                        building
                        in [units.Terran.Barracks, units.Terran.Starport, units.Terran.Factory,]
                        or building in units.Protoss
                    ):
                        if building == units.Terran.Barracks:
                            techlab = units.Terran.BarracksTechLab
                        elif building == units.Terran.Starport:
                            techlab = units.Terran.StarportTechLab
                        elif building == units.Terran.Factory:
                            techlab = units.Terran.FactoryTechLab
                        else:
                            techlab = units.Protoss.Pylon

                        # Need to add +3 to x position so that techlabs spawn in the
                        # proper spot. Giving the exact same position as the original
                        # building will cause the techlab to spawn randomly, and may not
                        # attach correctly
                        self.create_units(
                            techlab, owner_id, (position[0] + 3, position[1]), 1, player_id,
                        )
                        buildings_to_spawn.append(techlab)

            # Spawn all of the buildings and then wait until all show up
            def buildings_match():
                """Checks if all of the buildings have spawned

                Returns
                -------
                Boolean
                    True if all the spawned buildings are in the buildings to spawn
                """
                spawned_buildings = [
                    unit.unit_type for unit in self.timestep[0].observation.raw_units
                ]
                return all(building in spawned_buildings for building in buildings_to_spawn)

            if not self._wait_until(buildings_match, self.create_kill_timeout):
                raise RuntimeError("Could not spawn all upgrade buildings!")

            # Grab all the research commands we can do with these buildings
            race_research = [[] for _ in range(self.n_players)]
            for player_id, race in enumerate(player_races):
                if race is None:
                    continue
                race_research[player_id] = [
                    u for u in research[player_id] if upgrade_data.upgrade_race(u) == race
                ]

            # Continuously apply the research commands until we finally get all the
            # upgrades we requested. Once all the upgrades appear in the game, then
            # we can move on
            idx = 0
            while any(len(team_research) for team_research in race_research):
                actions = []
                # Determine the research action for each team
                for timestep, team_research in zip(self.timestep, race_research):
                    if len(team_research) > 0:
                        # Grab an upgrade that hasn't been applied yet and tell a
                        # unit to research it once it gets the chance
                        upgrade = team_research[idx % len(team_research)]
                        selected_unit = [
                            unit
                            for unit in timestep.observation.raw_units
                            if unit.alliance == features.PlayerRelative.SELF
                            and unit.unit_type == upgrade_data.upgrade_data(upgrade).building
                        ]
                        actions.append(RAW_FUNCTIONS[upgrade]("queued", selected_unit[0].tag))

                    else:
                        # This team is done all of its research commands for this
                        # particular race
                        actions.append(RAW_FUNCTIONS.no_op())
                idx += 1

                # Step the environment
                self.step(actions, setup_env=True)

                # Remove all research commands whose upgrades have already been applied
                race_research = [
                    [
                        upgrade
                        for upgrade in team_research
                        if upgrade_data.upgrade_data(upgrade).upgrade
                        not in timestep.observation.upgrades
                    ]
                    for timestep, team_research in zip(self.timestep, race_research)
                ]

            # Kill all the units
            def buildings_die():
                """Checks if all the buildings have been killed

                Returns
                -------
                Boolean
                    True if there are no buildings left
                """
                buildings_left = [unit.tag for unit in self.timestep[0].observation.raw_units]
                if len(buildings_left) > 0:
                    self.kill_units(buildings_left)

                return len(buildings_left) == 0

            if not self._wait_until(buildings_die, self.create_kill_timeout):
                raise RuntimeError("Could not kill all upgrade buildings.")

        # Return costs to the game
        self.eliminate_costs()
        # Make units killable again
        for player in range(self.n_players):
            self.god(player=player)
