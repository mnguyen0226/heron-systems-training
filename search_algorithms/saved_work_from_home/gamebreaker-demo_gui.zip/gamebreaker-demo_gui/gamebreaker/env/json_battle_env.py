from pysc2.env import sc2_env
from pysc2.lib import features
from pysc2.lib import units
from pysc2.lib.actions import RAW_FUNCTIONS

from gamebreaker.env.base import SC2DebugMixin
from gamebreaker.unit_data import available_units
from gamebreaker.unit_data import unit_data


class JSONBattleEnv(sc2_env.SC2Env, SC2DebugMixin):
    OBSERVER_SEP = 4

    def __init__(self, perturbations, create_kill_timeout=100, *args, **kwargs):
        """Construct a JSON Battle environment

        Parameters
        ----------
        perturbations : Dict
            The factors of the environment to perturb
        create_kill_timeout : int, optional
            the number of steps to wait to initialize the environment on a soft reset, by default
            100
        """
        super().__init__(*args, **kwargs)

        self.perturbations = perturbations
        self.create_kill_timeout = create_kill_timeout
        self.player_ids = list(range(self._num_agents))
        self.owner_ids = list(range(1, 1 + len(self._players)))
        self.nb_players = len(self._players)
        self.player_units = None
        self.timestep = None

    @property
    def neutral_owner_id(self):
        """Returns the value for a neutral unit owner

        Returns
        -------
        0
            the value of a neutral unit
        """
        return 0

    def reset(self, perturbations=None, reset_base_env: bool = True):
        """Resets the sc2 env

        Parameters
        ----------
        perturbations : Dict, optional
            Values to perturb, by default None
        reset_base_env : bool, optional
            Whether or not to hard reset the base env, by default True

        Returns
        -------
        the timestep will all the units killed and created
        """
        if reset_base_env:
            self.timestep = super().reset()

        if perturbations is not None:
            self.perturbations = perturbations

        self._kill_all()
        self._spawn_units()
        return self.timestep

    def _kill_all(self):
        """Kill all the remaining units

        Raises
        ------
        RuntimeError
            if the units were not all killed
        """
        for i in [0, 1]:
            unit_list = [
                unit.tag
                for unit in self.timestep[i].observation.raw_units
                if unit.alliance == features.PlayerRelative.SELF
            ]

            if len(unit_list) > 0:
                self.kill_units(unit_list)

            for _ in range(self.create_kill_timeout):
                self.step(
                    [RAW_FUNCTIONS.no_op() for _ in range(self._num_agents)], avoid_reset=True,
                )

                if all(
                    unit.alliance != features.PlayerRelative.SELF
                    for unit in self.timestep[i].observation.raw_units
                ):
                    break
            else:
                raise RuntimeError("Could not kill all of the units!")

    def _spawn_units(self):
        """Spawn in the next set of units

        Raises
        ------
        RuntimeError
            if not all the units were created
        """
        unit_list = decode_units(self.perturbations)
        for player_id, owner_id, key in zip(self.player_ids, self.owner_ids, unit_list):
            for unit in unit_list[key]:
                self.create_units(
                    unit,
                    owner_id,
                    (self.perturbations["x"][key], self.perturbations["y"][key],),
                    player=player_id,
                )

            for _ in range(self.create_kill_timeout):
                self.step(
                    [RAW_FUNCTIONS.no_op() for _ in range(self._num_agents)], avoid_reset=True,
                )

                spawned_units = [
                    unit.tag
                    for unit in self.timestep[player_id].observation.raw_units
                    if unit.alliance == features.PlayerRelative.SELF
                ]

                if len(spawned_units) == len(unit_list[key]):
                    break
            else:
                raise RuntimeError("Not all units were made!")

    def step(self, actions, step_mul=None, avoid_reset=False, reset_base_env=False):
        """Step the environment and execute the actions, then update the env

        Parameters
        ----------
        actions : Tuple[FunctionCall]
            The actions to perform
        step_mul : int, optional
            The amount to multliply how much we step the environment by, by default None
        avoid_reset : bool, optional
            whether or not to avoid resetting, by default False
        reset_base_env : bool, optional
            whether or not to reset the base env, by default False

        Returns
        -------
        Tuple(Timestep, int)
            the env observations, and the result
        """
        self.timestep = super().step(actions, step_mul=step_mul)
        assert len(self.timestep) == self.nb_players

        is_alives = [len(self._unit_counts(player_id)) > 0 for player_id in self.player_ids]

        if all(is_alives) or avoid_reset:
            return self.timestep, -1
        else:
            return (
                self.reset(reset_base_env=reset_base_env),
                next((i for i, x in enumerate(is_alives) if x == 0), None),
            )

    def _unit_counts(self, player_id):
        """Returns a count of the units

        Parameters
        ----------
        player_id : int
            id of the player to count units for

        Returns
        -------
        dict
            count of the units
        """
        return [
            unit.tag
            for unit in self.timestep[player_id].observation.raw_units
            if unit.alliance == features.PlayerRelative.SELF
        ]


def decode_units(perturbations):
    """Decodes the units based on the input perturbations

    Parameters
    ----------
    perturbations : Dict
        The fields and values to perturb

    Returns
    -------
    Dict
        The unit list
    """
    unit_list = {}
    race_list = {
        "terran": units.Terran,
        "zerg": units.Zerg,
        "protoss": units.Protoss,
    }
    for key in perturbations["agent_race"]:
        race_units = available_units(race_list[perturbations["agent_race"][key]])
        minerals_total = perturbations["minerals"][key]
        gas_total = perturbations["gas"][key]

        unit_list[key] = []
        for unit in perturbations["available_unit_types"][key]:
            unit_info = unit_data(race_units[unit % len(race_units)])
            if minerals_total - unit_info.minerals >= 0 and gas_total - unit_info.gas >= 0:
                unit_list[key].append(race_units[unit % len(race_units)])
                minerals_total -= unit_info.minerals
                gas_total -= unit_info.gas

    return unit_list
