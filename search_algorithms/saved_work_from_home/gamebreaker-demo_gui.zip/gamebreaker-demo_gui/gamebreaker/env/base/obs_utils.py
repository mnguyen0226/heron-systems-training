import pickle
from collections.abc import Iterable
from itertools import chain
from typing import List
from typing import Tuple
from typing import Union

import numpy as np
import torch
from pysc2.lib.buffs import Buffs
from pysc2.lib.features import FeatureUnit
from pysc2.lib.named_array import NamedNumpyArray
from pysc2.lib.units import Neutral
from pysc2.lib.units import Protoss
from pysc2.lib.units import Terran
from pysc2.lib.units import Zerg

from .binary_lookup import binary_lookup
from gamebreaker.env.base.obs_idx import CustomObsIdx
from gamebreaker.env.base.obs_idx import ObsIdx
from gamebreaker.env.base.obs_info import ExtraBuffs
from gamebreaker.env.base.obs_info import ExtraUnitTypes
from gamebreaker.env.base.obs_info import FeatureType
from gamebreaker.env.base.obs_info import get_bit_length
from gamebreaker.env.base.obs_info import get_features_infos

FIXED_UNIT_COUNT = 512
N_PYSC2_FIELDS = 47


def raw_empty_units(n=1, index_names=None):
    ret = np.zeros((n, N_PYSC2_FIELDS), dtype=np.int64)

    if index_names:
        if len(index_names) != N_PYSC2_FIELDS:
            raise ValueError(f"len(index_names) = {len(index_names)} != {N_PYSC2_FIELDS}")
        ret = NamedNumpyArray(ret, [None, index_names],)

    # These numbers were obtained empirically by looking at blank data
    ret[:, 0] = 886
    ret[:, 31] = 7
    ret[:, 32] = 7
    ret[:, 33] = 886

    return ret


def raw_is_empty(tail, index_names=None):
    tail = np.unique(tail, axis=0)

    if tail.shape[0] != 1:
        return False

    single_empty = np.array(raw_empty_units(n=1, index_names=index_names))

    return single_empty.shape == tail.shape and np.all(single_empty == tail)


def cat_to_bin(cat_value: int, num_bits: int, out: torch.Tensor = None, start_idx: int = 0):
    """Converts categorical feature to binary array

    Parameters
    ----------
    cat_value : int
        value of categorical feature
    range : int
        range of categorical feature (used to find number of bits needed)
    out : torch.Tensor, optional
        output binary array, by default None
    start_idx : int, optional
        index in output array to start at, by default 0

    Returns
    -------
    torch.Tensor
        output tensor containing binary encoding of categorical value
    int
        number of bits used to represent categorical value
    """
    bin_rep = binary_lookup[cat_value]
    if out is None:
        out = torch.zeros(num_bits)
    out[start_idx + (num_bits - bin_rep.shape[0]) : start_idx + num_bits] = bin_rep
    return out, num_bits


def bin_to_cat(in_tensor: torch.Tensor, num_bits: int, start_idx: int = 0):
    """Converts binary array to categorical feature

    Parameters
    ----------
    in_tensor : torch.Tensor
        input binary array
    num_bits : int
        number of bits of binary array to sample
    start_idx : int, optional
        index in output array to start at, by default 0

    Returns
    -------
    int
        categorical value corresponding to binary array
    """
    assert (
        in_tensor.shape[0] - start_idx >= num_bits
    ), f"in array is not large enough to read binary value of size {num_bits}"
    # convert binary value to categorical
    idx = 0
    out = 0
    while idx < num_bits:
        out += in_tensor[idx + start_idx].item() * 2 ** (num_bits - 1 - idx)
        idx += 1

    return int(out)


def get_raw_unit(proc_unit: np.ndarray, max_x: int, max_y: int) -> NamedNumpyArray:
    """
    Function to convert a unit that has been preprocessed back into the form that comes
    out of the environment (a "raw" unit)
    """

    if proc_unit.ndim == 1:
        # User passed in a single unit vector
        timesteps = np.reshape(proc_unit, (1, 1, -1))
    elif proc_unit.ndim == 2 and proc_unit[0, 0].ndim == 0:
        # User passed in multiple units from a single timestep
        # To make things easier, we first transmute the units s.t. the dimension order is
        # units, features
        transmuted_units = proc_unit.T
        timesteps = np.reshape(transmuted_units, (1, transmuted_units.shape[0], -1))
    elif proc_unit.ndim == 3 or (proc_unit.ndim == 2 and proc_unit[0, 0].ndim == 1):
        # User passed in multiple timesteps, each with a list of units
        # NOTE: unsafe to use np.moveaxis here, as sometimes the user might pass in a game
        # where the number of units on each timestep isn't consistent. This leads to
        # numpy claiming that the array is only 2D, as the third dimension is inconsistent
        timesteps = np.asarray([timestep.T for timestep in proc_unit])
    else:
        raise RuntimeError("Input must either be 1D, 2D, or 3D ndarray")

    # This is the reverse mapping for unit types used in the preprocessing tools
    id_to_unit_types = dict(enumerate(chain(Neutral, Terran, Protoss, Zerg, ExtraUnitTypes)))

    # This is the reverse mapping for unit buffs used in the preprocessing tools
    id_to_buffs = dict(enumerate(chain(Buffs, ExtraBuffs)))

    # Returns the bit lengths for each categorical feature
    bit_lengths = get_bit_length(max_x, max_y)

    # Returns in-depth information about each feature (type, raw index, proc index, etc.)
    feature_info = get_features_infos(max_x, max_y)

    raw_timesteps = []
    for timestep in timesteps:
        raw_timestep = []
        for unit in timestep:
            # Create the blank array for the new unit
            new_unit = np.zeros(len(FeatureUnit) + len(CustomObsIdx))

            # Begin populating each feature of the new unit
            for feature in feature_info:
                if feature_info[feature].type == FeatureType.CATEGORICAL:
                    # Categorical features need to be converted back from binary
                    feature_length = bit_lengths[feature_info[feature].name]
                    new_unit[feature_info[feature].raw_idx] = bin_to_cat(
                        unit, feature_length, feature_info[feature].proc_idx
                    )
                else:
                    # Non-categorical features just have to be multiplied by their max
                    # value
                    new_unit[feature_info[feature].raw_idx] = np.round(
                        unit[feature_info[feature].proc_idx] * feature_info[feature].range
                    )

            # Map the unit type back to the PySC2 value
            new_unit[FeatureUnit.unit_type] = id_to_unit_types[
                new_unit[FeatureUnit.unit_type].item()
            ]

            # Map the addon unit type back to the PySC2 value
            new_unit[FeatureUnit.addon_unit_type] = id_to_unit_types[
                new_unit[FeatureUnit.addon_unit_type].item()
            ]

            # Map the unit buffs back to the PySC2 value
            new_unit[FeatureUnit.buff_id_0] = id_to_buffs[new_unit[FeatureUnit.buff_id_0].item()]
            new_unit[FeatureUnit.buff_id_1] = id_to_buffs[new_unit[FeatureUnit.buff_id_1].item()]

            # Create a list of feature names and rebuild the NamedNumpyArray
            features = [feature.name for feature in FeatureUnit]
            features.append("on_creep")

            raw_timestep.append(NamedNumpyArray(new_unit.astype(int), features))
        raw_timesteps.append(NamedNumpyArray(raw_timestep, (None, features)))

    if proc_unit.ndim == 1:
        # User passed in a single unit vector
        return raw_timesteps[0][0]
    elif proc_unit.ndim == 2 and proc_unit[0, 0].ndim == 0:
        # User passed in multiple units from a single timestep
        # To make things easier, we first transmute the units s.t. the dimension order is
        # units, features
        return raw_timesteps[0]
    else:
        # User passed in multiple timesteps, each with a list of units
        return NamedNumpyArray(raw_timesteps, (None, None, features))


def get_proc_unit(
    input_unit: np.ndarray, x_max: int, y_max: int, map_tag: int = None
) -> np.ndarray:
    """
    Function to convert a raw unit into a processed unit. If the tag has not been mapped
    yet (reading a raw dataset file or grabbing straight from PySC2), set map_tag to the
    value you would like to set as the tag. Otherwise, keep map tag false.
    """

    raw_unit = np.asarray(input_unit)
    if raw_unit.ndim == 1 and raw_unit[0].ndim == 0:
        # The user has passed in a single unit, so put it into a unit list and timestep
        timesteps = np.reshape(raw_unit, (1, 1, raw_unit.shape[0]))
    elif raw_unit.ndim == 2:
        # The user has passed in a list of units
        timesteps = np.reshape(raw_unit, (1, raw_unit.shape[0], raw_unit.shape[1]))
    elif raw_unit.ndim == 3 or (raw_unit.ndim == 1 and raw_unit[0].ndim == 2):
        # The user has passed in multiple timesteps of units
        timesteps = np.copy(raw_unit)
    else:
        raise RuntimeError("Input must either be 1D, 2D, or 3D ndarray")

    # These allow us to map the unit type to a custom mapping
    id_to_unit_types = dict(enumerate(chain(Neutral, Terran, Protoss, Zerg, ExtraUnitTypes)))
    unit_type_to_ids = {v: k for k, v in id_to_unit_types.items()}

    # These allow us to map the unit's buffs to a custom mapping
    id_to_buffs = dict(enumerate(chain(Buffs, ExtraBuffs)))
    buff_to_ids = {v: k for k, v in id_to_buffs.items()}

    # Bit lengths of all the categorical features
    bit_length = get_bit_length(x_max, y_max)

    # In depth information about each of the features
    feature_info = get_features_infos(x_max, y_max)

    # Pre-compute a single empty unit
    single_empty_unit = raw_empty_units(n=1)

    proc_timesteps = []
    for timestep in timesteps:
        proc_timestep = []
        for unit in timestep:
            # Create an empty array to copy the unit into
            proc_unit = np.zeros(len(ObsIdx) + len(CustomObsIdx))

            # If the current unit is empty, then pre-empt this computation; this yields
            # a ~2x speedup over not having this check.
            if not np.all(unit == single_empty_unit):
                for feature in feature_info:
                    # Grab the original value from the raw unit
                    feature_value = unit[feature_info[feature].raw_idx]

                    # If we need to substitute the value for a custom mapping, or the
                    # tag, we do that here
                    if (
                        feature_info[feature].name == "unit_type"
                        or feature_info[feature].name == "addon_unit_type"
                    ):
                        feature_value = unit_type_to_ids[feature_value]
                    elif (
                        feature_info[feature].name == "buff_id_0"
                        or feature_info[feature].name == "buff_id_1"
                    ):
                        feature_value = buff_to_ids[feature_value]
                    elif feature_info[feature].name == "tag" and map_tag is not None:
                        feature_value = map_tag

                    # Convert the feature, depending on if it's categorical or otherwise
                    if feature_info[feature].type == FeatureType.CATEGORICAL:
                        # Convert from binary by passing in our unit vector and copying the values in
                        proc_unit, _ = cat_to_bin(
                            feature_value,
                            bit_length[feature_info[feature].name],
                            out=proc_unit,
                            start_idx=feature_info[feature].proc_idx,
                        )
                    else:
                        # Simply divide by the max value
                        proc_unit[feature_info[feature].proc_idx] = (
                            feature_value / feature_info[feature].range
                        )
            proc_timestep.append(proc_unit)
        proc_timesteps.append(np.asarray(proc_timestep).T)

    if raw_unit.ndim == 1 and raw_unit[0].ndim == 0:
        # The user has passed in a single unit, so put it into a unit list and timestep
        return np.squeeze(np.asarray(proc_timesteps))
    elif raw_unit.ndim == 2:
        # The user has passed in a list of units
        return np.squeeze(np.asarray(proc_timesteps), axis=0)
    else:
        # The user has passed in multiple timesteps of units
        return np.asarray(proc_timesteps, dtype=object)


def scale(scalar_val: float, range: Union[float, Tuple[float, float]]):
    """Scales scalar value to a [-1, 1] range

    Parameters
    ----------
    scalar_val : float
        input scalar value
    range : float | tuple(float, float)
        input range of scalar (if single value given, range is assumed as [0, range])

    Returns
    -------
    float
        scaled value (to range [-1, 1])
    """
    if isinstance(range, Iterable):
        assert len(range) == 2, (f"Range tuple must be of length 2, not length {len(range)}",)
    elif isinstance(range, (int, float)):
        range = (0, range)

    assert range[0] <= scalar_val <= range[1], (f"scalar_val {scalar_val} not in range {range}",)

    spread = range[1] - range[0]
    offset = range[0]

    return (scalar_val - offset) / (spread / 2) - 1


def unit_type_map(
    raw_unit_type: int,
    raw_unit_types: List[int],
    out: torch.Tensor = None,
    start_idx: int = 0,
    debug_mode: bool = False,
):
    """Converts raw integer unit type to binary-encoded (trimmed) unit type

    Parameters
    ----------
    raw_unit_type : int
        raw unit type to convert
    raw_unit_type : List[int]
        raw unit types
    out : torch.Tensor, optional
        output tensor for binary unit type, by default None
    start_idx : int, optional
        index in output array to start at, by default 0
    debug_mode : bool, optional
        when enabled, adds any unique tags to raw_unit_types, by default False

    Returns
    -------
    torch.Tensor
        output binary unit type
    int
        number of bits used to represent categorical value
    """
    try:
        unit_type = raw_unit_types.index(raw_unit_type)
    except ValueError:
        if debug_mode:
            raw_unit_types.append(raw_unit_type)
            unit_type = raw_unit_types.index(raw_unit_type)

            with open("gamebreaker/env/base/raw_unit_types.pkl", "wb") as raw_unit_types_file:
                pickle.dump(raw_unit_types, raw_unit_types_file)
        else:
            raise ValueError(f"raw unit type {raw_unit_type} invalid")

    return cat_to_bin(unit_type, len(raw_unit_types) - 1, out, start_idx=start_idx)


def buff_map(
    raw_buff: int,
    raw_buffs: List[int],
    out: torch.Tensor = None,
    start_idx: int = 0,
    debug_mode: bool = False,
):
    """Converts raw integer buff IDs to binary-encoded (trimmed) buff IDs

    Parameters
    ----------
    raw_buff: int
        raw buff to convert
    raw_buffs : List[int]
        list of raw buffs
    out : torch.Tensor, optional
        output tensor for binary buff, by default None
    start_idx : int, optional
        index in output array to start at, by default 0
    debug_mode : bool, optional
        when enabled, adds any unique tags to raw_buffs, by default False

    Returns
    -------
    torch.Tensor
        output binary buff ID
    int
        number of bits used to represent categorical value
    """
    try:
        buff_id = raw_buffs.index(raw_buff)
    except ValueError:
        if debug_mode:
            raw_buffs.append(raw_buff)
            buff_id = raw_buffs.index(raw_buff)

            with open("gamebreaker/env/base/raw_buffs.pkl", "wb") as raw_buffs_file:
                pickle.dump(raw_buffs, raw_buffs_file)
        else:
            raise ValueError(f"raw buff ID {raw_buff} invalid")

    return cat_to_bin(buff_id, len(raw_buffs) - 1, out, start_idx=start_idx)


def tag_map(
    raw_tag: int,
    raw_tags: List[int],
    out: torch.Tensor = None,
    start_idx: int = 0,
    debug_mode: bool = False,
):
    """Converts raw integer tags to binary-encoded (trimmed) tags

    Parameters
    ----------
    raw_tag : int
        raw tag to convert
    raw_tags : List[int]
        list of raw tags
    out : torch.Tensor, optional
        output tensor for binary tag, by default None
    start_idx : int, optional
        index in output array to start at, by default 0
    debug_mode : bool, optional
        when enabled, adds any unique tags to raw_tags, by default False

    Returns
    -------
    torch.Tensor
        output binary tag
    int
        number of bits used to represent categorical value
    """
    try:
        tag = raw_tags.index(raw_tag)
    except ValueError:
        if debug_mode:
            raw_tags.append(raw_tag)
            tag = raw_tags.index(raw_tag)

            with open("gamebreaker/env/base/raw_tags.pkl", "wb") as raw_tags_file:
                pickle.dump(raw_tags, raw_tags_file)
        else:
            raise ValueError(f"raw tag {raw_tag} invalid")

    if debug_mode:
        max_tag = 511  # 9 bits
    else:
        max_tag = len(raw_tags - 1)
        if max_tag > 511:
            raise Exception(
                "Max tag size larger than tag size allowed... " "adjust max tag size in obs_idx.py"
            )

    return cat_to_bin(tag, max_tag, out, start_idx=start_idx)


def on_creep_map(timesteps: np.ndarray, map_size: Tuple[int]) -> NamedNumpyArray:
    # Trying to make this function not assume no fog of war
    for player_ix, timestep in enumerate(timesteps):
        # Grab this player's unit positions (keeping in mind that y will be the row and x
        # will be the column)
        unit_pos = [[unit.y, unit.x] for unit in timestep.observation.raw_units]

        # If this player has no units, skip their observation
        if len(unit_pos) == 0:
            break

        # Here we grab the creep map from the observations. However, to line up positions
        # in the creep map, we also have to crop out any unpathable areas of the map
        creep_map = []
        for path_row, creep_row in zip(
            timestep.observation.feature_minimap.pathable,
            timestep.observation.feature_minimap.creep,
        ):
            if not any(path_row):
                continue
            creep_map_row = []
            for path_space, creep_space in zip(path_row, creep_row):
                if path_space == 1:
                    creep_map_row.append(creep_space)
            creep_map.append(np.asarray(creep_map_row))
        creep_map = np.asarray(creep_map)

        # The creep map and the map size may not be the same size, so we need to scale
        # them for a true lookup
        map_col, map_row = map_size[0], map_size[1]
        creep_map_row, creep_map_col = creep_map.shape
        scale_factor = np.asarray([(creep_map_row - 1) / map_row, (creep_map_col - 1) / map_col])

        # Scale the unit positions and pretty them up to use as array indices
        unit_pos = np.round(unit_pos * scale_factor)
        unit_pos = unit_pos.astype(int)
        unit_ys, unit_xs = unit_pos[:, 0], unit_pos[:, 1]
        on_creep = creep_map[unit_ys, unit_xs]

        # Create the index names for the NumpyNamedArray
        index_names = list(timestep.observation.raw_units[0]._index_names[0])

        # Add the creep observation
        index_names.append("on_creep")

        # We have to create all the new unit obs at once (to appease numpy's demands that
        # every element of an array be the same size)
        new_units = []
        for unit, creep_flag in zip(timestep.observation.raw_units, on_creep):
            new_unit_values = [value for value in unit]
            new_unit_values.append(creep_flag)
            new_units.append(NamedNumpyArray(new_unit_values, index_names))

        timesteps[player_ix].observation.raw_units = NamedNumpyArray(
            new_units, [None, index_names], dtype=np.int64
        )

    return timesteps
