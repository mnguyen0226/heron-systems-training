import numpy as np
import torch


def binary_tensor(num):
    bin_str = np.binary_repr(num)
    return torch.Tensor(list(map(int, list(bin_str))))


binary_lookup = {i: binary_tensor(i) for i in range(50000)}
