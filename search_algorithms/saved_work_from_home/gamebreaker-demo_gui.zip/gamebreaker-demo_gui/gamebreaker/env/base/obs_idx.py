import enum
from enum import auto
from enum import IntEnum


class _ObsIdxGenerateAuto(IntEnum):
    def _generate_next_value_(name, start, count, last_values):
        return count


class ObsIdx(_ObsIdxGenerateAuto):
    """Indices of processed observation

    Raw indices at pysc2.lib.features.FeatureUnit
    """

    # unit_type: 9 bits -> 511 max index (required: 258)
    unit_type_bit0 = auto()
    unit_type_bit1 = auto()
    unit_type_bit2 = auto()
    unit_type_bit3 = auto()
    unit_type_bit4 = auto()
    unit_type_bit5 = auto()
    unit_type_bit6 = auto()
    unit_type_bit7 = auto()
    unit_type_bit8 = auto()

    # alliance: 3 bits =  (up to 4)
    # Self = 1, Ally = 2, Neutral = 3, Enemy = 4
    alliance_bit0 = auto()
    alliance_bit1 = auto()
    alliance_bit2 = auto()

    # display_type: 2 bits (up to 3)
    # Visible = 1, Snapshot = 2, Hidden = 3
    display_type_bit0 = auto()
    display_type_bit1 = auto()

    # owner: 5 bits
    # 1-15, 16 = neutral
    owner_bit0 = auto()
    owner_bit1 = auto()
    owner_bit2 = auto()
    owner_bit3 = auto()
    owner_bit4 = auto()

    # facing: 3 bits
    facing_bit0 = auto()
    facing_bit1 = auto()
    facing_bit2 = auto()

    # cloak: 2 bits (up to 3)
    # Cloaked = 1, CloakedDetected = 2, NotCloaked = 3
    cloak_bit0 = auto()
    cloak_bit1 = auto()

    # order_id_0: 10 bits (up to 1023)
    # pysc2.lib.actions
    order_id_0_bit0 = auto()
    order_id_0_bit1 = auto()
    order_id_0_bit2 = auto()
    order_id_0_bit3 = auto()
    order_id_0_bit4 = auto()
    order_id_0_bit5 = auto()
    order_id_0_bit6 = auto()
    order_id_0_bit7 = auto()
    order_id_0_bit8 = auto()
    order_id_0_bit9 = auto()

    # order_id_1: 10 bits (up to 1023)
    # pysc2.lib.actions
    order_id_1_bit0 = auto()
    order_id_1_bit1 = auto()
    order_id_1_bit2 = auto()
    order_id_1_bit3 = auto()
    order_id_1_bit4 = auto()
    order_id_1_bit5 = auto()
    order_id_1_bit6 = auto()
    order_id_1_bit7 = auto()
    order_id_1_bit8 = auto()
    order_id_1_bit9 = auto()

    # tag: 9 bits (up to 511)
    tag_bit0 = auto()
    tag_bit1 = auto()
    tag_bit2 = auto()
    tag_bit3 = auto()
    tag_bit4 = auto()
    tag_bit5 = auto()
    tag_bit6 = auto()
    tag_bit7 = auto()
    tag_bit8 = auto()

    # buff_id_0: 6 bits (up to 47)
    # pysc2.lib.buffs
    buff_id_0_bit0 = auto()
    buff_id_0_bit1 = auto()
    buff_id_0_bit2 = auto()
    buff_id_0_bit3 = auto()
    buff_id_0_bit4 = auto()
    buff_id_0_bit5 = auto()

    # buff_id_1: 6 bits (up to 47)
    # pysc2.lib.buffs
    buff_id_1_bit0 = auto()
    buff_id_1_bit1 = auto()
    buff_id_1_bit2 = auto()
    buff_id_1_bit3 = auto()
    buff_id_1_bit4 = auto()
    buff_id_1_bit5 = auto()

    # addon_unit_type: 9 bits (up to 259)
    # pysc2.lib.units
    addon_unit_type_bit0 = auto()
    addon_unit_type_bit1 = auto()
    addon_unit_type_bit2 = auto()
    addon_unit_type_bit3 = auto()
    addon_unit_type_bit4 = auto()
    addon_unit_type_bit5 = auto()
    addon_unit_type_bit6 = auto()
    addon_unit_type_bit7 = auto()
    addon_unit_type_bit8 = auto()

    # order_id_2: 10 bits (up to 1023)
    order_id_2_bit0 = auto()
    order_id_2_bit1 = auto()
    order_id_2_bit2 = auto()
    order_id_2_bit3 = auto()
    order_id_2_bit4 = auto()
    order_id_2_bit5 = auto()
    order_id_2_bit6 = auto()
    order_id_2_bit7 = auto()
    order_id_2_bit8 = auto()
    order_id_2_bit9 = auto()

    # order_id_3: 10 bits (up to 1023)
    order_id_3_bit0 = auto()
    order_id_3_bit1 = auto()
    order_id_3_bit2 = auto()
    order_id_3_bit3 = auto()
    order_id_3_bit4 = auto()
    order_id_3_bit5 = auto()
    order_id_3_bit6 = auto()
    order_id_3_bit7 = auto()
    order_id_3_bit8 = auto()
    order_id_3_bit9 = auto()

    # attack_upgrade_level: 2 bits (up to 3)
    attack_upgrade_level_bit0 = auto()
    attack_upgrade_level_bit1 = auto()

    # armor_upgrade_level: 2 bits (up to 3)
    armor_upgrade_level_bit0 = auto()
    armor_upgrade_level_bit1 = auto()

    # shield_upgrade_level: 2 bits (up to 3)
    shield_upgrade_level_bit0 = auto()
    shield_upgrade_level_bit1 = auto()

    # health: scalar
    # max 1600
    health = auto()

    # shield: scalar
    # max 1000
    shield = auto()

    # energy: scalar
    # max 1000
    energy = auto()

    # cargo_space_taken: scalar
    # max 8
    cargo_space_taken = auto()

    # build_progress: scalar
    # max 1 (no scale needed)
    build_progress = auto()

    # health_ratio: scalar
    # max 256
    health_ratio = auto()

    # shield_ratio: scalar
    # max 256
    shield_ratio = auto()

    # energy_ratio: scalar
    # max 256
    energy_ratio = auto()

    # x: scalar
    x = auto()

    # y: scalar
    y = auto()

    # radius: scalar
    radius = auto()

    # is_selected: binary
    is_selected = auto()

    # is_blip: binary
    is_blip = auto()

    # is_powered: binary
    is_powered = auto()

    # mineral_contents: scalar
    # max 1800 (source: https://liquipedia.net/starcraft2/Resources)
    mineral_contents = auto()

    # vespene_contents: scalar
    # max 2250 (source: https://liquipedia.net/starcraft2/Resources)
    vespene_contents = auto()

    # cargo_space_max: scalar
    # maybe scalar not the best for encoding this
    # max 8
    cargo_space_max = auto()

    # assigned_harvesters: scalar
    # max 40 (?) (source: https://liquipedia.net/starcraft2/Mining_Minerals#Maximum)
    assigned_harvesters = auto()

    # ideal_harvesters: scalar
    # max 40 (?) (source: https://liquipedia.net/starcraft2/Mining_Minerals#Maximum)
    ideal_harvesters = auto()

    # weapon_cooldown: scalar
    # max 130 (?) (or maybe 28.57 if referring to attack cooldown, source: https://liquipedia.net/starcraft2/Cooldown)
    weapon_cooldown = auto()

    # order_length: scalar
    # max (?, guesing 256 until can be found)
    order_length = auto()

    # hallucination: binary
    hallucination = auto()

    # active: binary
    active = auto()

    # is_on_screen: binary
    is_on_screen = auto()

    # order_progress_0: scalar
    # max (?, guessing 256 (same as build_progress max))
    order_progress_0 = auto()

    # order_progress_1: scalar
    # max (?, guessing 256 (same as build_progress max))
    order_progress_1 = auto()

    # is_in_cargo: binary
    is_in_cargo = auto()

    # buff_duration_remain: scalar
    # max (?, guessing 256)
    buff_duration_remain = auto()

    # buff_duration_max: scalar
    # max (?, guessing 256)
    buff_duration_max = auto()


class CustomObsIdx(IntEnum):
    # Whether or not the unit is on creep: binary
    on_creep = int(max(ObsIdx)) + 1


class ContextObsIdx(IntEnum):
    # Mappings for the blue upgrade list
    blue_adaptive_talons = auto()
    blue_adrenal_glands = auto()
    blue_advanced_ballistics = auto()
    blue_anabolic_synthesis = auto()
    blue_anion_pulse_crystals = auto()
    blue_blink = auto()
    blue_burrow = auto()
    blue_centrifical_hooks = auto()
    blue_charge = auto()
    blue_chitinous_plating = auto()
    blue_cloaking_field = auto()
    blue_combat_shield = auto()
    blue_concussive_shells = auto()
    blue_corvid_reactor = auto()
    blue_cyclone_rapid_fire_launchers = auto()
    blue_drilling_claws = auto()
    blue_enhanced_shockwaves = auto()
    blue_extended_thermalLance = auto()
    blue_glial_reconstitution = auto()
    blue_gravitic_booster = auto()
    blue_gravitic_drive = auto()
    blue_graviton_catapult = auto()
    blue_grooved_spines = auto()
    blue_hi_sec_auto_tracking = auto()
    blue_high_capacity_fuel_tanks = auto()
    blue_hyperflight_rotors = auto()
    blue_infernal_preigniter = auto()
    blue_lock_on = auto()
    blue_metabolic_boost = auto()
    blue_muscular_augments = auto()
    blue_neosteel_frame = auto()
    blue_neural_parasite = auto()
    blue_pathogen_glands = auto()
    blue_personal_cloaking = auto()
    blue_pneumatized_carapace = auto()
    blue_protoss_air_armors_level1 = auto()
    blue_protoss_air_armors_level2 = auto()
    blue_protoss_air_armors_level3 = auto()
    blue_protoss_air_weapons_level1 = auto()
    blue_protoss_air_weapons_level2 = auto()
    blue_protoss_air_weapons_level3 = auto()
    blue_protoss_ground_armors_level1 = auto()
    blue_protoss_ground_armors_level2 = auto()
    blue_protoss_ground_armors_level3 = auto()
    blue_protoss_ground_weapons_level1 = auto()
    blue_protoss_ground_weapons_level2 = auto()
    blue_protoss_ground_weapons_level3 = auto()
    blue_protoss_shields_level1 = auto()
    blue_protoss_shields_level2 = auto()
    blue_protoss_shields_level3 = auto()
    blue_psi_storm = auto()
    blue_resonating_glaives = auto()
    blue_shadow_strike = auto()
    blue_smart_servos = auto()
    blue_stimpack = auto()
    blue_terran_infantry_armors_level1 = auto()
    blue_terran_infantry_armors_level2 = auto()
    blue_terran_infantry_armors_level3 = auto()
    blue_terran_infantry_weapons_level1 = auto()
    blue_terran_infantry_weapons_level2 = auto()
    blue_terran_infantry_weapons_level3 = auto()
    blue_terran_ship_weapons_level1 = auto()
    blue_terran_ship_weapons_level2 = auto()
    blue_terran_ship_weapons_level3 = auto()
    blue_terran_structure_armor = auto()
    blue_terran_vehicle_and_ship_armors_level1 = auto()
    blue_terran_vehicle_and_ship_armors_level2 = auto()
    blue_terran_vehicle_and_ship_armors_level3 = auto()
    blue_terran_vehicle_weapons_level1 = auto()
    blue_terran_vehicle_weapons_level2 = auto()
    blue_terran_vehicle_weapons_level3 = auto()
    blue_tunneling_claws = auto()
    blue_warp_gate_research = auto()
    blue_weapon_refit = auto()
    blue_zerg_flyer_armors_level1 = auto()
    blue_zerg_flyer_armors_level2 = auto()
    blue_zerg_flyer_armors_level3 = auto()
    blue_zerg_flyer_weapons_level1 = auto()
    blue_zerg_flyer_weapons_level2 = auto()
    blue_zerg_flyer_weapons_level3 = auto()
    blue_zerg_ground_armors_level1 = auto()
    blue_zerg_ground_armors_level2 = auto()
    blue_zerg_ground_armors_level3 = auto()
    blue_zerg_melee_weapons_level1 = auto()
    blue_zerg_melee_weapons_level2 = auto()
    blue_zerg_melee_weapons_level3 = auto()
    blue_zerg_missile_weapons_level1 = auto()
    blue_zerg_missile_weapons_level2 = auto()
    blue_zerg_missile_weapons_level3 = auto()

    # Mapping for the red upgrade list
    red_adaptive_talons = auto()
    red_adrenal_glands = auto()
    red_advanced_ballistics = auto()
    red_anabolic_synthesis = auto()
    red_anion_pulse_crystals = auto()
    red_blink = auto()
    red_burrow = auto()
    red_centrifical_hooks = auto()
    red_charge = auto()
    red_chitinous_plating = auto()
    red_cloaking_field = auto()
    red_combat_shield = auto()
    red_concussive_shells = auto()
    red_corvid_reactor = auto()
    red_cyclone_rapid_fire_launchers = auto()
    red_drilling_claws = auto()
    red_enhanced_shockwaves = auto()
    red_extended_thermalLance = auto()
    red_glial_reconstitution = auto()
    red_gravitic_booster = auto()
    red_gravitic_drive = auto()
    red_graviton_catapult = auto()
    red_grooved_spines = auto()
    red_hi_sec_auto_tracking = auto()
    red_high_capacity_fuel_tanks = auto()
    red_hyperflight_rotors = auto()
    red_infernal_preigniter = auto()
    red_lock_on = auto()
    red_metabolic_boost = auto()
    red_muscular_augments = auto()
    red_neosteel_frame = auto()
    red_neural_parasite = auto()
    red_pathogen_glands = auto()
    red_personal_cloaking = auto()
    red_pneumatized_carapace = auto()
    red_protoss_air_armors_level1 = auto()
    red_protoss_air_armors_level2 = auto()
    red_protoss_air_armors_level3 = auto()
    red_protoss_air_weapons_level1 = auto()
    red_protoss_air_weapons_level2 = auto()
    red_protoss_air_weapons_level3 = auto()
    red_protoss_ground_armors_level1 = auto()
    red_protoss_ground_armors_level2 = auto()
    red_protoss_ground_armors_level3 = auto()
    red_protoss_ground_weapons_level1 = auto()
    red_protoss_ground_weapons_level2 = auto()
    red_protoss_ground_weapons_level3 = auto()
    red_protoss_shields_level1 = auto()
    red_protoss_shields_level2 = auto()
    red_protoss_shields_level3 = auto()
    red_psi_storm = auto()
    red_resonating_glaives = auto()
    red_shadow_strike = auto()
    red_smart_servos = auto()
    red_stimpack = auto()
    red_terran_infantry_armors_level1 = auto()
    red_terran_infantry_armors_level2 = auto()
    red_terran_infantry_armors_level3 = auto()
    red_terran_infantry_weapons_level1 = auto()
    red_terran_infantry_weapons_level2 = auto()
    red_terran_infantry_weapons_level3 = auto()
    red_terran_ship_weapons_level1 = auto()
    red_terran_ship_weapons_level2 = auto()
    red_terran_ship_weapons_level3 = auto()
    red_terran_structure_armor = auto()
    red_terran_vehicle_and_ship_armors_level1 = auto()
    red_terran_vehicle_and_ship_armors_level2 = auto()
    red_terran_vehicle_and_ship_armors_level3 = auto()
    red_terran_vehicle_weapons_level1 = auto()
    red_terran_vehicle_weapons_level2 = auto()
    red_terran_vehicle_weapons_level3 = auto()
    red_tunneling_claws = auto()
    red_warp_gate_research = auto()
    red_weapon_refit = auto()
    red_zerg_flyer_armors_level1 = auto()
    red_zerg_flyer_armors_level2 = auto()
    red_zerg_flyer_armors_level3 = auto()
    red_zerg_flyer_weapons_level1 = auto()
    red_zerg_flyer_weapons_level2 = auto()
    red_zerg_flyer_weapons_level3 = auto()
    red_zerg_ground_armors_level1 = auto()
    red_zerg_ground_armors_level2 = auto()
    red_zerg_ground_armors_level3 = auto()
    red_zerg_melee_weapons_level1 = auto()
    red_zerg_melee_weapons_level2 = auto()
    red_zerg_melee_weapons_level3 = auto()
    red_zerg_missile_weapons_level1 = auto()
    red_zerg_missile_weapons_level2 = auto()
    red_zerg_missile_weapons_level3 = auto()

    # Whether or not blue is playing as terran (bool)
    blue_is_terran = auto()
    # Whether or not blue is playing as protoss (bool)
    blue_is_protoss = auto()
    # Whether or not blue is playing as zerg (bool)
    blue_is_zerg = auto()

    # Whether or not red is playing as terran (bool)
    red_is_terran = auto()
    # Whether or not red is playing as protoss (bool)
    red_is_protoss = auto()
    # Whether or not red is playing as zerg (bool)
    red_is_zerg = auto()

    # TODO: These will necessarily have to change in dataset v4. Maybe replace with
    #       TrueSkill?
    # Whether or not the blue agent is StormProtoss (bool)
    blue_is_storm_protoss = auto()
    # Whether or not the blue agent is FocusFire (bool)
    blue_is_focus_fire = auto()
    # Whether or not the blue agent is KiteEnemy (bool)
    blue_is_kite_enemy = auto()
    # Whether or not the blue agent is AttackNearest (bool)
    blue_is_attack_nearest = auto()

    # Whether or not the red agent is StormProtoss (bool)
    red_is_storm_protoss = auto()
    # Whether or not the red agent is FocusFire (bool)
    red_is_focus_fire = auto()
    # Whether or not the red agent is KiteEnemy (bool)
    red_is_kite_enemy = auto()
    # Whether or not the red agent is AttackNearest (bool)
    red_is_attack_nearest = auto()


def get_scalar_feature_ix_from_raw(creep=False):
    """
    Returns list containing the raw indices for features not represented as bits
    in the processed data.

    :return: list with raw indices of scalar features
    """
    return (
        list(range(2, 10))
        + list(range(12, 14))
        + [15]
        + list(range(17, 27))
        + [30]
        + list(range(34, 38))
        + list(range(40, 43))
        + ([46] if creep else [])
    )


SCALAR_START = ObsIdx.health
