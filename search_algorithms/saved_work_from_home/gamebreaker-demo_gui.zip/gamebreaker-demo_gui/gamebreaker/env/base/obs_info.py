from collections import namedtuple
from enum import IntEnum

import numpy as np
import torch
from pysc2.lib.buffs import Buffs
from pysc2.lib.features import FeatureUnit
from pysc2.lib.units import Neutral
from pysc2.lib.units import Protoss
from pysc2.lib.units import Terran
from pysc2.lib.units import Zerg

from gamebreaker.env.base import CustomObsIdx
from gamebreaker.env.base import ObsIdx


class FeatureType(IntEnum):
    CATEGORICAL = 0
    SCALAR = 1
    BINARY = 2


FeatureInfo = namedtuple("FeatureInfo", ["name", "raw_idx", "proc_idx", "range", "type"])


def get_features_infos(x_max, y_max, creep=False):
    """
    Returns a map from feature name to the FeatureInfo (namedtuple) of the
    feature

    :param x_max: maximum x value in the game
    :param y_max: maximum y value in the game
    :return: map ( dict(str, FeatureInfo) ) from feature name FeatureInfo of the
    feature
    """
    infos = {
        "unit_type": FeatureInfo(
            name="unit_type",
            raw_idx=FeatureUnit.unit_type,
            proc_idx=ObsIdx.unit_type_bit0,
            range=len(ExtraUnitTypes) + len(Neutral) + len(Terran) + len(Protoss) + len(Zerg) - 1,
            type=FeatureType.CATEGORICAL,
        ),
        "alliance": FeatureInfo(
            name="alliance",
            raw_idx=FeatureUnit.alliance,
            proc_idx=ObsIdx.alliance_bit0,
            range=4,
            type=FeatureType.CATEGORICAL,
        ),
        "health": FeatureInfo(
            name="health",
            raw_idx=FeatureUnit.health,
            proc_idx=ObsIdx.health,
            range=10000,
            type=FeatureType.SCALAR,
        ),
        "shield": FeatureInfo(
            name="shield",
            raw_idx=FeatureUnit.shield,
            proc_idx=ObsIdx.shield,
            range=1000,
            type=FeatureType.SCALAR,
        ),
        "energy": FeatureInfo(
            name="energy",
            raw_idx=FeatureUnit.energy,
            proc_idx=ObsIdx.energy,
            range=1000,
            type=FeatureType.SCALAR,
        ),
        "cargo_space_taken": FeatureInfo(
            name="cargo_space_taken",
            raw_idx=FeatureUnit.cargo_space_taken,
            proc_idx=ObsIdx.cargo_space_taken,
            range=8,
            type=FeatureType.SCALAR,
        ),
        "build_progress": FeatureInfo(
            name="build_progress",
            raw_idx=FeatureUnit.build_progress,
            proc_idx=ObsIdx.build_progress,
            range=100,
            type=FeatureType.SCALAR,
        ),
        "health_ratio": FeatureInfo(
            name="health_ratio",
            raw_idx=FeatureUnit.health_ratio,
            proc_idx=ObsIdx.health_ratio,
            range=256,
            type=FeatureType.SCALAR,
        ),
        "shield_ratio": FeatureInfo(
            name="shield_ratio",
            raw_idx=FeatureUnit.shield_ratio,
            proc_idx=ObsIdx.shield_ratio,
            range=256,
            type=FeatureType.SCALAR,
        ),
        "energy_ratio": FeatureInfo(
            name="energy_ratio",
            raw_idx=FeatureUnit.energy_ratio,
            proc_idx=ObsIdx.energy_ratio,
            range=256,
            type=FeatureType.SCALAR,
        ),
        "display_type": FeatureInfo(
            name="display_type",
            raw_idx=FeatureUnit.display_type,
            proc_idx=ObsIdx.display_type_bit0,
            range=3,
            type=FeatureType.CATEGORICAL,
        ),
        "owner": FeatureInfo(
            name="owner",
            raw_idx=FeatureUnit.owner,
            proc_idx=ObsIdx.owner_bit0,
            range=16,
            type=FeatureType.CATEGORICAL,
        ),
        "x": FeatureInfo(
            name="x",
            raw_idx=FeatureUnit.x,
            proc_idx=ObsIdx.x,
            range=x_max,
            type=FeatureType.SCALAR,
        ),
        "y": FeatureInfo(
            name="y",
            raw_idx=FeatureUnit.y,
            proc_idx=ObsIdx.y,
            range=y_max,
            type=FeatureType.SCALAR,
        ),
        "facing": FeatureInfo(
            name="facing",
            raw_idx=FeatureUnit.facing,
            proc_idx=ObsIdx.facing_bit0,
            range=7,  # ?
            type=FeatureType.CATEGORICAL,
        ),
        "radius": FeatureInfo(
            name="radius",
            raw_idx=FeatureUnit.radius,
            proc_idx=ObsIdx.radius,
            range=1,
            type=FeatureType.SCALAR,
        ),
        "cloak": FeatureInfo(
            name="cloak",
            raw_idx=FeatureUnit.cloak,
            proc_idx=ObsIdx.cloak_bit0,
            range=3,
            type=FeatureType.CATEGORICAL,
        ),
        "is_selected": FeatureInfo(
            name="is_selected",
            raw_idx=FeatureUnit.is_selected,
            proc_idx=ObsIdx.is_selected,
            range=1,
            type=FeatureType.BINARY,
        ),
        "is_blip": FeatureInfo(
            name="is_blip",
            raw_idx=FeatureUnit.is_blip,
            proc_idx=ObsIdx.is_blip,
            range=1,
            type=FeatureType.BINARY,
        ),
        "is_powered": FeatureInfo(
            name="is_powered",
            raw_idx=FeatureUnit.is_powered,
            proc_idx=ObsIdx.is_powered,
            range=1,
            type=FeatureType.BINARY,
        ),
        "mineral_contents": FeatureInfo(
            name="mineral_contents",
            raw_idx=FeatureUnit.mineral_contents,
            proc_idx=ObsIdx.mineral_contents,
            range=1800,
            type=FeatureType.SCALAR,
        ),
        "vespene_contents": FeatureInfo(
            name="vespene_contents",
            raw_idx=FeatureUnit.vespene_contents,
            proc_idx=ObsIdx.vespene_contents,
            range=2250,
            type=FeatureType.SCALAR,
        ),
        "cargo_space_max": FeatureInfo(
            name="cargo_space_max",
            raw_idx=FeatureUnit.cargo_space_max,
            proc_idx=ObsIdx.cargo_space_max,
            range=40,
            type=FeatureType.SCALAR,
        ),
        "assigned_harvesters": FeatureInfo(
            name="assigned_harvesters",
            raw_idx=FeatureUnit.assigned_harvesters,
            proc_idx=ObsIdx.assigned_harvesters,
            range=40,  # ?
            type=FeatureType.SCALAR,
        ),
        "ideal_harvesters": FeatureInfo(
            name="ideal_harvesters",
            raw_idx=FeatureUnit.ideal_harvesters,
            proc_idx=ObsIdx.ideal_harvesters,
            range=40,
            type=FeatureType.SCALAR,
        ),
        "weapon_cooldown": FeatureInfo(
            name="weapon_cooldown",
            raw_idx=FeatureUnit.weapon_cooldown,
            proc_idx=ObsIdx.weapon_cooldown,
            range=130,  # ?
            type=FeatureType.SCALAR,
        ),
        "order_length": FeatureInfo(
            name="order_length",
            raw_idx=FeatureUnit.order_length,
            proc_idx=ObsIdx.order_length,
            range=2,
            type=FeatureType.SCALAR,
        ),
        "order_id_0": FeatureInfo(
            name="order_id_0",
            raw_idx=FeatureUnit.order_id_0,
            proc_idx=ObsIdx.order_id_0_bit0,
            range=1023,
            type=FeatureType.CATEGORICAL,
        ),
        "order_id_1": FeatureInfo(
            name="order_id_1",
            raw_idx=FeatureUnit.order_id_1,
            proc_idx=ObsIdx.order_id_1_bit0,
            range=1023,
            type=FeatureType.CATEGORICAL,
        ),
        "tag": FeatureInfo(
            name="tag",
            raw_idx=FeatureUnit.tag,
            proc_idx=ObsIdx.tag_bit0,
            range=511,
            type=FeatureType.CATEGORICAL,
        ),
        "hallucination": FeatureInfo(
            name="hallucination",
            raw_idx=FeatureUnit.hallucination,
            proc_idx=ObsIdx.hallucination,
            range=1,
            type=FeatureType.BINARY,
        ),
        "buff_id_0": FeatureInfo(
            name="buff_id_0",
            raw_idx=FeatureUnit.buff_id_0,
            proc_idx=ObsIdx.buff_id_0_bit0,
            range=len(Buffs) + len(ExtraBuffs) - 1,
            type=FeatureType.CATEGORICAL,
        ),
        "buff_id_1": FeatureInfo(
            name="buff_id_1",
            raw_idx=FeatureUnit.buff_id_1,
            proc_idx=ObsIdx.buff_id_1_bit0,
            range=len(Buffs) + len(ExtraBuffs) - 1,
            type=FeatureType.CATEGORICAL,
        ),
        "addon_unit_type": FeatureInfo(
            name="addon_unit_type",
            raw_idx=FeatureUnit.addon_unit_type,
            proc_idx=ObsIdx.addon_unit_type_bit0,
            range=len(Neutral) + len(Terran) + len(Protoss) + len(Zerg) + len(ExtraUnitTypes) - 1,
            type=FeatureType.CATEGORICAL,
        ),
        "active": FeatureInfo(
            name="active",
            raw_idx=FeatureUnit.active,
            proc_idx=ObsIdx.active,
            range=1,
            type=FeatureType.BINARY,
        ),
        "is_on_screen": FeatureInfo(
            name="is_on_screen",
            raw_idx=FeatureUnit.is_on_screen,
            proc_idx=ObsIdx.is_on_screen,
            range=1,
            type=FeatureType.BINARY,
        ),
        "order_progress_0": FeatureInfo(
            name="order_progress_0",
            raw_idx=FeatureUnit.order_progress_0,
            proc_idx=ObsIdx.order_progress_0,
            range=1,  # guess
            type=FeatureType.SCALAR,
        ),
        "order_progress_1": FeatureInfo(
            name="order_progress_1",
            raw_idx=FeatureUnit.order_progress_1,
            proc_idx=ObsIdx.order_progress_1,
            range=1,
            type=FeatureType.SCALAR,
        ),
        "order_id_2": FeatureInfo(
            name="order_id_2",
            raw_idx=FeatureUnit.order_id_2,
            proc_idx=ObsIdx.order_id_2_bit0,
            range=1023,
            type=FeatureType.CATEGORICAL,
        ),
        "order_id_3": FeatureInfo(
            name="order_id_3",
            raw_idx=FeatureUnit.order_id_3,
            proc_idx=ObsIdx.order_id_3_bit0,
            range=1023,
            type=FeatureType.CATEGORICAL,
        ),
        "is_in_cargo": FeatureInfo(
            name="is_in_cargo",
            raw_idx=FeatureUnit.is_in_cargo,
            proc_idx=ObsIdx.is_in_cargo,
            range=1,
            type=FeatureType.BINARY,
        ),
        "buff_duration_remain": FeatureInfo(
            name="buff_duration_remain",
            raw_idx=FeatureUnit.buff_duration_remain,
            proc_idx=ObsIdx.buff_duration_remain,
            range=256,  # guess
            type=FeatureType.SCALAR,
        ),
        "buff_duration_max": FeatureInfo(
            name="buff_duration_max",
            raw_idx=FeatureUnit.buff_duration_max,
            proc_idx=ObsIdx.buff_duration_max,
            range=256,  # guess
            type=FeatureType.SCALAR,
        ),
        "attack_upgrade_level": FeatureInfo(
            name="attack_upgrade_level",
            raw_idx=FeatureUnit.attack_upgrade_level,
            proc_idx=ObsIdx.attack_upgrade_level_bit0,
            range=3,
            type=FeatureType.CATEGORICAL,
        ),
        "armor_upgrade_level": FeatureInfo(
            name="armor_upgrade_level",
            raw_idx=FeatureUnit.armor_upgrade_level,
            proc_idx=ObsIdx.armor_upgrade_level_bit0,
            range=3,
            type=FeatureType.CATEGORICAL,
        ),
        "shield_upgrade_level": FeatureInfo(
            name="shield_upgrade_level",
            raw_idx=FeatureUnit.shield_upgrade_level,
            proc_idx=ObsIdx.shield_upgrade_level_bit0,
            range=3,
            type=FeatureType.CATEGORICAL,
        ),
    }
    if creep:
        infos["on_creep"] = (
            FeatureInfo(
                name="on_creep",
                raw_idx=max(FeatureUnit) + 1,
                proc_idx=CustomObsIdx.on_creep,
                range=1,
                type=FeatureType.BINARY,
            )
            if creep
            else None,
        )
    return infos


def get_bit_length(x_max, y_max):
    """
    Returns a map from feature name to the number of bits it is represented by
    in the processed data.

    :param x_max: maximum x value in the game
    :param y_max: maximum y value in the game
    :return: map ( dict(str, int) ) from feature name to number of bits
    representing the feature.
    """
    info_map = get_features_infos(x_max, y_max)
    return {
        f: int(np.ceil(np.log2(info_map[f].range + 1)))
        for f in info_map
        if info_map[f].type == FeatureType.CATEGORICAL
    }


def get_feature_ranges(x_max, y_max, creep=False):
    """
    Returns a torch.Tensor with the maximum allowed value of each feature at the
    same index of the torch.Tensor as the feature in the data.

    :param x_max: maximum x value in the game
    :param y_max: maximum y value in the game
    :return: torch.Tensor with maximum allowed value of each feature
    """
    info_map = get_features_infos(x_max, y_max)
    bit_length = get_bit_length(x_max, y_max)
    num_proc_features = sum(
        [
            bit_length[f] if f in bit_length else (1 if creep else (0 if f == "on_creep" else 1))
            for f in info_map
        ]
    )
    ranges = torch.ones(num_proc_features)
    for f in info_map:
        info = info_map[f]
        if info.type == FeatureType.SCALAR:
            if creep or (not creep and info.name != "on_creep"):
                ranges[info.proc_idx] = info.range
    return ranges


class ExtraBuffs(IntEnum):
    NoBuff = 0


class ExtraUnitTypes(IntEnum):
    MineralShard = 1680
    NoUnit = 0
