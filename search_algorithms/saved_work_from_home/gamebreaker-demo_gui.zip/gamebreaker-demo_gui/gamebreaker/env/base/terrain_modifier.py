# Copyright (C) 2020 Heron Systems, Inc.
from abc import ABC
from abc import abstractmethod
from typing import List
from typing import Tuple
from typing import Union

import numpy as np
from pysc2.lib import features
from pysc2.lib import units

# Forward declare MicroBattleEnv
class MicroBattleEnv(object):
    pass


class TerrainModifier(ABC):
    """
    Base class for a TerrainModifier, used to modify terrains for
    pysc2.sc2_env.SC2Env objects.

    To modify terrains, you'll want to extend this class and implement the modify()
    method below.
    """

    @abstractmethod
    def modify(self, env: MicroBattleEnv):
        """
        This is the function that you invoke to modify env. It is automatically
        invoked in MicroBattleEnv.

        NOTE: in this function, any terrain modifications must be made only via neutral
        units. No unit/building modifications can be made to a player's army; otherwise,
        you'll end up with strange errors in MicroBattleEnv.
        """
        ...


class AddMultichoke(TerrainModifier):
    # If you'd like to use a unit blocker not present in this list below, feel free to
    # experiment and add an entry to the below list.
    SPACING_MAP = {units.Neutral.XelNagaTower: 2}

    def __init__(
        self,
        start_xy: Union[Tuple, np.array],
        segment_lengths: List,
        orientation: str = "right",
        thickness: int = 1,
        unit_blocker: units.Neutral = units.Neutral.XelNagaTower,
    ):
        """
        A Multichoke is best defined by example:

        .......................................
        .......................................
        ..xxx..xxxxx....xxxxxx.....xxx....x....
        .......................................
        .......................................
        .......................................

        Suppose that we wish to create a map similar to the above, where . represents open
        field while x represents a barrier of some kind. The following AddMultichoke
        terrain modifier would be what you'd want:

        start_xy = (2, 3)
        segment_lengths = [3, 2, 5, 4, 6, 5, 3, 4, 1]
        orientation = "right"
        tmod = AddMultichoke(start_xy, segment_lengths, orientation)

        To see why:

        (1) start_xy represents the "starting point" for the multichoke; the **bottom
        left** of the world is defined as (0, 0) with the x-axis pointing right and the
        y-axis pointing up. The left-most x is at (2, 3) so the starting point is (2, 3).

        (2) to understand segment_lengths, look at the multichoke:

        ..xxx..xxxxx....xxxxxx.....xxx....x....

        We have 3 x's, 2 blanks, 5 x's, 4 blanks, 6 x's, 5 blanks, 3 x's, 4 blanks, and 1
        x. This yields segment_lengths of [3, 2, 5, 4, 6, 5, 3, 4, 1]. segment_lengths
        simply needs to have positive length:

        segment_lengths = [10] creates a wall with no gaps of size 10
        segment_lengths = [10, 1, 10] creates a wall with a tiny choke point with size 1
        segment_lengths = [10, 5] is silly; you have a wall of size 10; the 5 is ignored;
                          you may as well have just done segment_lengths = [10]

        (3) Because orientation is set to "right", the multichoke starts at start_xy and
        goes to the right. If the orientation was set to "left", the multichoke would go
        leftwards. The same for "up" and "down."

        (4) Unit blocker; ok, this one is hard to draw with ASCII characters :) In game,
        each x needs to be a neutral unit of some kind. Unit blocker is that neutral unit.

        This object is called a multichoke, as it represents "multiple choke points." Of
        course, if the gaps are set wide enough, you don't really have choke points at
        all.

        NOTE: one subtlety of multichokes is that segment length does not refer to world
        coordinates. Rather, segment_length refers to the number of unit_blockers/blanks
        that are placed. So, when working with the following:

        ..xxx..xxxxx....xxxxxx.....xxx....x....

        What we really mean is that we have 3, e.g., XelNagaTowers, 2 blanks (blanks have
        width 1 world-unit), 5 XelNagaTowers, 4 blanks, etc.

        :param start_xy: starting point of multichoke
        :param segment_lengths: multichoke segment lengths
        :param orientation: orientation of the multichoke
        :param thickness: the thickness of the multichoke
        :param unit_blocker: this is the type of unit that will be used in creating walls
        """
        self.unit_blocker = unit_blocker
        self.start_xy = start_xy
        self.segment_lengths = segment_lengths
        self.thickness = thickness

        # Determine the direction in which the wall should be built
        orientation_map = {
            "left": (-1, 0),
            "right": (1, 0),
            "up": (0, 1),
            "down": (0, -1),
        }
        if orientation not in orientation_map:
            raise ValueError(f"Orientation = {orientation} not in {list(orientation_map.keys())}.")

        self.orientation = orientation
        self._dvec = np.array(orientation_map[orientation], dtype=np.int32)

    def modify(self, env: MicroBattleEnv):
        start_xy = np.array(self.start_xy, dtype=np.int32)
        expected_units = []

        for segment_ix in range(len(self.segment_lengths)):
            if segment_ix % 2 == 0:
                for cur_ix in range(self.segment_lengths[segment_ix]):
                    loc = (
                        start_xy
                        + AddMultichoke.SPACING_MAP[self.unit_blocker] * cur_ix * self._dvec
                    )

                    for thickness_ix in range(self.thickness):
                        cur_loc = (
                            loc
                            + self._dvec[::-1]
                            * thickness_ix
                            * AddMultichoke.SPACING_MAP[self.unit_blocker]
                        )

                        if (
                            0 <= cur_loc[0] < env.world_size[0]
                            and 0 <= cur_loc[1] < env.world_size[1]
                        ):
                            env.create_neutral_units(
                                units.Neutral.XelNagaTower, tuple(cur_loc),
                            )
                            expected_units.append(units.Neutral.XelNagaTower)

                start_xy += (
                    AddMultichoke.SPACING_MAP[self.unit_blocker] * self.segment_lengths[segment_ix]
                ) * self._dvec
            else:
                start_xy += self.segment_lengths[segment_ix] * self._dvec

                # NOTE: this is a hack that allows walls to be aligned when orientation is
                # specified as up. For some reason, SC2 doesn't align XelNaga towers
                # properly without this hack.
                if self.orientation == "up":
                    start_xy[0] += 1

        return expected_units


class AddWall(AddMultichoke):
    def __init__(
        self,
        start_xy: Union[Tuple, np.array],
        length: int,
        orientation: str = "right",
        unit_blocker: units.Neutral = units.Neutral.XelNagaTower,
    ):
        """
        Add a wall to your environment. A wall is a Multichoke with no gaps.

        :param start_xy: starting point of multichoke
        :param length: length of the wall
        :param orientation: starting point of multichoke
        :param unit_blocker: this is the type of unit that will be used in creating walls
        """
        super().__init__(
            start_xy, [length], orientation=orientation, unit_blocker=unit_blocker,
        )


class AddSingleBlocker(AddWall):
    def __init__(
        self, loc: Union[Tuple, np.array], unit_blocker: units.Neutral = units.Neutral.XelNagaTower,
    ):
        """
        Add a single blocker to your environment.

        :param loc: location of the blocker
        :param unit_blocker: this is the type of blocker unit
        """
        super().__init__(
            loc, 1, unit_blocker=unit_blocker,
        )


class AddSingleCreepTumor(TerrainModifier):
    def __init__(self, xy: Union[Tuple, np.array]):
        """
        Add a single creep tumor to your environment.

        :param xy: location of creep tumor
        """
        self.xy = xy

    def modify(self, env: MicroBattleEnv):
        env.create_units(
            units.Zerg.CreepTumorBurrowed,
            env.neutral_owner_id,
            tuple(self.xy),
            quantity=1,
            player=0,
        )
        return [units.Zerg.CreepTumorBurrowed]


class AddCreepRectangle(TerrainModifier):
    CREEP_SEPARATION = 3

    def __init__(
        self, start_xy: Union[Tuple, np.array], width: int, height: int,
    ):
        """
        Add creep to your environment.

        :param start_xy: starting point of creep (bottom left)
        :param width: width of creep region
        :param height: height of creep region
        """
        self.start_xy = start_xy
        self.width = width
        self.height = height

    def modify(self, env: MicroBattleEnv):
        expected_units = []
        for dx in range(
            AddCreepRectangle.CREEP_SEPARATION, self.width, AddCreepRectangle.CREEP_SEPARATION,
        ):
            for dy in range(
                AddCreepRectangle.CREEP_SEPARATION, self.height, AddCreepRectangle.CREEP_SEPARATION,
            ):
                loc_x = self.start_xy[0] + dx
                loc_y = self.start_xy[1] + dy

                if 0 <= loc_x < env.world_size[0] and 0 <= loc_y < env.world_size[1]:
                    env.create_units(
                        units.Zerg.CreepTumorBurrowed,
                        env.neutral_owner_id,
                        (loc_x, loc_y),
                        quantity=1,
                        player=0,
                    )
                    expected_units.append(units.Zerg.CreepTumorBurrowed)

        return expected_units
