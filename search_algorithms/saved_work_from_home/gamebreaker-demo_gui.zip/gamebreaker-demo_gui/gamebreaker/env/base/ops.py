from itertools import chain

import torch
from adept.preprocess.base.ops import MultiOperation
from adept.preprocess.base.ops import SimpleOperation
from pysc2.lib.buffs import Buffs
from pysc2.lib.units import Neutral
from pysc2.lib.units import Protoss
from pysc2.lib.units import Terran
from pysc2.lib.units import Zerg

from .obs_idx import CustomObsIdx
from .obs_idx import get_scalar_feature_ix_from_raw
from .obs_idx import ObsIdx
from .obs_idx import SCALAR_START
from .obs_info import ExtraBuffs
from .obs_info import ExtraUnitTypes
from .obs_info import get_bit_length
from .obs_info import get_feature_ranges
from .obs_info import get_features_infos
from .obs_utils import cat_to_bin


class CreateEmptyArray(SimpleOperation):
    def __init__(self, seq_len, input_field, output_field, creep=False):
        super().__init__(input_field, output_field)
        self.seq_len = seq_len
        self.creep = creep

    def update_shape(self, old_shape):
        return self.seq_len, (len(ObsIdx) + len(CustomObsIdx) if self.creep else len(ObsIdx))

    def update_dtype(self, old_dtype):
        return old_dtype

    def preprocess_cpu(self, tensor):
        return torch.zeros(
            size=(self.seq_len, (len(ObsIdx) + len(CustomObsIdx) if self.creep else len(ObsIdx)),)
        )

    def preprocess_gpu(self, tensor):
        return torch.zeros(
            size=(self.seq_len, (len(ObsIdx) + len(CustomObsIdx) if self.creep else len(ObsIdx)),)
        )


class ProcessCategoricalFeatures(MultiOperation):
    def __init__(self, x_max, y_max, input_fields, output_fields):
        super().__init__(input_fields, output_fields)

        self._id_to_unit_types = dict(
            enumerate(chain(Neutral, Terran, Protoss, Zerg, ExtraUnitTypes))
        )
        self._unit_type_to_ids = {v: k for k, v in self._id_to_unit_types.items()}

        self._id_to_buffs = dict(enumerate(chain(Buffs, ExtraBuffs)))
        self._buff_to_ids = {v: k for k, v in self._id_to_buffs.items()}

        self._tag_to_ids = {}
        self._id_to_tags = {}
        self._cur_id = 0

        self.info_map = get_features_infos(x_max, y_max)
        self.bit_length = get_bit_length(x_max, y_max)

    def update_shape(self, old_shape):
        return [old_shape[1]]

    def update_dtype(self, old_dtype):
        return [old_dtype[1]]

    def preprocess_cpu(self, tensors):
        tensors = [tensors[0].clone(), tensors[1].clone()]
        for i, units in enumerate(zip(tensors[0], tensors[1])):
            raw_unit, proc_unit = units
            for feature in self.bit_length:
                info = self.info_map[feature]
                uid = self.get_id(int(raw_unit[info.raw_idx].item()), feature)
                _, offset = cat_to_bin(
                    uid, self.bit_length[feature], out=proc_unit, start_idx=info.proc_idx,
                )
        return [tensors[1]]

    def preprocess_gpu(self, tensors):
        raise NotImplemented

    def get_tag_id(self, tag):
        if tag in self._tag_to_ids:
            out = self._tag_to_ids[tag]
        else:
            self._tag_to_ids[tag] = self._cur_id
            self._id_to_tags[self._cur_id] = tag
            out = self._cur_id
            self._cur_id += 1
        return out

    def get_unit_type_id(self, raw_unit_id):
        return self._unit_type_to_ids[raw_unit_id]

    def get_buff_id(self, raw_buff_id):
        return self._buff_to_ids[raw_buff_id]

    def get_id(self, raw_id, name):
        if "tag" == name:
            return self.get_tag_id(raw_id)
        elif "unit_type" in name:
            return self.get_unit_type_id(raw_id)
        elif "buff_id" in name:
            return self.get_buff_id(raw_id)
        else:
            return raw_id

    def reset(self):
        self._tag_to_ids = {}
        self._id_to_tags = {}
        self._cur_id = 0


class CopyOverScalarFeatures(MultiOperation):
    def __init__(self, input_fields, output_fields, creep=False):
        super().__init__(input_fields, output_fields)

        self.creep = creep
        self.scalar_features = get_scalar_feature_ix_from_raw(creep=self.creep)

    def update_shape(self, old_shape):
        return [old_shape[1]]

    def update_dtype(self, old_dtype):
        return [old_dtype[1]]

    def preprocess_cpu(self, tensors):
        tensors = [tensors[0].clone(), tensors[1].clone()]
        tensors[1][: tensors[0].shape[0], SCALAR_START:] = tensors[0][:, self.scalar_features]
        return [tensors[1]]

    def preprocess_gpu(self, tensors):
        tensors = [tensors[0].clone(), tensors[1].clone()]
        tensors[1][:, : tensors[0].shape[0], SCALAR_START:] = tensors[0][:, :, self.scalar_features]
        return [tensors[1]]


class ProcessScalarFeatures(SimpleOperation):
    def __init__(self, x_max, y_max, input_field, output_field, creep=False):
        super().__init__(input_field, output_field)

        self.creep = creep
        self.ranges = get_feature_ranges(x_max, y_max, creep=self.creep)

    def update_shape(self, old_shape):
        return old_shape

    def update_dtype(self, old_dtype):
        return old_dtype

    def preprocess_cpu(self, tensor):
        tensor = tensor.clone()
        return torch.div(tensor, self.ranges)

    def preprocess_gpu(self, tensor):
        tensor = tensor.clone()
        return torch.div(tensor, self.ranges)

    def to(self, device):
        self.ranges = self.ranges.to(device)
        return self


class FilterForNet(SimpleOperation):
    def update_shape(self, old_shape):
        return None

    def update_dtype(self, old_dtype):
        return None

    def preprocess_cpu(self, tensor):
        # del tensor
        return None

    def preprocess_gpu(self, tensor):
        # del tensor
        return None


class PermuteToFS(SimpleOperation):
    def update_shape(self, old_shape):
        if len(old_shape) == 2:
            s, f = 0, 1
            return old_shape[f], old_shape[s]
        elif len(old_shape == 3):
            b, s, f = 0, 1, 2
            return old_shape[b], old_shape[f], old_shape[s]
        else:
            raise Exception(f"Unrecognized shape {old_shape}")

    def update_dtype(self, old_dtype):
        return old_dtype

    def preprocess_cpu(self, tensor):
        tensor = tensor.clone()
        s, f = 0, 1
        return tensor.permute(f, s)

    def preprocess_gpu(self, tensor):
        tensor = tensor.clone()
        b, s, f = 0, 1, 2
        return tensor.permute(b, f, s)
