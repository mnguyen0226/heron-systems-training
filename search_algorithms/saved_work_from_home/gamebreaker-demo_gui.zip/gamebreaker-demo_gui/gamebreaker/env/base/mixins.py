# Copyright (C) 2020 Heron Systems, Inc.
from s2clientprotocol import common_pb2 as sc_common
from s2clientprotocol import debug_pb2 as sc_debug

_NEUTRAL_OWNER_ID = 0


class SC2DebugMixin(object):
    def _debug(self, player=0, **kwargs):
        return self._controllers[player].debug([sc_debug.DebugCommand(**kwargs)])

    def create_units(self, unit_type, owner, pos, quantity=1, player=0):
        if isinstance(pos, tuple):
            pos = sc_common.Point2D(x=pos[0], y=pos[1])
        elif isinstance(pos, sc_common.Point):
            pos = sc_common.Point2D(x=pos.x, y=pos.y)
        return self._debug(
            create_unit=sc_debug.DebugCreateUnit(
                unit_type=unit_type, owner=owner, pos=pos, quantity=quantity
            ),
            player=player,
        )

    def create_neutral_units(self, unit_type, pos, quantity=1):
        # Let's just have player 0 create the neutral units
        return self.create_units(unit_type, _NEUTRAL_OWNER_ID, pos, quantity=quantity, player=0)

    def kill_units(self, unit_tags):
        if not isinstance(unit_tags, (list, tuple)):
            unit_tags = [unit_tags]
        return self._debug(kill_unit=sc_debug.DebugKillUnit(tag=unit_tags))

    def set_unit_value(self, unit_tags, field, value):
        if type(unit_tags) not in [list, tuple]:
            unit_tags = [unit_tags]
        unit_value = {"energy": 1, "life": 2, "shields": 3}[field]
        for unit_tag in unit_tags:
            self._debug(
                unit_value=sc_debug.DebugSetUnitValue(
                    unit_value=unit_value, value=float(value), unit_tag=unit_tag
                )
            )

    def switch_sides(self, player=1):
        return self._debug(game_state=sc_debug.DebugGameState, player=player)

    def eliminate_costs(self, player=0):
        return self._debug(player=player, game_state=4)

    def eliminate_tech_tree(self, player=0):
        return self._debug(player=player, game_state=10)

    def upgrade_units(self, player=0):
        return self._debug(player=player, game_state=11)

    def fast_build(self, player=0):
        return self._debug(player=player, game_state=12)

    def god(self, player=0):
        return self._debug(player=player, game_state=6)
