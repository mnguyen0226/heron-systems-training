# Copyright (C) 2020 Heron Systems, Inc.
import collections
import itertools
import math
from typing import Dict
from typing import List
from typing import Tuple

import numpy as np
import torch
from absl import logging
from adept.preprocess import CPUPreprocessor
from adept.preprocess import GPUPreprocessor
from adept.preprocess.ops import CastToFloat
from adept.preprocess.ops import FromNumpy
from adept.utils.util import DotDict
from pysc2.env import environment
from pysc2.lib import colors
from pysc2.lib import metrics
from pysc2.lib import point
from pysc2.lib import stopwatch
from pysc2.lib.features import FeatureUnit
from pysc2.lib.renderer_human import clamp
from pysc2.lib.renderer_human import RendererHuman
from s2clientprotocol import raw_pb2 as sc_raw

from gamebreaker.agent import AGENT_LIST
from gamebreaker.classifier.utils.common_utils import create_upgrades_vec
from gamebreaker.classifier.utils.common_utils import get_context_vector
from gamebreaker.classifier.utils.common_utils import get_network
from gamebreaker.classifier.utils.common_utils import get_old_args
from gamebreaker.classifier.utils.common_utils import get_path_from_args
from gamebreaker.classifier.utils.common_utils import get_races_encoding
from gamebreaker.env.base.ops import CopyOverScalarFeatures
from gamebreaker.env.base.ops import CreateEmptyArray
from gamebreaker.env.base.ops import FilterForNet
from gamebreaker.env.base.ops import PermuteToFS
from gamebreaker.env.base.ops import ProcessCategoricalFeatures
from gamebreaker.env.base.ops import ProcessScalarFeatures
from gamebreaker.env.micro_battle_env import MicroBattleEnv
from gamebreaker.selector import RandomUpgradeSelector
from gamebreaker.selector import Selector

observation_space = {"raw_units": (None, len(FeatureUnit))}
observation_dtypes = {"raw_units": np.int64}

UNIT_MAX = 512

sw = stopwatch.sw

MODIFIED_PLAYER_PALETTE = np.array(
    [
        colors.Color(0, 0, 0),
        colors.Color(74, 169, 247),
        colors.Color(113, 25, 34),  # 2: Red
        colors.Color(223, 215, 67),  # 3: Yellow
        colors.Color(66, 26, 121),  # 4: Purple
        colors.Color(222, 144, 50),  # 5: Orange
        colors.Color(46, 72, 237),  # 6: Blue
        colors.Color(207, 111, 176),  # 7: Pink
        colors.Color(189, 251, 157),  # 8: Light green
        colors.white * 0.1,  # 9: Does the game ever have more than 8 players?
        colors.white * 0.1,  # 10: Does the game ever have more than 8 players?
        colors.white * 0.1,  # 11: Does the game ever have more than 8 players?
        colors.white * 0.1,  # 12: Does the game ever have more than 8 players?
        colors.white * 0.1,  # 13: Does the game ever have more than 8 players?
        colors.white * 0.1,  # 14: Does the game ever have more than 8 players?
        colors.white * 0.1,  # 15: Does the game ever have more than 8 players?
        colors.Color(145, 145, 145),  # 16 Neutral: Cyan
    ]
)


class WinProbRenderer(RendererHuman):
    def __init__(
        self, fps=22.4, step_mul=1, render_sync=False, render_feature_grid=True, video=None,
    ):
        """This class renders the win probability bar when using the winprob_env

        Parameters
        ----------
        fps : float, optional
            frames per second to render, by default 22.4
        step_mul : int, optional
            multiplier to step the environment by per step, by default 1
        render_sync : bool, optional
            whether to wait for the obs to render before continuing, by default False
        render_feature_grid : bool, optional
            When RGB and feature layers are available, whether to render the grid of feature layers.
            by default True
        video : string, optional
            A filename to write the video to. Implicitly enables render_sync., by default True, by
            default None
        """
        super().__init__(
            fps=fps,
            step_mul=step_mul,
            render_sync=render_sync,
            render_feature_grid=render_feature_grid,
            video=video,
        )

        self._predictions = {}

    def draw_screen(self, surf):
        """Draw the screen

        Parameters
        ----------
        surf : _Surface
            Surface to draw on
        """
        if (
            self._render_rgb
            and self._obs.observation.HasField("render_data")
            and self._obs.observation.render_data.HasField("map")
        ):
            self.draw_rendered_map(surf)
        else:
            self.draw_base_map(surf)
            self.draw_effects(surf)
            self.draw_units(surf)

        if self._predictions != {}:
            self.draw_predictions(surf)

    @sw.decorate
    def draw_units(self, surf):
        """Draw the units and buildings.

        Parameters
        ----------
        surf : _Surface
            Surface to draw on
        """
        unit_dict = None  # Cache the units {tag: unit_proto} for orders.
        tau = 2 * math.pi
        for u, p in self._visible_units():
            if self._camera.intersects_circle(p, u.radius):
                fraction_damage = clamp((u.health_max - u.health) / (u.health_max or 1), 0, 1)
                if u.display_type == sc_raw.Placeholder:
                    surf.draw_circle(MODIFIED_PLAYER_PALETTE[u.owner] // 3, p, u.radius)
                else:
                    surf.draw_circle(MODIFIED_PLAYER_PALETTE[u.owner], p, u.radius)

                    if fraction_damage > 0:
                        surf.draw_circle(
                            MODIFIED_PLAYER_PALETTE[u.owner] // 2, p, u.radius * fraction_damage
                        )
                surf.draw_circle(colors.black, p, u.radius, thickness=1)

                if self._static_data.unit_stats[u.unit_type].movement_speed > 0:
                    surf.draw_arc(
                        colors.white, p, u.radius, u.facing - 0.1, u.facing + 0.1, thickness=1
                    )

                def draw_arc_ratio(color, world_loc, radius, start, end, thickness=1):
                    surf.draw_arc(color, world_loc, radius, start * tau, end * tau, thickness)

                if u.shield and u.shield_max:
                    draw_arc_ratio(colors.blue, p, u.radius - 0.05, 0, u.shield / u.shield_max)
                if u.energy and u.energy_max:
                    draw_arc_ratio(
                        colors.purple * 0.9, p, u.radius - 0.1, 0, u.energy / u.energy_max
                    )
                if 0 < u.build_progress < 1:
                    draw_arc_ratio(colors.cyan, p, u.radius - 0.15, 0, u.build_progress)
                elif u.orders and 0 < u.orders[0].progress < 1:
                    draw_arc_ratio(colors.cyan, p, u.radius - 0.15, 0, u.orders[0].progress)

                if u.buff_duration_remain and u.buff_duration_max:
                    draw_arc_ratio(
                        colors.white,
                        p,
                        u.radius - 0.2,
                        0,
                        u.buff_duration_remain / u.buff_duration_max,
                    )

                if u.attack_upgrade_level:
                    draw_arc_ratio(
                        self.upgrade_colors[u.attack_upgrade_level],
                        p,
                        u.radius - 0.25,
                        0.18,
                        0.22,
                        thickness=3,
                    )

                if u.armor_upgrade_level:
                    draw_arc_ratio(
                        self.upgrade_colors[u.armor_upgrade_level],
                        p,
                        u.radius - 0.25,
                        0.23,
                        0.27,
                        thickness=3,
                    )

                if u.shield_upgrade_level:
                    draw_arc_ratio(
                        self.upgrade_colors[u.shield_upgrade_level],
                        p,
                        u.radius - 0.25,
                        0.28,
                        0.32,
                        thickness=3,
                    )

                def write_small(loc, s):
                    surf.write_world(self._font_small, colors.white, loc, str(s))

                name = self.get_unit_name(
                    surf, self._static_data.units.get(u.unit_type, "<none>"), u.radius
                )
                if name:
                    write_small(p, name)
                if u.ideal_harvesters > 0:
                    write_small(
                        p + point.Point(0, 0.5),
                        "%s / %s" % (u.assigned_harvesters, u.ideal_harvesters),
                    )
                if u.mineral_contents > 0:
                    write_small(p - point.Point(0, 0.5), u.mineral_contents)
                elif u.vespene_contents > 0:
                    write_small(p - point.Point(0, 0.5), u.vespene_contents)
                elif u.display_type == sc_raw.Snapshot:
                    write_small(p - point.Point(0, 0.5), "snapshot")
                elif u.display_type == sc_raw.Placeholder:
                    write_small(p - point.Point(0, 0.5), "placeholder")
                elif u.is_hallucination:
                    write_small(p - point.Point(0, 0.5), "hallucination")
                elif u.is_burrowed:
                    write_small(p - point.Point(0, 0.5), "burrowed")
                elif u.cloak != sc_raw.NotCloaked:
                    write_small(p - point.Point(0, 0.5), "cloaked")

                if u.is_selected:
                    surf.draw_circle(colors.green, p, u.radius + 0.1, 1)

                    # Draw the orders of selected units.
                    start_point = p
                    for o in u.orders:
                        target_point = None
                        if o.HasField("target_world_space_pos"):
                            target_point = point.Point.build(o.target_world_space_pos)
                        elif o.HasField("target_unit_tag"):
                            if unit_dict is None:
                                unit_dict = {t.tag: t for t in self._obs.observation.raw_data.units}
                            target_unit = unit_dict.get(o.target_unit_tag)
                            if target_unit:
                                target_point = point.Point.build(target_unit.pos)
                        if target_point:
                            surf.draw_line(colors.cyan * 0.75, start_point, target_point)
                            start_point = target_point
                        else:
                            break
                    for rally in u.rally_targets:
                        surf.draw_line(colors.cyan * 0.75, p, point.Point.build(rally.point))

    def draw_predictions(self, surf):
        """Draw the prediction bars for each output

        Parameters
        ----------
        surf : _Surface
            Surface to draw on
        """
        line = itertools.count(2)

        def write(loc, key, bar_color):

            nb_lines = 350
            nb_blue_lines = round(nb_lines * self._predictions[key])

            surf.write_screen(self._font_large, colors.white, loc, f"{key}:")
            for i in range(nb_lines):
                if i % (nb_lines // 10) < 2:
                    color = colors.black
                elif i < nb_blue_lines:
                    color = bar_color[0]
                else:
                    color = bar_color[1]
                surf.write_screen(self._font_large, color, (7.2 + 0.05 * i, loc[1]), "|")

        def write_line(x, *args, **kwargs):
            write((x, next(line)), *args, **kwargs)

        write_line(0.2, "win", [colors.blue, colors.red])
        write_line(0.2, "b_attrition", [colors.blue, colors.black])
        write_line(0.2, "b_minerals", [colors.blue, colors.black])
        write_line(0.2, "b_gas", [colors.blue, colors.black])
        write_line(0.2, "r_attrition", [colors.red, colors.black])
        write_line(0.2, "r_minerals", [colors.red, colors.black])
        write_line(0.2, "r_gas", [colors.red, colors.black])


class WinProbEnv(MicroBattleEnv):
    def __init__(
        self,
        world_size: Tuple[int, int],
        selectors: Tuple[Selector],
        upgrade_selectors: List[RandomUpgradeSelector],
        agent_info: List[Tuple[str, str]],
        race_info: torch.Tensor,
        network_args: DotDict,
        save_replay_info: Dict[str, str] = None,
        *args,
        **kwargs,
    ):
        """Environment for running SC2 matches with the WinProb Classifier predictions shown

        Parameters
        ----------
        world_size : Tuple[int, int]
            Size of the world to generate
        selectors : Tuple[Selector]
            selector[i] is used to create the units for army i.
        upgrade_selectors : List[UpgradeSelector]
            upgrade_selector[i] is used to choose the upgrades for army i
        agent_info : List[Tuple[str, str]]
            List of the agents used in the match
        race_info : torch.Tensor
            Races used in the match
        network_args : DotDict
            Stored arguments for the network to test
        save_replay_info : Dict[str, str], optional
            location to save the replay info to, by default None
        """
        super().__init__(world_size, selectors, upgrade_selectors, *args, **kwargs)
        # Grab the model path
        model_path = get_path_from_args(network_args)

        # Grab the old arguments and merge our new ones
        network_args = get_old_args(network_args, model_path)

        # Build the network
        self._network = get_network(network_args, model_path)
        self._network.eval()

        self._network_args = network_args
        self._gpu_id = network_args.gpu_id
        self._agent_info = agent_info
        self._race_info = torch.reshape(race_info, (1, -1))
        self.save_replay_info = save_replay_info

        self.cpu_preprocessor = CPUPreprocessor(
            [
                FromNumpy("raw_units", "raw_units"),
                CreateEmptyArray(UNIT_MAX, "raw_units", "proc_units", creep=True),
                ProcessCategoricalFeatures(
                    world_size[0], world_size[1], ["raw_units", "proc_units"], ["proc_units"],
                ),
                CopyOverScalarFeatures(["raw_units", "proc_units"], ["proc_units"], creep=True),
                FilterForNet("raw_units", "raw_units"),
            ],
            observation_space,
            observation_dtypes,
        )
        self.gpu_preprocessor = GPUPreprocessor(
            [
                ProcessScalarFeatures(
                    world_size[0], world_size[1], "proc_units", "proc_units", creep=True,
                ),
                CastToFloat("proc_units", "proc_units"),
                PermuteToFS("proc_units", "proc_units"),
            ],
            self.cpu_preprocessor.observation_space,
            self.cpu_preprocessor.observation_dtypes,
        )

        self.predictions = {}
        self._resetting = True

    def reset(self, hard_reset: bool = False):
        """Resets the environment

        This either performs a soft reset by removing all the units on the field, or performs a hard
        reset to completely clear the environment

        Parameters
        ----------
        hard_reset : bool, optional
            whether or not to hard reset the environment instance, by default False

        Returns
        -------
        the timestep with all units killed and created
        """
        self._resetting = True
        temp = super().reset(hard_reset=hard_reset)
        self._resetting = False
        return temp

    def _finalize(self, visualize):
        """Finalize and reset the fields of the WinProbEnv

        Parameters
        ----------
        visualize : Boolean
            If true, will create the WinProbRenderer
        """
        self._delayed_actions = [collections.deque() for _ in self._action_delay_fns]

        if visualize:
            # Only change from the super.super._finalize()
            self._renderer_human = WinProbRenderer()
            self._renderer_human.init(self._controllers[0].game_info(), self._controllers[0].data())
        else:
            self._renderer_human = None

        self._metrics = metrics.Metrics(self._map_name)
        self._metrics.increment_instance()

        self._last_score = None
        self._total_steps = 0
        self._episode_steps = 0
        self._episode_count = 0
        self._obs = [None] * self._num_agents
        self._agent_obs = [None] * self._num_agents
        self._state = environment.StepType.LAST  # Want to jump to `reset`.
        logging.info("Environment is ready")

    @torch.no_grad()
    def _predict(self):
        """Predicts the results of the match using the WinProb Classifier"""
        upgrade_list = [
            self.timestep[0].observation.upgrades,
            self.timestep[1].observation.upgrades,
        ]
        upgrades_vec = create_upgrades_vec(upgrade_list)
        upgrades_vec = torch.from_numpy(upgrades_vec)
        upgrades_vec = torch.reshape(upgrades_vec, (1, -1))
        context_vec = get_context_vector(upgrades_vec, self._race_info, self._agent_info)
        context_vec = context_vec.float().to(self._gpu_id)

        unit_list = self.timestep[0].observation.raw_units

        obs = self.cpu_preprocessor({"raw_units": unit_list})
        obs = self.gpu_preprocessor(
            {
                "proc_units": torch.reshape(
                    obs["proc_units"],
                    (-1, obs["proc_units"].shape[0], obs["proc_units"].shape[1],),
                )
            }
        )

        temp = self._network.forward(
            {"units": obs["proc_units"].to(self._gpu_id), "upgrades": context_vec,}, {},
        )

        for key in temp[0]:
            pred = temp[0][key].squeeze(-1)
            pred = torch.sigmoid(pred)
            self.predictions[key] = float(pred.cpu())

    def _step(self, step_mul=None):
        """Step the environment and perform a prediction

        Parameters
        ----------
        step_mul : int, optional
            multiplier to step by, by default None

        Returns
        -------
        The next timestepped env
        """
        if not self._resetting:
            self._predict()
            self._renderer_human._predictions = self.predictions
        return super()._step(step_mul=step_mul)
