# Copyright (C) 2020 Heron Systems, Inc.
from typing import Tuple

from pysc2.env.environment import TimeStep
from pysc2.lib import features
from pysc2.lib import units
from pysc2.lib.actions import FunctionCall
from pysc2.lib.actions import Queued
from pysc2.lib.actions import RAW_FUNCTIONS

# Forward declarations
class MicroBattleEnv:
    pass


class ActionPostprocessor(object):
    def __init__(self, env: MicroBattleEnv):
        """Construct an ActionPostprocessor, which applies SC2 effects that should be taken
        care of by the game client, but aren't for whatever reason.

        Parameters
        ----------
        env: MicroBattleEnv
            the MicroBattleEnv object to modify
        """
        self.env = env
        self._all_funcs = set([func.id for func in RAW_FUNCTIONS._func_list])

    def postprocess(self, actions: Tuple[FunctionCall]):
        """Perform postprocessing on the environment actions

        Parameters
        ----------
        actions : Tuple[FunctionCall]
            actions conducted

        Returns
        -------
        ret : List
            the list of postprocessed actions

        Raises
        ------
        ValueError
            if the length of the actions is not the same as the number of timesteps the environment
            went through
        ValueError
            if the action function is not in the set of valid functions
        """
        if len(actions) != len(self.env.timestep):
            raise ValueError(
                f"len(actions) = {len(actions)} != {len(self.env.timestep)} " "= self.env.timestep"
            )

        # Apply postprocessing steps
        ret = []
        for action, timestep in zip(actions, self.env.timestep):
            if action.function not in self._all_funcs:
                raise ValueError(f"Invalid action: {action}")

            # Apply your list of actions here, chained
            action = self._reduce_health_on_stimpack(action, timestep)

            ret.append(action)

        return ret

    def _action_set(self, actions: Tuple[FunctionCall]):
        """Returns the id of the actions input as parameters

        Parameters
        ----------
        actions : Tuple[FunctionCall]
            the actions to take

        Returns
        -------
        List
            The list of action ids
        """
        return [RAW_FUNCTIONS[action].id for action in actions]

    def _reduce_health_on_stimpack(self, action: FunctionCall, timestep: TimeStep):
        """Reduce health if a stimpack function is being used

        Parameters
        ----------
        action : FunctionCall
            The action that is being used
        timestep : TimeStep
            timestep that the match is at

        Returns
        -------
        action
            the action taken
        """
        # Only operate when we're running a stim function
        if action.function not in self._action_set(
            [
                "Effect_Stim_quick",
                "Effect_Stim_Marauder_quick",
                "Effect_Stim_Marauder_Redirect_quick",
                "Effect_Stim_Marine_quick",
                "Effect_Stim_Marine_Redirect_quick",
            ]
        ):
            return action

        # Parse action arguments
        queued, tags = action.arguments[0], set(action.arguments[1])

        if queued != [Queued.now]:
            print(
                f'Warning: encountered queued value that isn\'t "now": {queued}. Health '
                "will be decreased earlier than usual for units that were stimmed."
            )

        # Consider applying a modifier to each unit's health...
        for unit in timestep.observation.raw_units:
            # Ensure that we only modify health of units that:
            # - are marines or marauders
            # - belong to the action-taker
            if (
                unit.tag not in tags
                or unit.unit_type not in [units.Terran.Marine, units.Terran.Marauder,]
                or unit.alliance != features.PlayerRelative.SELF
            ):
                continue

            # Marines lose 10 health, marauders lose 20 health
            final_health = {
                units.Terran.Marine: unit.health - 10,
                units.Terran.Marauder: unit.health - 20,
            }[unit.unit_type]

            # Can't stim if a unit would die
            if final_health <= 0:
                continue

            # Match unit types to action types
            if (action.function == RAW_FUNCTIONS["Effect_Stim_quick"].id) or (
                action.function
                in self._action_set(
                    ["Effect_Stim_Marine_quick", "Effect_Stim_Marine_Redirect_quick",]
                )
                and unit.unit_type == units.Terran.Marine
                or (
                    action.function
                    in self._action_set(
                        ["Effect_Stim_Marauder_quick", "Effect_Stim_Marauder_Redirect_quick",]
                    )
                    and unit.unit_type == units.Terran.Marauder
                )
            ):
                self.env.set_unit_value(unit.tag, "life", final_health)

        return action
