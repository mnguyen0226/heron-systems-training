# Copyright (C) 2020 Heron Systems, Inc.
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import torch
from adept.env import EnvModule
from adept.preprocess.base.preprocessor import CPUPreprocessor
from adept.preprocess.base.preprocessor import GPUPreprocessor
from adept.preprocess.ops import CastToFloat
from adept.preprocess.ops import FromNumpy
from adept.utils.util import DotDict
from pysc2.env import sc2_env
from pysc2.env.environment import StepType
from pysc2.env.sc2_env import SC2Env
from pysc2.lib.actions import FUNCTION_TYPES
from pysc2.lib.actions import FunctionCall
from pysc2.lib.features import FeatureUnit
from pysc2.lib.features import PlayerRelative

from gamebreaker.env.base.actions import RAW_FUNCTIONS
from gamebreaker.env.base.obs_utils import on_creep_map
from gamebreaker.env.base.ops import CopyOverScalarFeatures
from gamebreaker.env.base.ops import CreateEmptyArray
from gamebreaker.env.base.ops import FilterForNet
from gamebreaker.env.base.ops import PermuteToFS
from gamebreaker.env.base.ops import ProcessCategoricalFeatures
from gamebreaker.env.base.ops import ProcessScalarFeatures

NB_ACTIONS = 17


class RawSC2Env(EnvModule):
    args = {
        "step_mul": 8,
        "max_step": 10000,
        "unit_max": 512,
        "env_debug": False,
        "render_env": False,
        "realtime": False,
    }
    ids = ["CollectMineralShards", "DefeatRoaches"]

    def __init__(self, env: SC2Env, unit_max: int, seed: int, debug: Optional[bool] = False):
        """Initializes a RawSC2Env

        Parameters
        ----------
        env: sc2_env
            The pysc2 environment
        unit_max: int
            The maximum amount of units to create.
        seed: int
            Seed for RNG.
        debug: bool
            whether to debug or not.
        """
        self.sc2_env = env
        self.playable_area = env.game_info[0].start_raw.playable_area
        self.seed = seed
        self.debug = debug
        self.timesteps = None

        x_max = max(abs(self.playable_area.p0.x), abs(self.playable_area.p1.x))
        y_max = max(abs(self.playable_area.p0.y), abs(self.playable_area.p1.y))

        self.x_max = x_max
        self.y_max = y_max

        observation_space = {"raw_units": (None, len(FeatureUnit))}
        observation_dtypes = {"raw_units": np.float64}
        self.categorical_processor = ProcessCategoricalFeatures(
            x_max, y_max, ["raw_units", "proc_units"], ["proc_units"]
        )

        cpu_preprocessor = CPUPreprocessor(
            [
                FromNumpy("raw_units", "raw_units"),
                CreateEmptyArray(unit_max, "raw_units", "proc_units", creep=debug),
                self.categorical_processor,
                CopyOverScalarFeatures(["raw_units", "proc_units"], ["proc_units"], creep=debug),
                ProcessScalarFeatures(x_max, y_max, "proc_units", "proc_units", creep=debug),
                CastToFloat("proc_units", "proc_units"),
                PermuteToFS("proc_units", "proc_units"),
                FilterForNet("raw_units", "raw_units"),
            ],
            observation_space,
            observation_dtypes,
        )
        gpu_preprocessor = GPUPreprocessor(
            [], cpu_preprocessor.observation_space, cpu_preprocessor.observation_dtypes,
        )
        x_range = abs(self.playable_area.p0.x - self.playable_area.p1.x)
        y_range = abs(self.playable_area.p0.y - self.playable_area.p1.y)
        action_space = {
            "func_id": (len(RAW_FUNCTIONS),),
            "x": (x_range,),
            "y": (y_range,),
            "selected_units": (unit_max, 2),
            "target_unit": (unit_max,),
        }
        super().__init__(action_space, cpu_preprocessor, gpu_preprocessor)

    @classmethod
    def from_args(cls, args: DotDict, seed: int, **kwargs: Optional[DotDict]) -> "RawSC2Env":
        """Builds environment from arguments

        Parameters
        ----------
        args: DotDict
            Arguments needed to build the environment
        seed: int
            Seed for the random number generators.

        Returns
        -------
        RawSC2Env
        """
        feat_dims = (
            sc2_env.Dimensions(screen=84, minimap=84,)
            if args.env_debug or args.render_env
            else None
        )
        viz = (args.env_debug and seed == 0) or args.render_env
        env = SC2Env(
            map_name=args.env,
            players=[sc2_env.Agent(sc2_env.Race.terran)],
            agent_interface_format=sc2_env.AgentInterfaceFormat(
                feature_dimensions=feat_dims,
                action_space=sc2_env.ActionSpace.RAW,
                use_raw_units=True,
                raw_crop_to_playable_area=True,
            ),
            step_mul=args.step_mul,
            game_steps_per_episode=args.step_mul * args.max_step,
            random_seed=seed,
            visualize=viz,
            realtime=args.realtime,
        )

        return cls(env, args.unit_max, seed, args.env_debug)

    def step(self, action: Dict[str, torch.Tensor]) -> Tuple[Dict[str, Any], float, bool, Dict]:
        """Steps the environment based on the input action

        Parameters
        ----------
        action : dict[str, torch.Tensor]
            What action the agent is trying to take

        Returns
        -------
        Tuple[Dict[str, Any], float, bool, Dict]
            The observation, reward, whether the env is done, and the result info
        """
        action = self.convert_action(action)
        self.timesteps = self.sc2_env.step(action)
        if self.debug:
            self.timesteps = on_creep_map(self.timesteps, (64, 64))

        timestep = self.timesteps[0]
        reward = float(timestep.reward)
        # print(reward)
        # time.sleep(0.05)
        done = timestep.step_type == StepType.LAST
        info = {}
        raw_observation = timestep.observation
        observation = self.convert_obs(raw_observation)
        return (
            observation,
            reward,
            done,
            info,
        )

    def convert_action(self, action: Dict[str, torch.Tensor]) -> List[FunctionCall]:
        """Converts action dictionary to SC2 format

        Parameters
        ----------
        action : Dict[str, torch.Tensor]
            The action the agent is attempting to take

        Returns
        -------
        List[FunctionCall]
            The FunctionCalls of the actions to take
        """
        func_idx = action["func_id"].item()
        func = RAW_FUNCTIONS[func_idx]
        arg_names = [arg.name for arg in FUNCTION_TYPES[func.function_type]]

        args = []
        unit_tags = []
        valid_action = True
        for arg in arg_names:
            if arg == "queued":
                args.append([0])  # don't queue orders
            elif arg == "world":
                args.append([action["x"].item(), action["y"].item()])
            elif arg == "unit_tags":
                selected_units = self.timesteps[0].observation["raw_units"][
                    action["selected_units"][0 : len(self.timesteps[0].observation["raw_units"])]
                    == 1
                ]
                unit_tags = [unit.tag for unit in selected_units]
                if not unit_tags:
                    valid_action = False
                args.append(unit_tags)
            elif arg == "target_unit_tag":
                target_unit_tag = (
                    self.timesteps[0].observation["raw_units"][action["target_unit_tag"].item()].tag
                )
                args.append([target_unit_tag])
            else:
                raise Exception(f"Unrecognized argument name '{arg}'")

        allied_units = [
            unit.tag
            for unit in self.timesteps[0].observation["raw_units"]
            if unit.alliance == PlayerRelative.SELF
        ]
        for unit_tag in unit_tags:
            assert unit_tag in allied_units

        if self.debug and self.seed == 0:
            print(func.id, args)

        return [FunctionCall(func.id, args)] if valid_action else [FunctionCall(0, [])]

    def convert_obs(self, obs: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """Converts an observation to the raw_units dictionary

        Parameters
        ----------
        obs: Dict[str, torch.Tensor]
            The current environment observations.

        Returns
        -------
        Dict[str, torch.Tensor]
            Dictionary of the raw units
        """

        raw_units = {"raw_units": obs["raw_units"]}
        cpu_proc = self.cpu_preprocessor(raw_units)
        gpu_proc = self.gpu_preprocessor(
            {"proc_units": cpu_proc["proc_units"].view(1, *cpu_proc["proc_units"].shape)}
        )
        return {"proc_units": gpu_proc["proc_units"].squeeze(0)}

    def reset(self, **kwargs):
        """Resets the environment and cpu preprocessor

        Returns
        -------
        torch.Tensor
        """
        self.timesteps = self.sc2_env.reset()

        if self.debug:
            self.timesteps = on_creep_map(self.timesteps, (64, 64))
        self.cpu_preprocessor.reset()
        step = self.timesteps[0]
        return self.convert_obs(step.observation)

    def close(self):
        """Closes the environment"""
        self.sc2_env.close()

    def render(self, mode):
        """Does nothing

        Parameters
        ----------
        mode : String
            unused

        Returns
        -------
        None
        """
        return None
