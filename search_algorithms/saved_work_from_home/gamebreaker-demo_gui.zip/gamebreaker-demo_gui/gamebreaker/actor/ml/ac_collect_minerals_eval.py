from collections import OrderedDict
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple
from typing import Union

import torch
from adept.actor import ActorModule
from adept.actor.base.ac_helper import ACActorHelperMixin
from adept.utils.util import DotDict

from gamebreaker.env.base import ObsIdx


def compute_selected_units_exp(
    obs: torch.Tensor, pred: torch.Tensor
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Takes in an observation and prediction, determines the softmax and the action chosen for the
    selected units output head

    Parameters
    ----------
    obs: torch.Tensor
        The state observation
    pred:
        The selected units prediction from the network

    Returns
    -------
    Tuple[torch.Tensor, torch.Tensor]
        The softmax of each
    """

    # Mask out units that don't belong to us
    unit_mask = torch.prod(
        obs[:, ObsIdx.alliance_bit0 : ObsIdx.alliance_bit2 + 1, :].permute(0, 2, 1)
        == torch.cat(
            (
                torch.zeros(obs.shape[0], obs.shape[-1], 1),
                torch.zeros(obs.shape[0], obs.shape[-1], 1),
                torch.ones(obs.shape[0], obs.shape[-1], 1),
            ),
            dim=-1,
        ).to(obs.device),
        dim=-1,
    )

    # Generate the probabilities
    selected_units_softmax = torch.stack([1 - torch.sigmoid(pred), torch.sigmoid(pred)]).permute(
        1, 2, 0
    )

    # Use that to determine the units the network would like to select
    selected_units_action = torch.argmax(selected_units_softmax.view(-1, 2), dim=-1).view(
        *pred.shape
    )

    # Mask out any units we aren't allowed to take
    selected_units_action = unit_mask * selected_units_action

    # Return the softmax and the selected units
    return selected_units_softmax, selected_units_action.cpu()


class ACCollectMineralsEval(ActorModule, ACActorHelperMixin):
    args = {}

    def __init__(self, action_space: Dict[str, Any]):
        """Agent class for eval

        Parameters
        ----------
        action_space: Dict[str, Any]
            Unused
        """
        super().__init__(action_space)
        self.x_max = 22
        self.y_max = 17
        self.last_obs = None

    @classmethod
    def from_args(cls, args: DotDict, action_space: Dict[str, Any]) -> "ACCollectMineralsEval":
        """Builds the agent from arguments

        Parameters
        ----------
        args: DotDict
            Unused
        action_space: Dict[str, Any]
            Unused
        Returns
        -------
        "ACCollectMineralsEval"
        """
        return cls(action_space)

    @staticmethod
    def output_space(action_space: Dict[str, Any]) -> Dict[str, Union[int, Any]]:
        """Unused function

        Parameters
        ----------
        action_space: Dict[str, Any]
            Unused

        Returns
        -------
        Dict[str, Union[int, Any]]
        """
        head_dict = {"critic": (1,), **action_space}
        return head_dict

    def compute_simple_action_exp(
        self, pred: torch.Tensor, mask: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Calculates the softmax and selects an action based for the simple action heads and only
        need one choice (anything other than selecting units)

        Parameters
        ----------
        pred: torch.Tensor
            The prediction returned by the network
        mask: Optional[torch.Tensor]
            An optional mask to apply to the probability distribution. Useful for func id's that
            are invalid or masking out units that don't exist

        Returns
        -------
        Tuple[torch.Tensor, torch.Tensor]
            The softmaxed distribution and the selected action, respectively
        """
        if mask is None:
            # Softmax the distribution
            softmax = self.softmax(pred)
        else:
            # If a mask is provided, we mask the distribution and then softmax
            masked_pred = torch.where(mask, pred, torch.zeros_like(pred) + -(10 ** 10))
            softmax = self.softmax(masked_pred)

        # Choose the action the network thinks is best
        action = torch.argmax(softmax, dim=-1).unsqueeze(-1)

        # Return the softmax and the chosen action
        return softmax, action.cpu()

    def compute_action_exp(
        self,
        predictions: Dict[str, torch.Tensor],
        internals: Dict[str, List[torch.Tensor]],
        obs: torch.Tensor,
        available_actions: Any,
    ) -> Tuple[OrderedDict, Dict[str, torch.Tensor]]:
        """Determines which action to take and what the probability distributions for the given
        state look like.

        Parameters
        ----------
        predictions: Dict[str, torch.Tensor]
            The predictions output by the model
        internals: Dict[str, List[torch.Tensor]]
            The internals needed for the LSTM
        obs: torch.Tensor
            The observation states
        available_actions: Any
            Unused

        Returns
        -------
        Tuple[OrderedDict, Dict[str, torch.Tensor]]
        """
        # Grab the critic value
        softmaxes = {"critic": predictions["critic"].squeeze(1)}

        actions = OrderedDict()

        # Get the softmax and selected function
        softmaxes["func_id_softmax"], actions["func_id"] = self.compute_simple_action_exp(
            predictions["func_id"]
        )

        # Get the softmax and selected x/y
        softmaxes["x_softmax"], actions["x"] = self.compute_simple_action_exp(predictions["x"])
        softmaxes["y_softmax"], actions["y"] = self.compute_simple_action_exp(predictions["y"])

        # Get the softmax and selected units
        (
            softmaxes["selected_units_softmax"],
            actions["selected_units"],
        ) = compute_selected_units_exp(obs, predictions["selected_units"])

        # Generate the mask for the target unit and use it to generate the softmax and target unit
        # action
        nonzero_units = torch.sum(obs, dim=1)
        target_unit_mask = nonzero_units != torch.zeros_like(nonzero_units)
        (
            softmaxes["target_unit_softmax"],
            actions["target_unit_tag"],
        ) = self.compute_simple_action_exp(predictions["target_unit"], mask=target_unit_mask)

        return actions, softmaxes

    @classmethod
    def _exp_spec(cls, rollout_len, batch_sz, obs_space, act_space, internal_space):
        """Unused"""
        return {}
