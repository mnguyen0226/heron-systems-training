# TODO: remove? could potentially remove this, or at least update to be more useful/work on multiple
# datasets
import numpy as np

from gamebreaker.classifier.logistic_regression.logistic_regression import LogReg


def run():
    """Builds and runs a logistic regression model"""
    # Build the logistic regression model
    logreg = LogReg()

    print("Fitting the model...")
    x, y = logreg.read_episode("/media/banshee/gb_winprob/Data/raw_rand_scripted/Training/4500/")
    logreg.train(x, y)

    print("Testing the model...")
    x_test, y_test = logreg.read_episode(
        "/media/banshee/gb_winprob/Data/raw_rand_scripted/Testing/0/"
    )
    print(logreg.test(x_test, y_test))


if __name__ == "__main__":
    run()
