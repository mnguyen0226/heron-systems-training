"""
Script for running a logistic regression model on a Starcraft II dataset.
"""
import os
import pickle as pkl

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

from gamebreaker.classifier.utils.file_loader import normalize_size


class LogReg:
    """Logistic Regression Model

    This class sets up, trains, fits, and tests a logistic regression model
    """

    def __init__(self, path, max_iter=3000):
        """Initialize the model

        Parameters
        ----------
        path : string
            path to save the model
        max_iter : int, optional
            maximum number of iterations to run, by default 3000
        """
        self.path = path

        self.name = None
        self.sc = StandardScaler()
        self.max_iter = max_iter
        self.model = LogisticRegression(
            random_state=0, solver="lbfgs", multi_class="multinomial", max_iter=self.max_iter,
        )

    def train(self, x, y):
        """Fit the model to the data

        Parameters
        ----------
        x : array-like
            data to train on
        y : array-like
            true labels for the data
        """
        x_train = self.sc.fit_transform(x)
        self.model.fit(x_train, y)

    def test(self, x, y):
        """Test the hard label accuracy of the model

        Parameters
        ----------
        x : array-like
            data to test on
        y : array-like
            true labels for the data

        Returns
        -------
        score : float
            Mean accuracy of ``self.predict(X)`` wrt. `y`
        """
        x_test = self.sc.fit_transform(x)
        return self.model.score(x_test, y)

    def forward(self, x):
        """Predict probability that samples belong to a class

        Parameters
        ----------
        x : array-like
            data to predict on

        Returns
        -------
        T : array-like of shape (n_samples, n_classes)
            Returns the probability of the sample for each class in the model,
            where classes are ordered as they are in ``self.classes_``.
        """
        x_test = self.sc.fit_transform(x)
        return self.model.predict_proba(x_test)

    # This function reads data specifically for the Logistic Regression model
    def read_episode(self, path):
        """This function reads data specifically for the Logistic Regression model

        This reads the data of all the episodes in the path specified and appends the data in a
        nparray

        Parameters
        ----------
        path : String
            path to the list of files to read

        Returns
        -------
        x_data, y_data : nparray, nparray
            The data from the episodes in the file
        """
        list_of_files = sorted(os.listdir(path))
        x_data = []
        y_data = []
        for file in list_of_files:
            data = np.load(os.path.join(path, file), allow_pickle=True)
            data = normalize_size(data)
            label = file.split("_")[1].split(".")[0]
            for timestep in data:
                x_data.append(timestep.reshape(timestep.shape[0] * timestep.shape[1]))
                y_data.append(label)

        x_data = np.asarray(x_data)
        return np.asarray(x_data), np.asarray(y_data)

    def save(self):
        """Save the LogReg model

        Saves the model parameters in the specified path using pickle
        """
        if not os.path.isdir(self.path):
            os.mkdir(self.path)

        with open(os.path.join(self.path, f"{self.name}.pkl"), "wb") as fp:
            pkl.dump(self.model, fp)

    def load(self):
        """Loads the LogReg model

        Loads the model parameters from the specified path using pickle
        """
        with open(self.path, "rb") as fp:
            self.model = pkl.load(fp)


if __name__ == "__main__":
    save_path = "/media/banshee/gb_winprob/lr_models/"
    lr_name = "init"
    logreg = LogReg(os.path.join(save_path, lr_name))
    x_train, y_train = logreg.read_episode(
        "/media/banshee/gb_winprob/Data/raw_rand_scripted/Training/4500/"
    )
    print(x_train.shape, y_train.shape)
    logreg.train(x_train, y_train)
    x_test, y_test = logreg.read_episode(
        "/media/banshee/gb_winprob/Data/raw_rand_scripted/Testing/0/"
    )
    print(x_test.shape, y_test.shape)
    print(logreg.test(x_test, y_test))
    logreg.save()
    logreg.load()
