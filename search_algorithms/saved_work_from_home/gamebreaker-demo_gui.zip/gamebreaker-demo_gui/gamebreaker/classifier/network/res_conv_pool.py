from typing import Dict
from typing import Tuple

import torch
from torch import nn
from torch.nn import AvgPool1d

from gamebreaker.classifier.network import ResConv


class ResConvPool(ResConv):
    args = {"resconv_norm": "bn", "nb_layer": 2}

    def __init__(
        self,
        in_shape: Tuple[int, int],
        id: str,
        conv_nb_hidden: int,
        nb_conv_layer: int,
        dropout: float,
    ):
        """Module that creates multiple, sequential conv layers with residual connections followed
        by an average pooling layer

        Parameters
        ----------
        in_shape: Tuple[int, int]
            The input shape to this module (no batch size).
        id: str
            Unique identifier for this instance
        conv_nb_hidden: int
            Number of channels
        nb_conv_layer: int
            Number of conv layers
        dropout: float
            Probability of an element being zeroed out (0.0 for no dropout)
        """
        super().__init__(in_shape, id, conv_nb_hidden, nb_conv_layer, dropout)

        self.pool = nn.AvgPool1d(kernel_size=in_shape[0])

    @property
    def _output_shape(self) -> Tuple[int, int]:
        """
        The output shape of this module

        Returns
        -------
        Tuple[int, int]
            The output shape of the module (no batch size)
        """

        if self._out_shape is None:
            self._out_shape = self._conv_nb_hidden, 1

        return self._out_shape

    def _forward(
        self, xs: torch.Tensor, internals: Dict, **kwargs: Dict
    ) -> Tuple[torch.Tensor, Dict]:
        """
        Forward function for the module

        Parameters
        ----------
        xs: torch.Tensor
            Input to be fed through the module
        internals: Dict
            Unused
        kwargs: Dict
            Unused

        Returns
        -------
        Tuple[torch.Tensor, Dict]
            The output tensor of the module and the new internals (unused)
        """
        xs, _ = super()._forward(xs, internals, **kwargs)
        xs = self.pool(xs)

        return xs, {}
