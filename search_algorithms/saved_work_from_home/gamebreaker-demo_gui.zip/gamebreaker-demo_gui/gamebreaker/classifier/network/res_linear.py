from typing import Dict
from typing import Tuple

import torch
from adept.network import SubModule1D
from adept.utils.util import DotDict
from torch import nn
from torch.nn import functional as F


class ResLinear(SubModule1D):
    args = {"linear_normalize": "bn", "linear_nb_hidden": 512, "nb_layer": 2}

    def __init__(
        self, in_shape: Tuple[int], id: str, nb_hidden: int, nb_layer: int, dropout: float
    ):
        """Module that creates multiple linear/dense/fully connected layers with residual
        connections

        Parameters
        ----------
        in_shape: Tuple[int]
          The input shape to this module (no batch size)
        id: str
            Unique identifier for this instance
        nb_hidden: int
            Number of hidden units in the linear layer
        nb_layer: int
            Number of linear layers
        dropout: float
            Probability of an element being zeroed out (0.0 for no dropout)
        """
        super().__init__(in_shape, id)
        self._input_shape = in_shape
        self._nb_hidden = nb_hidden
        self._nb_layer = nb_layer
        layers_per_block = 2
        self._layers_per_block = layers_per_block
        nb_input_channel = in_shape[0]

        self.linears = nn.ModuleList(
            [
                nn.Linear(nb_input_channel if i == 0 else nb_hidden, nb_hidden, False)
                for i in range(layers_per_block * self._nb_layer)
            ]
        )

        self.norms = nn.ModuleList(
            [
                nn.BatchNorm1d(nb_input_channel if i == 0 else nb_hidden)
                for i in range(layers_per_block * self._nb_layer)
            ]
        )

        self.connections = nn.ModuleList(
            [
                nn.Linear(nb_input_channel if i == 0 else nb_hidden, nb_hidden, False)
                for i in range(self._nb_layer)
            ]
        )

        self.dropout = nn.Dropout(p=dropout)

        for i in range(len(self.connections)):
            self.connections[i].requires_grad = False

    @classmethod
    def from_args(cls, args: DotDict, in_shape: Tuple[int], id: str) -> "ResLinear":
        """
        Function for building this module from arguments

        Parameters
        ----------
        args: DotDict
            Arguments used to build the model. Must contain keys 'linear_nb_hidden', 'nb_layer',
            and 'dropout'
        in_shape: Tuple[int]
            The input shape to the module
        id: str
            Unique identifier for this module

        Returns
        -------
        ResLinear
        """

        return cls(in_shape, id, args.linear_nb_hidden, args.nb_layer, args.dropout)

    def _forward(
        self, xs: torch.Tensor, internals: Dict, **kwargs: Dict
    ) -> Tuple[torch.Tensor, Dict]:
        """
        Forward function for the module

        Parameters
        ----------
        xs: torch.Tensor
            Input to be fed through the module
        internals: Dict
            Unused
        kwargs: Dict
            Unused

        Returns
        -------
        Tuple[torch.Tensor, Dict]
            The output tensor of the module and the new internals (unused)
        """
        for block in range(self._nb_layer):
            residual = xs
            for i in range(self._layers_per_block):
                xs = self.norms[i + self._layers_per_block * block](xs)
                xs = F.relu(xs)
                xs = self.linears[i + self._layers_per_block * block](xs)
                xs = self.dropout(xs)
            residual = torch.reshape(residual, (1, residual.shape[0], residual.shape[1]))
            xs += torch.squeeze(F.interpolate(residual, size=self._nb_hidden, mode="area"))
        return xs, {}

    def _new_internals(self) -> Dict:
        """
        Function for generating internals for an LSTM (unused)

        Returns
        -------
        Dict
            New internals (unused)
        """
        return {}

    @property
    def _output_shape(self) -> Tuple[int]:
        """
        The output shape of this module

        Returns
        -------
        Tuple[int]
            The output shape of the module (no batch size)
        """

        return (self._nb_hidden,)
