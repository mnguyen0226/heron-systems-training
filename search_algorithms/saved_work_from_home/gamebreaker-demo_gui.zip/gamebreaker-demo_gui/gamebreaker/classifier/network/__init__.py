from adept.registry.registry import Registry

from gamebreaker.classifier.network.avg_pooling_linear import AvgPoolingLinear
from gamebreaker.classifier.network.conv_net import ConvNet
from gamebreaker.classifier.network.conv_pool import ConvPool
from gamebreaker.classifier.network.gated_encoder import GatedEncoder
from gamebreaker.classifier.network.res_conv import ResConv
from gamebreaker.classifier.network.res_conv_pool import ResConvPool
from gamebreaker.classifier.network.res_linear import ResLinear
from gamebreaker.classifier.network.upgrade_net import UpgradeNet
from gamebreaker.classifier.network.win_prob_conv import WinProbConv
from gamebreaker.classifier.network.win_prob_linear import WinProbLinear

CUSTOM_REGISTRY = Registry()
CUSTOM_REGISTRY.register_submodule(AvgPoolingLinear)
CUSTOM_REGISTRY.register_submodule(ConvNet)
CUSTOM_REGISTRY.register_submodule(ConvPool)
CUSTOM_REGISTRY.register_submodule(GatedEncoder)
CUSTOM_REGISTRY.register_submodule(ResConv)
CUSTOM_REGISTRY.register_submodule(ResConvPool)
CUSTOM_REGISTRY.register_submodule(ResLinear)
CUSTOM_REGISTRY.register_submodule(UpgradeNet)
CUSTOM_REGISTRY.register_submodule(WinProbConv)
CUSTOM_REGISTRY.register_submodule(WinProbLinear)
CUSTOM_REGISTRY.register_submodule(UpgradeNet)
