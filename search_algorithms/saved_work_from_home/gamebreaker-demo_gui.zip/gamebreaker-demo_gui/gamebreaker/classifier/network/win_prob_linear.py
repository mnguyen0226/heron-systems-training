from typing import Dict
from typing import Tuple

import torch
from adept.network import SubModule1D
from adept.utils.util import DotDict
from torch import nn
from torch.nn import functional as F


class WinProbLinear(SubModule1D):
    args = {"wp_linear_norm": "bn"}

    def __init__(self, in_shape: Tuple[int], id: str, dropout: float):
        """Module that creates multiple linear/dense/fully connected layers with residual
        connections

        Parameters
        ----------
        in_shape: Tuple[int]
          The input shape to this module (no batch size)
        id: str
            Unique identifier for this instance
        dropout: float
            Probability of an element being zeroed out (0.0 for no dropout)
        """
        super().__init__(in_shape, id)
        self._in_shape = in_shape
        self.linear1 = nn.Linear(in_shape[0], 256, False)
        self.linear2 = nn.Linear(256, 128, False)

        self.norm1 = nn.BatchNorm1d(256)
        self.norm2 = nn.BatchNorm1d(128)

        self.dropout = nn.Dropout(p=dropout)

    @classmethod
    def from_args(cls, args: DotDict, in_shape: Tuple[int], id: str) -> "WinProbLinear":
        """
        Function for building this module from arguments

        Parameters
        ----------
        args: DotDict
            Arguments used to build the model. Must contain key 'dropout'
        in_shape: Tuple[int]
            The input shape to the module
        id: str
            Unique identifier for this module

        Returns
        -------
        WinProbLinear
        """
        return cls(in_shape, id, args.dropout)

    def _forward(
        self, xs: torch.Tensor, internals: Dict, **kwargs: Dict
    ) -> Tuple[torch.Tensor, Dict]:
        """
        Forward function for the module

        Parameters
        ----------
        xs: torch.Tensor
            Input to be fed through the module
        internals: Dict
            Unused
        kwargs: Dict
            Unused

        Returns
        -------
        Tuple[torch.Tensor, Dict]
            The output tensor of the module and the new internals (unused)
        """
        xs = self.dropout(F.relu(self.norm1(self.linear1(xs))))
        xs = self.dropout(F.relu(self.norm2(self.linear2(xs))))

        return xs, {}

    def _new_internals(self) -> Dict:
        """
        Function for generating internals for an LSTM (unused)

        Returns
        -------
        Dict
            New internals (unused)
        """
        return {}

    @property
    def _output_shape(self) -> Tuple[int]:
        """
        The output shape of this module

        Returns
        -------
        Tuple[int]
            The output shape of the module (no batch size)
        """

        return (128,)
