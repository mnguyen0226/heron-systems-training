from collections import OrderedDict
from typing import Dict
from typing import Tuple

import torch
import torch.nn as nn
from adept.network import SubModule2D
from adept.utils.util import DotDict


class AvgPoolingLinear(SubModule2D):
    args = {}

    def __init__(
        self, in_shape: Tuple[int, int], id: str, nb_hidden: int, nb_layer: int, dropout: float
    ):
        """Module that creates a 2D avg pooling layer that averages over the sequence, followed by
        a number of linear layers

        Parameters
        ----------
        in_shape: Tuple[int, int]
            The input shape to this module (no batch size).
        id: str
            Unique identifier for this instance
        nb_hidden: int
            Number of hidden weights in the linear layers
        nb_layer: int
            Number of linear layers
        dropout: float
            Probability of an element being zeroed out (0.0 for no dropout)
        """
        super().__init__(in_shape, id)

        self.pool = nn.AvgPool2d((1, in_shape[1]))

        self._out_shape = (1, nb_hidden)

        layer_list = []
        for i in range(nb_layer):
            layer_list.append(
                (f"linear_{i}", nn.Linear(in_shape[0] if i == 0 else nb_hidden, nb_hidden))
            )
            layer_list.append((f"norm_{i}", nn.BatchNorm1d(nb_hidden)))
            layer_list.append((f"relu_{i}", nn.ReLU()))
            layer_list.append((f"drop_{i}", nn.Dropout(p=dropout)))
        self.linears = nn.Sequential(OrderedDict(layer_list))

    @classmethod
    def from_args(cls, args: DotDict, in_shape: Tuple[int, int], id: str) -> "AvgPoolingLinear":
        """
        Function for building this module from arguments

        Parameters
        ----------
        args: DotDict
            Arguments used to build the model. Must contain keys 'conv_nb_hidden', 'nb_conv_layer',
            and 'dropout'
        in_shape: Tuple[int, int]
            The input shape to the module
        id: str
            Unique identifier for this module

        Returns
        -------
        AvgPoolLinear
        """
        return cls(in_shape, id, args.linear_nb_hidden, args.nb_layer, args.dropout)

    @property
    def _output_shape(self) -> Tuple[int, int]:
        """
        The output shape of this module

        Returns
        -------
        Tuple[int, int]
            The output shape of the module (no batch size)
        """
        return self._out_shape

    def _forward(
        self, xs: torch.Tensor, internals: Dict, **kwargs: Dict
    ) -> Tuple[torch.Tensor, Dict]:
        """
        Forward function for the module

        Parameters
        ----------
        xs: torch.Tensor
            Input to be fed through the module
        internals: Dict
            Unused
        kwargs: Dict
            Unused

        Returns
        -------
        Tuple[torch.Tensor, Dict]
            The output tensor of the module and the new internals (unused)
        """
        b, f, s = xs.shape
        avg_xs = self.pool(xs)
        linear_out = self.linears(torch.reshape(avg_xs, (b, -1)))

        return torch.reshape(linear_out, (b, 1, -1)), {}

    def _new_internals(self) -> Dict:
        """
        Function for generating internals for an LSTM (unused)

        Returns
        -------
        Dict
            New internals (unused)
        """
        return {}
