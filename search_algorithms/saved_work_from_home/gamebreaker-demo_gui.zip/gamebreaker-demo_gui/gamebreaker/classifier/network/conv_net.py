from typing import Dict
from typing import Tuple

import torch
from adept.network import SubModule2D
from adept.utils.util import DotDict
from torch import nn
from torch.nn import functional as F


class ConvNet(SubModule2D):
    args = {"convnet_norm": "bn"}

    def __init__(
        self,
        in_shape: Tuple[int, int],
        id: str,
        conv_nb_hidden: int,
        nb_conv_layer: int,
        dropout: float,
    ):
        """Module that creates multiple, sequential conv layers

        Parameters
        ----------
        in_shape: Tuple[int, int]
            The input shape to this module (no batch size).
        id: str
            Unique identifier for this instance
        conv_nb_hidden: int
            Number of channels
        nb_conv_layer: int
            Number of conv layers
        dropout: float
            Probability of an element being zeroed out (0.0 for no dropout)
        """
        super().__init__(in_shape, id)
        self._in_shape = in_shape
        self._out_shape = None
        self._nb_conv_layer = nb_conv_layer
        self._conv_nb_hidden = conv_nb_hidden
        self.convs = nn.ModuleList(
            [
                nn.Conv1d(
                    in_shape[1] if i == 0 else conv_nb_hidden,
                    conv_nb_hidden,
                    kernel_size=(3,),
                    stride=(1,),
                    padding=(1,),
                )
                for i in range(nb_conv_layer)
            ]
        )

        self.norms = nn.ModuleList([nn.BatchNorm1d(conv_nb_hidden) for _ in range(nb_conv_layer)])

        self.dropout = nn.Dropout(p=dropout)
        relu_gain = nn.init.calculate_gain("relu")
        for i in range(nb_conv_layer):
            self.convs[i].weight.data.mul_(relu_gain)

    @classmethod
    def from_args(cls, args: DotDict, in_shape: Tuple[int, int], id: str) -> "ConvNet":
        """
        Function for building this module from arguments

        Parameters
        ----------
        args: DotDict
            Arguments used to build the model. Must contain keys 'conv_nb_hidden', 'nb_conv_layer',
            and 'dropout'
        in_shape: Tuple[int, int]
            The input shape to the module
        id: str
            Unique identifier for this module

        Returns
        -------
        ConvNet
        """
        return cls(in_shape, id, args.conv_nb_hidden, args.nb_conv_layer, args.dropout)

    @property
    def _output_shape(self) -> Tuple[int, int]:
        """
        The output shape of this module

        Returns
        -------
        Tuple[int, int]
            The output shape of the module (no batch size)
        """
        if self._out_shape is None:
            self._out_shape = self._conv_nb_hidden, self._in_shape[0]
        return self._out_shape

    def _forward(
        self, xs: torch.Tensor, internals: Dict, **kwargs: Dict
    ) -> Tuple[torch.Tensor, Dict]:
        """
        Forward function for the module

        Parameters
        ----------
        xs: torch.Tensor
            Input to be fed through the module
        internals: Dict
            Unused
        kwargs: Dict
            Unused

        Returns
        -------
        Tuple[torch.Tensor, Dict]
            The output tensor of the module and the new internals (unused)
        """
        for conv, norm in zip(self.convs, self.norms):
            xs = self.dropout(F.relu(norm(conv(xs))))

        return xs, {}

    def _new_internals(self) -> Dict:
        """
        Function for generating internals for an LSTM (unused)

        Returns
        -------
        Dict
            New internals (unused)
        """
        return {}
