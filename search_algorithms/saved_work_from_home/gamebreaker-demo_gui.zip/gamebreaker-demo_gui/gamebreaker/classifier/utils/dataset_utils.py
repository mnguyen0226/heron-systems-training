import os
from typing import Tuple

import numpy as np
import torch
from pysc2.lib import units
from pysc2.lib.features import PlayerRelative
from pysc2.lib.named_array import NamedNumpyArray

from gamebreaker.agent import AGENT_LIST
from gamebreaker.classifier.utils.common_utils import get_context_vector
from gamebreaker.classifier.utils.common_utils import RACE_MAP
from gamebreaker.data.unit_stats import get_stats
from gamebreaker.data.unit_stats import MAX_STATS
from gamebreaker.data.unit_stats import stats_to_ndarray
from gamebreaker.env.base.obs_utils import get_raw_unit
from gamebreaker.unit_data import unit_data
from gamebreaker.unit_data import unit_race


def read_episode(path: str) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Function for reading a processed v3 game file

    Parameters
    ----------
    path : str
        path to the location of the episode

    Returns
    -------
    Tuple[torch.Tensor, torch.Tensor, torch.Tensor]
        the unit data, upgrade data, and labels for the episode
    """
    data = np.load(path, allow_pickle=True)[0]

    unit_data = torch.from_numpy(data["data"])
    upgrade_data = torch.from_numpy(data["upgrades"])
    upgrade_data = torch.reshape(upgrade_data, (-1, upgrade_data.shape[0]))
    upgrade_data = torch.cat(tuple([upgrade_data for _ in range(unit_data.shape[0])]), dim=0)
    upgrade_data = upgrade_data.double()
    agents = [data["agents"] for _ in unit_data]
    winner = int(data["winner"])

    raw_unit_data = get_raw_unit(unit_data.numpy(), 64, 64)
    (b_attr, b_mine, b_gas, r_attr, r_mine, r_gas, races,) = determine_attrition(
        raw_unit_data, winner
    )

    upgrade_data = get_context_vector(upgrade_data, torch.from_numpy(races), agents)

    labels = torch.tensor([[winner for _ in b_attr], b_attr, b_mine, b_gas, r_attr, r_mine, r_gas])

    return unit_data, upgrade_data, labels.permute(1, 0)


def convert_raw_to_stats(
    timesteps: NamedNumpyArray, upgrade_data: np.ndarray, unit_max: int
) -> np.ndarray:
    """
    Uses the raw unit vectors to generate the accompanying stats

    Parameters
    ----------
    timesteps: NamedNumpyArray
        A 3D NamedNumpyArray, with dimensions (timestep, units, features).
    upgrade_data: np.ndarray
        1D upgrade vector for the given timesteps
    unit_max: int
        Maximum number of units that can be on the field at any one time

    Returns
    -------
    np.ndarray
        3D ndarray that contains all the stats respective to timesteps
    """
    stats = []
    for timestep in timesteps:
        timestep_stats = np.zeros((len(MAX_STATS), unit_max))
        for ix, unit in enumerate(timestep):
            if unit.unit_type == units.Neutral.XelNagaTower:
                continue
            timestep_stats[:, ix] += stats_to_ndarray(get_stats(unit, upgrade_data))
        stats.append(timestep_stats)
    return np.asarray(stats)


def agent_string_to_int(agents):
    """Function for converting the agent name from string to an integer using the AGENT_LIST

    Parameters
    ----------
    agents : List[String, String]
        The two agents as strings

    Returns
    -------
    List[int, int]
        The two agents, integer encoded
    """
    agent_names = [agent_string.rsplit(".")[-1] for agent_string in AGENT_LIST]
    return [agent_names.index(agents[0]), agent_names.index(agents[1])]


def read_files(path: str, raw_path: str):
    """Reads the files in the path given and returns the information from the dataset

    Parameters
    ----------
    path : str
        path to the directory of processed files to read
    raw_path : str
        path to the directory of raw files to read

    Returns
    -------
    Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]
        Parsed x, upgrades, labels, agents, gamenums, and races arrays
    """
    x = []
    labels = []
    upgrades = []
    gamenums = []
    agents = []
    races = []
    file_list = os.listdir(path)
    raw_file_list = os.listdir(raw_path)
    file_list.sort()
    raw_file_list.sort()
    for file, raw_file in zip(file_list, raw_file_list):
        print(f"\t\tReading {file}")
        print(f"\t\tRaw File {raw_file}")
        filename = os.path.join(path, file)
        data = np.load(filename, allow_pickle=True)[0]

        raw_filename = os.path.join(raw_path, raw_file)
        raw_data = np.load(raw_filename, allow_pickle=True)[0]
        raw_unit_data = raw_data["data"]
        unit_data = data["data"]
        upgrade_data = data["upgrades"]
        label = float(data["winner"])

        game_stats = convert_raw_to_stats(raw_unit_data, upgrade_data, 512)

        (b_attr, b_mine, b_gas, r_attr, r_mine, r_gas, races_data,) = determine_attrition(
            raw_unit_data, label
        )
        agent = agent_string_to_int(data["agents"])
        gamenum = file[0:5]
        for i, timestep in enumerate(unit_data):
            new_timestep = np.concatenate(
                (game_stats[i, :, :], np.asarray(timestep)[9:, :]), axis=0
            )
            x.append(np.asarray(new_timestep))
            # x.append(np.asarray(timestep))

            upgrades.append(upgrade_data)
            labels.append(
                [label, b_attr[i], b_mine[i], b_gas[i], r_attr[i], r_mine[i], r_gas[i],]
            )
            agents.append(agent)
            gamenums.append(gamenum)
            races.append(races_data[i])

    x = np.array(x)
    upgrades = np.asarray(upgrades)
    labels = np.asarray(labels)
    agents = np.asarray(agents)
    gamenums = np.asarray(gamenums)
    races = np.asarray(races)
    return x, upgrades, labels, agents, gamenums, races


def shuffle_and_save(x, upgrades, y, agents, gamenums, races, path, file_num):
    """Shuffles the data and stores each in seperate npy files

    Parameters
    ----------
    x : np.ndarray
        the unit data
    upgrades : np.ndarray
        the upgrade values
    y : np.ndarray
        the labels
    agents : np.ndarray
        the agents in the matches
    gamenums : np.ndarray
        the gamenumber that each data timestep comes from
    races : np.ndarray
        the races of the armies in the matches
    path : string
        the path to save the data to
    file_num : int
        the file number to save the files under
    """
    print("\tShuffling data...")
    order = [i for i in range(x.shape[0])]
    np.random.shuffle(order)
    x = x[order]
    upgrades = upgrades[order]
    y = y[order, :]
    agents = agents[order]
    gamenums = gamenums[order]
    races = races[order]

    print(f"\tSaving data to {path}")
    np.save(os.path.join(path, f"{file_num:03d}_units.npy"), x, allow_pickle=True)
    np.save(
        os.path.join(path, f"{file_num:03d}_upgrades.npy"), upgrades, allow_pickle=True,
    )
    np.save(os.path.join(path, f"{file_num:03d}_labels.npy"), y, allow_pickle=True)
    np.save(
        os.path.join(path, f"{file_num:03d}_agents.npy"), agents, allow_pickle=True,
    )
    np.save(
        os.path.join(path, f"{file_num:03d}_gamenums.npy"), gamenums, allow_pickle=True,
    )
    np.save(
        os.path.join(path, f"{file_num:03d}_races.npy"), races, allow_pickle=True,
    )


def determine_attrition(
    data: np.ndarray, label: float
) -> Tuple[
    np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray,
]:
    """Determines the attrition values for for the labeled data

    Parameters
    ----------
    data : np.ndarray
        data of the match
    label : float
        which team won the interaction

    Returns
    -------
    Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray,]
        attrition values per timestep
    """
    blue_attr = np.zeros(len(data))
    blue_mine = np.zeros(len(data))
    blue_gas = np.zeros(len(data))

    red_attr = np.zeros(len(data))
    red_mine = np.zeros(len(data))
    red_gas = np.zeros(len(data))

    races = []

    for time_ix, timestep in enumerate(data):
        self_race = None
        enemy_race = None
        for unit in timestep:
            if unit.alliance == PlayerRelative.SELF:
                # Grab the string name of the race
                if self_race is None:
                    # Get the player race as a string to access our dictionary mapping
                    self_race = str(unit_race(unit.unit_type)).rsplit("'")[1].lower()
                blue_attr[time_ix] += 1
                blue_mine[time_ix] += unit_data(unit.unit_type).minerals
                blue_gas[time_ix] += unit_data(unit.unit_type).gas
            elif unit.alliance == PlayerRelative.ENEMY:
                if enemy_race is None:
                    enemy_race = str(unit_race(unit.unit_type)).rsplit("'")[1].lower()
                red_attr[time_ix] += 1
                red_mine[time_ix] += unit_data(unit.unit_type).minerals
                red_gas[time_ix] += unit_data(unit.unit_type).gas
        races.append(np.array([RACE_MAP[self_race], RACE_MAP[enemy_race]]))

    races = np.asarray(races)

    if label == 1.0:
        if blue_attr[-1] == 0:
            blue_attr = np.zeros(len(data))
            blue_mine = np.zeros(len(data))
            blue_gas = np.zeros(len(data))
        else:
            blue_attr = blue_attr[-1] / blue_attr
            blue_mine = blue_mine[-1] / blue_mine
            if all(blue_gas != 0):
                blue_gas = blue_gas[-1] / blue_gas
            else:
                blue_gas = np.zeros(len(data))

        red_attr = np.zeros(len(data))
        red_mine = np.zeros(len(data))
        red_gas = np.zeros(len(data))
    elif label == 0.0:
        blue_attr = np.zeros(len(data))
        blue_mine = np.zeros(len(data))
        blue_gas = np.zeros(len(data))

        if red_attr[-1] == 0:
            red_attr = np.zeros(len(data))
            red_mine = np.zeros(len(data))
            red_gas = np.zeros(len(data))
        else:
            red_attr = red_attr[-1] / red_attr
            red_mine = red_mine[-1] / red_mine
            if all(red_gas != 0):
                red_gas = red_gas[-1] / red_gas
            else:
                red_gas = np.zeros(len(data))
    else:
        if blue_attr[-1] == 0:
            blue_attr = np.zeros(len(data))
            blue_mine = np.zeros(len(data))
            blue_gas = np.zeros(len(data))
        else:
            blue_attr = blue_attr[-1] / blue_attr
            blue_mine = blue_mine[-1] / blue_mine
            if all(blue_gas != 0):
                blue_gas = blue_gas[-1] / blue_gas
            else:
                blue_gas = np.zeros(len(data))
        if red_attr[-1] == 0:
            red_attr = np.zeros(len(data))
            red_mine = np.zeros(len(data))
            red_gas = np.zeros(len(data))
        else:
            red_attr = red_attr[-1] / red_attr
            red_mine = red_mine[-1] / red_mine
            if all(red_gas != 0):
                red_gas = red_gas[-1] / red_gas
            else:
                red_gas = np.zeros(len(data))
    return blue_attr, blue_mine, blue_gas, red_attr, red_mine, red_gas, races


def shuffle_dataset(path, raw_path, samples_per_file=1000 * 256):
    """Shuffles the given dataset so that it is no longer organized by game number

    Parameters
    ----------
    path : string
        path to the processed files
    raw_path : string
        path to the raw files
    samples_per_file : int, optional
        number of samples per file, by default 1000*256
    """

    shuffled_set = "/media/banshee/gb_winprob/Data/shuffled_dataset_v3/"

    # Make the new directory if it doesn't exist already
    if not os.path.isdir(shuffled_set):
        os.mkdir(shuffled_set)

    for ml_mode in ["Training", "Validation"]:
        print(f"Mode: {ml_mode}")
        x = np.asarray([])
        upgrades = np.asarray([])
        y = None
        agents = np.asarray([])
        gamenums = np.asarray([])
        races = np.asarray([])
        data_length = 0
        save_path = os.path.join(shuffled_set, ml_mode)
        if not os.path.isdir(save_path):
            os.mkdir(save_path)

        for save_type in ["units", "upgrades", "labels", "agents", "gamenums", "races"]:
            if not os.path.isdir(os.path.join(save_path, save_type)):
                os.mkdir(os.path.join(save_path, save_type))

        milestones = [int(i) for i in os.listdir(os.path.join(path, ml_mode)) if ".txt" not in i]

        milestones.sort()
        milestones = [str(i) for i in milestones]
        file_num = 0
        for milestone in milestones:
            print(f"\tReading milestone {milestone}")
            filepath = os.path.join(path, ml_mode, milestone)
            raw_filepath = os.path.join(raw_path, ml_mode, milestone)
            # Read in the data and the labels of an entire milestone and append the rest
            # of the data
            (data, upgrade_data, labels, agent_data, gamenum_data, races_data,) = read_files(
                filepath, raw_filepath
            )

            data_length += len(labels)

            if y is not None:
                x = np.append(x, data[0::2], axis=0)
                upgrades = np.append(upgrades, upgrade_data[0::2], axis=0)
                y = np.append(y, np.array(labels)[0::2], axis=0)
                agents = np.append(agents, agent_data[0::2], axis=0)
                gamenums = np.append(gamenums, gamenum_data[0::2], axis=0)
                races = np.append(races, races_data[0::2], axis=0)
            else:
                x = np.copy(data[0::2])
                upgrades = np.copy(upgrade_data[0::2])
                y = np.copy(labels[0::2])
                agents = np.copy(agent_data[0::2])
                gamenums = np.copy(gamenum_data[0::2])
                races = np.copy(races_data[0::2])

            if x.shape[0] > 73960:
                break
        shuffle_and_save(x, upgrades, y, agents, gamenums, races, save_path, file_num)
        file_num += 1
        np.save(
            os.path.join(shuffled_set, f"{ml_mode.lower()}_stats.npy"),
            (samples_per_file, data_length),
        )


class GameRecorder:
    def __init__(self, path, mode, races, agents):
        """Class used for recording games for the classifier

        Parameters
        ----------
        path : string
            path to the save directory
        mode : string
            Either "Training", "Testing", or "Validation" depending on how the games should be
            logged
        races : List
            the races that are to be recorded
        agents : List
            the agents that are to be used for the matches
        """
        self.path = path
        self.mode = mode
        self.agents = agents

        race_strings = []
        for race in races:
            if race == units.Terran:
                race_strings.append("terran")
            elif race == units.Zerg:
                race_strings.append("zerg")
            elif race == units.Protoss:
                race_strings.append("protoss")

        self.blue_race = race_strings[0]
        self.red_race = race_strings[1]

        self.log_file = os.path.join(self.path, f"{self.mode.lower()}_log")

        if not os.path.isdir(self.path):
            os.mkdir(self.path)

        self.save_path = os.path.join(self.path, self.mode)
        if not os.path.isdir(self.save_path):
            os.mkdir(self.save_path)

        # Datasets are set up as PATH_TO_DATASET/MODE/MILESTONE/INDIVIDUAL_GAME_FILES
        # Find the last milestone reached (all milestone directories are simply a number
        # indicating the number of games recorded)
        milestone_list = [
            int(dir_name) for dir_name in os.listdir(self.save_path) if dir_name.isnumeric()
        ]

        # If the milestone list is not empty, than we should resume recording from where
        # we left off
        if len(milestone_list) > 0:
            latest_milestone = sorted(milestone_list)[-1]

            # Make note of the path to current milestone
            self.milestone_path = os.path.join(self.save_path, str(latest_milestone))

            # See how many games are currently in the milestone directory
            game_list = os.listdir(self.milestone_path)
            if len(game_list) > 0:
                latest_file = sorted(game_list)[-1]
                # From the filename, grab the game number
                self.ep_num = int(latest_file.split("_")[0]) + 1
            else:
                # If the milestone directory is empty (i.e., we reached the milstone, but
                # failed to complete the game), then the game number is just the milestone
                # number
                self.ep_num = latest_milestone
        else:
            self.ep_num = 0

        # A dictionary to record wins between races
        self.wins = {
            "terran": {"terran": [0, 0], "zerg": [0, 0], "protoss": [0, 0],},
            "zerg": {"terran": [0, 0], "zerg": [0, 0], "protoss": [0, 0],},
            "protoss": {"terran": [0, 0], "zerg": [0, 0], "protoss": [0, 0],},
        }

    def save_episode(self, result, unit_data, upgrades):
        """Saves the episode

        Parameters
        ----------
        result : int
            integer that represents whether red or blue won
        unit_data : np.ndarray
            unit data from the episode
        upgrades : np.ndarray
            upgrade data from the episode

        Returns
        -------
        self.ep_num
            the episode number of the match
        """
        milestone = (self.ep_num // 500) * 500
        self.milestone_path = os.path.join(self.save_path, str(milestone))
        if not os.path.isdir(self.milestone_path):
            os.mkdir(self.milestone_path)

        save_data = [{"upgrades": upgrades, "data": unit_data, "agents": self.agents}]

        filename = os.path.join(self.milestone_path, f"{self.ep_num:05d}_{result}.npy")

        np.save(filename, save_data)

        # Load the win record for the dataset
        if os.path.isfile(self.log_file):
            self.wins = np.load(self.log_file, allow_pickle=True)[0]

        # Keep track of who won against who
        self.wins[self.blue_race][self.red_race][0] += result
        # Keep track of how many games have been played
        self.wins[self.blue_race][self.red_race][1] += 1

        # Do this again, but for the reverse setup
        self.wins[self.red_race][self.blue_race][0] += 1 - result
        self.wins[self.red_race][self.blue_race][1] += 1

        np.save(self.log_file, [self.wins])

        self.ep_num += 1

        return self.ep_num


if __name__ == "__main__":
    shuffle_dataset(
        "/media/banshee/gb_winprob/Data/proc_dataset_v3",
        "/media/banshee/gb_winprob/Data/raw_dataset_v3",
    )
