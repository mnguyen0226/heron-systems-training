import json
import os
from typing import Dict
from typing import List
from typing import Tuple

import numpy as np
import torch
from adept.network import ModularNetwork
from adept.preprocess import GPUPreprocessor
from adept.preprocess import MultiOperation
from adept.preprocess import SimpleOperation
from adept.utils.util import DotDict
from pysc2.lib import units
from pysc2.lib.features import FeatureUnit
from pysc2.lib.features import PlayerRelative
from pysc2.lib.upgrades import Upgrades

from gamebreaker.agent import AGENT_LIST
from gamebreaker.classifier.network import CUSTOM_REGISTRY
from gamebreaker.env.base import CustomObsIdx
from gamebreaker.env.base import ObsIdx
from gamebreaker.env.base.ops import FilterForNet

##########################################################################################
# Common Constants
##########################################################################################
UPGRADES_MAP = {e.value: i for i, e in enumerate(Upgrades)}

RACE_MAP = {"terran": 0, "protoss": 1, "zerg": 2}

ALL_INDICES = list(ObsIdx) + list(CustomObsIdx)

DASHBOARD_INDICES = [
    ObsIdx.unit_type_bit0,
    ObsIdx.unit_type_bit1,
    ObsIdx.unit_type_bit2,
    ObsIdx.unit_type_bit3,
    ObsIdx.unit_type_bit4,
    ObsIdx.unit_type_bit5,
    ObsIdx.unit_type_bit6,
    ObsIdx.unit_type_bit7,
    ObsIdx.unit_type_bit8,
    ObsIdx.alliance_bit0,
    ObsIdx.alliance_bit1,
    ObsIdx.alliance_bit2,
    ObsIdx.attack_upgrade_level_bit0,
    ObsIdx.attack_upgrade_level_bit1,
    ObsIdx.armor_upgrade_level_bit0,
    ObsIdx.armor_upgrade_level_bit1,
    ObsIdx.shield_upgrade_level_bit0,
    ObsIdx.shield_upgrade_level_bit1,
    ObsIdx.health,
    ObsIdx.shield,
    ObsIdx.energy,
    ObsIdx.health_ratio,
    ObsIdx.shield_ratio,
    ObsIdx.energy_ratio,
]


##########################################################################################
# Function for building a classifier from args
##########################################################################################
def get_path_from_args(args: DotDict) -> str:
    """Function for getting the path to the model from arguments. If the directory does
    not exist, this function creates one

    Parameters
    ----------
    args: DotDict
        Arguments used to create a classifier. Must contain "logdir" as a path to the directory
        containing multiple models, and "tag," the name of the model
    Returns
    -------
    str
        Path to the model
    """
    if not os.path.isdir(os.path.join(args.logdir, args.tag)):
        os.mkdir(os.path.join(args.logdir, args.tag))
        print("Created dir:", os.path.join(args.logdir, args.tag))
    return os.path.join(args.logdir, args.tag)


def get_old_args(new_args: DotDict, model_path: str) -> DotDict:
    """This function will find the old args to the specified model and combine them with
    the new args

    Parameters
    ----------
    new_args: DotDict
        Arguments used to build a classifier. If an older version of the arguments are found, then
        the new arguments will override those (useful for training on a different GPU than previous)
        If no old arguments are found, then new_args is returned unchanged
    model_path: str
        Path to the directory containing "args.json" for this model

    Returns
    -------
    DotDict
    """
    file_list = os.listdir(model_path)

    if "args.json" in file_list:
        with open(os.path.join(model_path, "args.json"), "r") as fp:
            old_args = json.load(fp)

        args = {}

        for arg_name in old_args:
            if arg_name in new_args:
                args[arg_name] = new_args[arg_name]
            else:
                args[arg_name] = old_args[arg_name]

        return DotDict(args)

    print("Old arguments not found! Returning unchanged args...")
    return new_args


def save_args(args: DotDict, model_path: str) -> None:
    """This function saves the arguments to a json file

    Parameters
    ----------
    args: DotDict
        Arguments used to build a classifier
    model_path: str
        Path where the model is saved

    Returns
    -------
    None
    """
    with open(os.path.join(model_path, "args.json"), "w") as fp:
        json.dump(args, fp, indent=4)


def get_network(args: DotDict, model_path: str) -> ModularNetwork:
    """Builds an Adept modular network from the arguments typically used in Gamebreaker

    Parameters
    ----------
    args: DotDict
        Arguments used to build the classifier. Required arguments are:
        - nb_units: int
        - feature_indices: List[int]
        - output_labels: List[str]
        - gpu_id: int
    model_path: str
        Path to where the model will be saved

    Returns
    -------
    ModularNetwork
    """
    model_file = None
    models_list = os.listdir(model_path)
    if "model_best.pt" in models_list:
        model_file = os.path.join(model_path, "model_best.pt")

    # The input space of the model
    obs_space = {
        "units": (len(args.feature_indices), args.nb_units),
        # "upgrades": (2 * (len(Upgrades) + len(AGENT_LIST) + len(RACE_MAP)),),
    }

    # Output space of the model
    output_space = {key: (1,) for key in args.output_labels}

    gpu_preprocessor = GPUPreprocessor([], obs_space)
    # Create the actual model
    network = ModularNetwork.from_args(
        args, obs_space, output_space, gpu_preprocessor, CUSTOM_REGISTRY
    )

    # If a previous model exists, then we load in all of its weights
    if model_file:
        try:
            network.load_state_dict(
                torch.load(model_file, map_location=lambda storage, loc: storage)
            )
        except RuntimeError:
            print("Couldn't load previous model (possibly corrupt)! Initializing new model.")
    # Move the model onto the specified GPU
    network.to(args.gpu_id)

    return network


##########################################################################################
# Functions for updating the inputs to the classifier
##########################################################################################
def get_context_vector(
    upgrade_data: torch.Tensor, race_data: torch.Tensor, player_agents: List[Tuple[int, int]],
) -> torch.Tensor:
    """Function for combining the upgrade data, races data, and agent data into the shape
    expected by the 1D input head of the win probability classifier

    Parameters
    ----------
    upgrade_data : torch.Tensor
        Tensor of units upgrade data
    race_data : torch.Tensor
        Tensor of the two races that are involved in the engagement
    agent_names : List[Tuple[str, str]]
        List of the agent names that are controlling the engagement

    Returns
    -------
    torch.Tensor
        Context vector of the combined inputs

    Raises
    ------
    RuntimeError
        upgrade data must have dim=2
    RuntimeError
        race data must have dim=2
    RuntimeError
        All inputs must have the same length
    """
    # First, make sure that the input is correct
    if upgrade_data.dim() != 2:
        raise RuntimeError(
            f"1st positional argument should have dim=2, got dim={upgrade_data.dim()}"
        )

    if race_data.dim() != 2:
        raise RuntimeError(f"2nd positional argument should have dim=2, got dim={race_data.dim()}")

    if upgrade_data.shape[0] != race_data.shape[0] or upgrade_data.shape[0] != len(player_agents):
        raise RuntimeError(
            f"All inputs should have the same length! Received lengths "
            + f"{upgrade_data.shape[0]}, {race_data.shape[0]}, {len(player_agents)}"
        )

    # First step is to concatenate the upgrades and the races
    upgrades_w_races = add_one_hot_vector(upgrade_data, race_data, len(RACE_MAP))

    # Second step is to concatenate the previous tensor with the agents
    context_vector = add_one_hot_vector(
        upgrades_w_races, torch.tensor(player_agents), len(AGENT_LIST)
    )

    return context_vector


def get_races_encoding(unit_data: torch.Tensor) -> torch.Tensor:
    """Function for getting the blue and red player's races from the unit lists.

    Obtains the races from the unit lists. The unit_data should be a 3D tensor with dimensions
    (batch, units, features). This data should be UNPROCESSSED (raw). Returns a 2D tensor with
    dimensions (batch, player)

    Parameters
    ----------
    unit_data : torch.Tensor
        unit data

    Returns
    -------
    torch.Tensor
        tensor containing the players races in the match
    """
    player_races = torch.zeros((unit_data.shape[0], 2))

    # Iterate through each of the timesteps
    for ts_ix, timestep in enumerate(unit_data):
        # Grab the units belonging to blue (player 1)
        blue_units = [
            unit[FeatureUnit.unit_type]
            for unit in timestep
            if unit[FeatureUnit.alliance] == PlayerRelative.SELF
        ]
        # Grab the units belonging to red (player 2)
        red_units = [
            unit[FeatureUnit.unit_type]
            for unit in timestep
            if unit[FeatureUnit.alliance] == PlayerRelative.ENEMY
        ]

        # Use the first unit from each player list to determine player race
        for player_ix, player_unit in enumerate([blue_units[0], red_units[0]]):
            # The player_race_ix is the location in the one-hot encoding that corresponds
            # to the player's race
            # We use the index from RACES_MAP and add a value to shift to the correct
            # player's section of  the one-hot vector
            if player_unit in list(units.Terran):
                player_races[ts_ix, player_ix] = RACE_MAP["terran"]
            elif player_unit in list(units.Protoss):
                player_races[ts_ix, player_ix] = RACE_MAP["protoss"]
            else:
                player_races[ts_ix, player_ix] = RACE_MAP["zerg"]

    return player_races.long()


def get_agent_encodings(player_agents: List[Tuple[str, str]]) -> torch.Tensor:
    """Function for obtaining red and blue agent encodings from the player agents list

    Expects a list of tuples, each containing 2 strings with the class names of the
    agents playing. Returns 2D tensor with shape (len(agent_names), 2) containing integer
    mappings of the player agents.

    When adding more agents it is critical to update the AGENT_LIST in gamebreaker/agent/__init__.py


    Parameters
    ----------
    player_agents : List[Tuple[str, str]]
        List of tuples contining strings of the class names of the agents playing

    Returns
    -------
    torch.Tensor
        encoded 2D tensor of integer mappings of the player agents
    """
    encoded_agents = torch.zeros((len(player_agents), 2))
    agent_names = [agent_string.rsplit(".")[-1] for agent_string in AGENT_LIST]
    # Iterate through the timesteps
    for ts_ix, timestep in enumerate(player_agents):
        # Iterate over players
        for player_ix, player_agent in enumerate(timestep):
            # Use the agent's index in AGENT_LIST as the int value of the agent
            encoded_agents[ts_ix, player_ix] = agent_names.index(player_agent)

    return encoded_agents.long()


def create_upgrades_vec(upgrades: List[List[int]], upgrades_map: Dict = UPGRADES_MAP) -> np.ndarray:
    """Creates the upgrades vector given the upgrads list and the upgrades map

    Parameters
    ----------
    upgrades : List[List[int]]
        List of the List of upgrades that are active in a match
    upgrades_map : Dict, optional
        Mapping of index location to actual upgrade, by default UPGRADES_MAP

    Returns
    -------
    np.ndarray
        np array of the upgrades for a match
    """
    upgrade_vec = np.zeros(len(upgrades_map) * 2)
    i = 0
    for upgrade in upgrades:
        for up in upgrade:
            upgrade_vec[upgrades_map[up] + i] = 1
        i += len(upgrades_map)
    return upgrade_vec


def add_one_hot_vector(
    base_vectors: torch.Tensor, new_vectors: torch.Tensor, one_hot_length: int
) -> torch.Tensor:
    """Function for combining two tensors. new_vectors is assumed to be size
    (batch_size, 2), where 2 is the number of players
    max_value should be the actual largest value seen (not the number of unique values)

    Parameters
    ----------
    base_vectors: torch.Tensor
        Vectors that will appear first in the output. Should already by one-hot
    new_vectors: torch.Tensor
        Vectors that will appear second in the output. Doesn't have to be one-hot
    one_hot_length: int
        Number of classes in the one-hot vector for new_vectors

    Returns
    -------
    torch.Tensor
        One-hot vectors where base_vectors appears at the beginning, new_vectors appears at the end,
        converted to a one-hot
    """

    # Create the return tensor (number of samples in dimension 0 should be the same,
    # size of dimension 1 will be the length of the base vectors plus the length of the
    # newly-encoded vectors
    combined_vector = torch.zeros((base_vectors.shape[0], base_vectors.shape[1] + one_hot_length))

    # Insert the base vectors into the return tensor
    combined_vector[:, 0 : base_vectors.shape[1]] = base_vectors[:, :]

    # Convert player 1's data to one-hot
    player_1_vec = torch.zeros((new_vectors.shape[0], one_hot_length)).double()
    player_1_vec[range(new_vectors.shape[0]), new_vectors[:, 0]] = 1

    # Convert player 2's data to one-hot
    player_2_vec = torch.zeros((new_vectors.shape[0], one_hot_length)).double()
    player_2_vec[range(new_vectors.shape[0]), new_vectors[:, 1]] = 1

    # Return the concatenated tensor
    return torch.cat((base_vectors, player_1_vec, player_2_vec), dim=1)


# TODO: talk to either Joe or Joseph for better documentation of these operations
class CreateEmptyArray(SimpleOperation):
    def __init__(self, seq_len, input_field, output_field, numpy=False):
        """Creates an empty array

        Parameters
        ----------
        seq_len : int
            Length of the empty array
        input_field : string
            input field of the array
        output_field : string
            output field of the array
        numpy : bool, optional
            whether or not to output as a numpy array, if false, a torch tensor is output, by
            default False
        """
        super().__init__(input_field, output_field)
        self.seq_len = seq_len
        self.numpy = numpy

    def update_shape(self, old_shape):
        """Update the shape

        Parameters
        ----------
        old_shape : unused
            unused

        Returns
        -------
        self.seq_len, len(ObsIdx)
            The length of the sequence, and the length of the indices of the processed observation
        """
        return self.seq_len, len(ObsIdx)

    def update_dtype(self, old_dtype):
        """updates the data type

        TODO: what does this do?

        Parameters
        ----------
        old_dtype :
            old data type

        Returns
        -------
        old_dtype
            returns the input old_dtype
        """
        return old_dtype

    def preprocess_cpu(self, tensor):
        """Perform preprocessing if on the CPU

        Parameters
        ----------
        tensor : Torch.tensor
            unused

        Returns
        -------
        Zeros array
            np array if self.numpy, otherwise a torch tensor
        """
        if self.numpy:
            return np.zeros(shape=(self.seq_len, len(ObsIdx)))
        else:
            return torch.zeros(size=(self.seq_len, len(ObsIdx)))

    def preprocess_gpu(self, tensor):
        """Perform preprocessing if on the GPU

        Parameters
        ----------
        tensor : Torch.tensor
            unused

        Returns
        -------
        Zeros array
            np array if self.numpy, otherwise a torch tensor
        """
        if self.numpy:
            return np.zeros(shape=(tensor.shape[0], self.seq_len, len(ObsIdx)))
        else:
            return torch.zeros(size=(tensor.shape[0], self.seq_len, len(ObsIdx)))


class CopyOverClassifier(MultiOperation):
    def update_shape(self, old_shape):
        """Update the shape

        Parameters
        ----------
        old_shape :
            the old shape

        Returns
        -------
        old_shape
            the old shape
        """
        return old_shape

    def update_dtype(self, old_dtype):
        """Update the data type

        Parameters
        ----------
        old_dtype :
            the old data type

        Returns
        -------
        old_dtype
            the old data type
        """
        return old_dtype

    def preprocess_cpu(self, tensors):
        """Preprocess cpu, unused

        Parameters
        ----------
        tensors : Torch.tensor
            Tensors to copy over

        Raises
        ------
        NotImplemented
            This method does not run on CPU
        """
        raise NotImplemented

    def preprocess_gpu(self, tensors):
        """Preprocess operation on the GPU

        Parameters
        ----------
        tensors : Torch.tensor
            Tensors to copy over

        Returns
        -------
        List of the new tensor
        """
        for i in range(len(tensors[0])):
            tensors[1][i][: tensors[0][i].shape[0], : tensors[0][i].shape[1]] = tensors[0][i][:]
        return [tensors[1]]


def normalize_size(obs: torch.Tensor) -> torch.Tensor:
    """Function to normalize each timestep to have the same unit vector length. This ensures
    that the data being passed into the network is the same size each timestep by making
    the input the largest possible array it can be.

    Parameters
    ----------
    obs: torch.Tensor
        Raw output from PySC2

    Returns
    -------
    torch.Tensor
        Output with zero-vectors appended onto the end so the last dimension has uniform size
    """

    observation_space = {"raw_units": (None, obs[0].shape[1])}
    observation_dtypes = {"raw_units": np.int64}
    gpu_preprocessor = GPUPreprocessor(
        [
            CreateEmptyArray(512, "raw_units", "proc_units", numpy=True),
            CopyOverClassifier(["raw_units", "proc_units"], ["proc_units"]),
            FilterForNet("raw_units", "raw_units"),
        ],
        observation_space,
        observation_dtypes,
    )
    obs = {"raw_units": obs}
    obs = gpu_preprocessor(obs)
    return obs["proc_units"]
