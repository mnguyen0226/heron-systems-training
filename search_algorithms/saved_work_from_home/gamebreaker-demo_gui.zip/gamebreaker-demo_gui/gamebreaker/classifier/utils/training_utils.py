import json
import os
import sys
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import torch
from torch.utils.tensorboard import SummaryWriter

from gamebreaker.classifier.utils.common_utils import get_context_vector
from gamebreaker.classifier.utils.common_utils import RACE_MAP
from gamebreaker.classifier.utils.common_utils import UPGRADES_MAP
from gamebreaker.data.upgrade_data import _PROTOSS_UPGRADES
from gamebreaker.data.upgrade_data import _TERRAN_UPGRADES
from gamebreaker.data.upgrade_data import _ZERG_UPGRADES


def rolling_average(prev_sum: float, curr_sum: float, prev_nb_samples: int) -> float:
    """Calculates a rolling average

    Parameters
    ----------
    prev_sum : float
        the previous sum
    curr_sum : float
        the current sum
    prev_nb_samples : int
        the previous number of samples

    Returns
    -------
    float
        the new rolling average
    """
    return ((prev_sum * prev_nb_samples) + curr_sum) / (prev_nb_samples + 1)


class ModelResultsLogger:
    """Logger for training the classifier"""

    def __init__(self, model_path: str, max_bar_length: int = 20):
        """Logger for training the classifier

        Parameters
        ----------
        model_path : str
            the path the model is stored at
        max_bar_length : int, optional
            the maximum length of the logging bar, by default 20
        """
        # Full path to where the model is stored
        self._model_path = model_path

        # How long the progress bar printed to the terminal should be
        self._max_bar_length = max_bar_length

        # Tensorboard summary writer
        self._summary_writer = SummaryWriter(self._model_path)

        # Lets the logger remember the last thing it printed out
        self._stdout = ""

        # Let's the logger know when a new epoch has begun
        self._curr_epoch = 0

        # Open the previous counting files (if they exist)
        try:
            # See if the file already exists and read in from it
            with open(os.path.join(self._model_path, "count.json"), "r") as file:
                val_count, train_count = json.load(file)
                self._counters = {
                    "Training": train_count,
                    "Validation": val_count,
                }
        except:
            # If the file doesn't exist (or if there's some JSON read error), create the
            # file
            with open(os.path.join(self._model_path, "count.json"), "w") as file:
                self._counters = {"Training": 0, "Validation": 0}
                json.dump(
                    (self._counters["Validation"], self._counters["Training"]), file,
                )

    def log_to_tensorboard(
        self, acc: Dict[str, torch.Tensor], loss: Dict[str, torch.Tensor], train_step: bool
    ):
        """Function to log batch accuracy and epoch results to tensorboard

        Parameters
        ----------
        acc : Dict[str, torch.Tensor]
            accuracy dictionary for each label
        loss : Dict[str, torch.Tensor]
            loss dictionary for each label
        train_step : bool
            whether or not the current step is a training step
        """

        # Folder is used to organize the tensorboard drop-downs
        if train_step:
            folder = "Training"
        else:
            folder = "Validation"

        # Log loss to tensorboard
        for key in loss:
            self._summary_writer.add_scalar(
                f"{folder}_Loss/{key}", loss[key], self._counters[folder]
            )

        # Log accuracy to tensorboard
        for key in acc:
            self._summary_writer.add_scalar(
                f"{folder}_Accuracy/{key}", torch.mean(acc[key]), self._counters[folder],
            )

        # Increment the counter based on which step we're on
        self._counters[folder] += 1

        # Save the counters
        with open(os.path.join(self._model_path, "count.json"), "w") as file:
            json.dump((self._counters["Validation"], self._counters["Training"]), file)

    def print_results(
        self,
        acc: Dict[str, float],
        loss: Dict[str, float],
        batches_completed: int,
        batches_total: int,
        epoch: int,
        train_step: bool,
    ):
        """Function for printing epoch results to the command line

        Parameters
        ----------
        acc : Dict[str, float]
            accuracy dictionary for each label
        loss : Dict[str, float]
            loss dictionary for each label
        batches_completed : int
            number of batches the model has been run on
        batches_total : int
            total number of batches to run
        epoch : int
            number of epochs the model has been running for
        train_step : bool
            whether or not the current step is a training step
        """
        # Determine how long the progress bar should be
        bar_length = round(self._max_bar_length * (batches_completed / batches_total)) + 1
        # Ensure its not longer than the maximum length
        bar_length = min((self._max_bar_length, bar_length))

        if train_step:
            # The progress bar should fill up based on how far into the epoch we are.
            # If we've trained over a fourth of the batches, the bar should be
            # max_len * 0.25 characters long. Helps to see how fast training is going, and
            # prevents madness
            # Character to show progress
            bar_char = "-"
            # Character to mark the end point (aesthetic purposes only)
            pointer_char = ">"
            # Character to show space left to be filled
            empty_char = " "
        else:
            # We change the characters used to construct the bar based on what mode we're
            # in
            bar_char = "="
            pointer_char = "="
            empty_char = "-"

        # Build the progress bar
        progress_bar = (
            "["
            + bar_char * (bar_length - 1)
            + pointer_char
            + empty_char * (self._max_bar_length - np.max((bar_length, 1)))
            + "]"
        )

        # If it's the first time we're printing, we should print out the head of the table
        if self._stdout == "":
            # Section bar labels the training and validation sections of the table
            section_bar = (
                "|"
                + " " * 5
                + "|"
                + " " * (self._max_bar_length + 2)
                + "|"
                + " " * 27
                + "Training"
                + " " * 28
                + "||"
                + " " * 26
                + "Validation"
                + " " * 27
                + "|"
            )

            # Divider is just the row separators
            divider = (
                "+"
                + "-" * 5
                + "+"
                + "-" * (self._max_bar_length + 2)
                + "+"
                + "-" * 63
                + "++"
                + "-" * 63
                + "+"
            )

            # Title bar labels each of the columns in the table
            title_bar = (
                f"|Epoch|"
                + f"{'Progress':{self._max_bar_length+2}}|"
                + "  Win  |"
                + " B Attr|"
                + " B Mine|"
                + " B Gas |"
                + " R Attr|"
                + " R Mine|"
                + " R Gas |"
                + " T Loss|"
                "|  Win  |"
                + " B Attr|"
                + " B Mine|"
                + " B Gas |"
                + " R Attr|"
                + " R Mine|"
                + " R Gas |"
                + " T Loss|"
            )
            print(divider)
            print(section_bar)
            print(divider)
            print(title_bar)
            print(divider)

        # If the epoch has changed, print a newline
        if epoch != self._curr_epoch:
            print("")
            self._curr_epoch = epoch

        # If it's the training step, we should update self._stdout (this is used to track
        # the accuracies and loss for the training step only to be easily printed out)
        if train_step:
            output = f"\r|{epoch:5d}|{progress_bar}|"
            self._stdout = ""
            for key in acc:
                self._stdout += f" {acc[key]: 0.3f}|"
            self._stdout += f" {loss['total']: 0.3f}|"
            sys.stdout.write(output + self._stdout)
            sys.stdout.flush()
        else:
            output = f"\r|{epoch:5d}|{progress_bar}|" + self._stdout + "|"
            for key in acc:
                output += f" {acc[key]: 0.3f}|"
            output += f" {loss['total']: 0.3f}|"
            sys.stdout.write(output)
            sys.stdout.flush()


class GBDataset:
    def __init__(
        self,
        filepath: str,
        batch_size: int,
        gpu_id: Optional[int] = None,
        indices: Optional[List[int]] = None,
        noise_threshold: Optional[int] = 5,
        ram_size: Optional[int] = 64,
    ):
        """Dataset iterator for the PySC2 dataset. Will lazily load the data to not take up
        excessive amounts of RAM at the expense of some training speed.

        Parameters
        ----------
        filepath: str
            Path to the dataset to be read in. Should include the "Training" or "Validation"
            directory
        batch_size: int
            Number of samples to be batched together and passed out
        gpu_id: Optional[int]
            Device number to move the samples to
        indices: Optional[List[int]]
            List of indices of features that should be passed out. If None, then all indices are
            passed
        noise_threshold: Optional[int]
            Percent of the time that no noise should be added to the upgrades
        ram_size: Optional[int]
            Number of batches to load into memory at once. A value of 0 means to load all data into
            RAM at once
        """
        # Absolute path to the directory where all files are stored (this has to include
        # 'Training' or 'Validation'
        self._filepath = filepath

        # Batch size being used by the classifier
        self._batch_size = batch_size

        # If a gpu_id is specified, we store that so we can move data onto the GPU as
        # needed
        if gpu_id is not None:
            self._gpu_id = torch.device(f"cuda:{gpu_id}")
        else:
            self._gpu_id = None

        # indices is the list of indices that should be passed into the classifier
        self._indices = torch.tensor(indices)

        # shuffle_threshold is the percentage of times the classifier should see
        # an upgrades vector with no noise added.
        self._noise_threshold = noise_threshold

        # Load in the iteratable unit data
        self._unit_data = self._load_data(os.path.join(filepath, "units", "0", "000.npy"),)

        # Load in the iteratable upgrade data
        self._upgrade_data = self._load_data(os.path.join(filepath, "upgrades", "0", "000.npy"))

        # Load in the iteratable race data
        self._race_data = self._load_data(os.path.join(filepath, "races", "0", "000.npy"))

        # Load in the iteratable agent data
        self._agent_data = self._load_data(os.path.join(filepath, "agents", "0", "000.npy"))

        # Load in the iteratable label data
        self._label_data = self._load_data(os.path.join(filepath, "labels", "0", "000.npy"))

        # The length of our dataset (in batches)
        self._length = self._unit_data.shape[0]

        # How many timesteps to load into RAM at once
        if ram_size == 0:
            self.ram_size = self._length
        else:
            self.ram_size = ram_size

        # Bit mask used to find terran, protoss, and zerg upgrades
        self._upgrade_mask = self._get_upgrade_mask()

    @staticmethod
    def _get_upgrade_mask() -> torch.Tensor:
        """Create a bit-mask showing where each race's upgrades are in the upgrade vector

        Returns
        -------
        torch.Tensor
            a bitmask for the upgrades
        """
        # Get a list of the upgrades for each race
        race_upgrades = [
            [_TERRAN_UPGRADES[upgrade].upgrade for upgrade in _TERRAN_UPGRADES],
            [_PROTOSS_UPGRADES[upgrade].upgrade for upgrade in _PROTOSS_UPGRADES],
            [_ZERG_UPGRADES[upgrade].upgrade for upgrade in _ZERG_UPGRADES],
        ]

        # Create a bitmask showing where each race's upgrades are in the upgrades vectors
        upgrade_mask = torch.zeros((len(RACE_MAP), len(UPGRADES_MAP)))
        for ix, race in enumerate(race_upgrades):
            upgrade_mask[ix, :] = torch.tensor([key in race for key in UPGRADES_MAP])

        return upgrade_mask

    def _load_data(self, filename: str) -> np.ndarray:
        """Loads all of the initial data using a memory map for quick loading

        Parameters
        ----------
        filename: str
            The true name of the .npy file to be loaded
        timestep_shape: List[int]
            The shape of a single timestep for this data

        Returns
        -------
        np.ndarray
            Returns the data with dimensions [nb_batches, batch_size, *timestep_shape]
        """
        # Load the numpy file
        data = np.load(filename, mmap_mode="r")

        if len(data) % self._batch_size != 0:
            # Drop the last samples so that data can be split into batches
            data = data[0 : -1 - len(data) % self._batch_size + 1]

        # Determine how many batches we'll have
        nb_batches = len(data) // self._batch_size

        timestep_shape = list(data.shape[1:])

        # Reshape size then becomes (nb_batches, batch_size, timestep_shape)
        # timestep_shape can be a 2D list (unit_list) or -1 (meaning its 1D)
        reshape_size = [nb_batches, self._batch_size] + timestep_shape

        return np.reshape(data, tuple(reshape_size))

    def __getitem__(self, batch_idx: int) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Gets an item from the data currently loaded into memory.
        NOTE: This function will not act as a proper __getitem__() function. It won't pull from the
        entire dataset, but rather just from the samples that have been loaded into memory

        Parameters
        ----------
        batch_idx: int
            The index to use to retrieve the data.
        Returns
        -------
        Tuple[torch.Tensor, torch.Tensor, torch.Tensor]
            The unit data, context data, and label data, respectively
        """
        if batch_idx % self.ram_size == 0:
            end_idx = batch_idx + self.ram_size
            self._ram_units = np.copy(self._unit_data[batch_idx:end_idx, :, :, :])
            self._ram_upgrades = np.copy(self._upgrade_data[batch_idx:end_idx, :, :])
            self._ram_races = np.copy(self._race_data[batch_idx:end_idx, :, :])
            self._ram_agents = np.copy(self._agent_data[batch_idx:end_idx, :, :])
            self._ram_labels = np.copy(self._label_data[batch_idx:end_idx, :, :])

        # Grab the current batch data
        unit_batch = torch.from_numpy(self._ram_units[batch_idx % self.ram_size, :, :, :])
        upgrade_batch = torch.from_numpy(self._ram_upgrades[batch_idx % self.ram_size, :, :])
        race_batch = torch.from_numpy(self._ram_races[batch_idx % self.ram_size, :, :])
        agent_batch = self._ram_agents[batch_idx % self.ram_size, :, :]
        label_batch = torch.from_numpy(self._ram_labels[batch_idx % self.ram_size, :, :])

        # Add noise to the upgrade data (but only sometimes)
        if np.random.randint(0, high=100) > self._noise_threshold:
            # Create a random upgrade tensor
            random_upgrade_batch = torch.randint(low=0, high=2, size=upgrade_batch.shape)

            # Grab the player races
            player_1_races, player_2_races = (
                race_batch[:, 0],
                race_batch[:, 1],
            )

            # Create the bit mask of which upgrades on each timestep are actually
            # important to game balance on that timestep
            batch_mask = torch.cat(
                (self._upgrade_mask[player_1_races, :], self._upgrade_mask[player_2_races, :],),
                dim=1,
            ).byte()

            # Create a tensor that takes the upgrades that apply to the player race
            # and replaces the other ones with noise
            noisy_upgrade_batch = torch.where(
                batch_mask, upgrade_batch.double(), random_upgrade_batch.double(),
            )
        else:
            # Sometimes just pass in the unaltered data
            noisy_upgrade_batch = upgrade_batch

        context_batch = get_context_vector(noisy_upgrade_batch, race_batch, agent_batch)

        # Grab only the indices desired by the classifier
        if len(self._indices) > 0:
            unit_batch = torch.index_select(unit_batch, 1, self._indices)

        # Randomly set ties (2.0) to either a loss or a win (0.0 or 1.0)
        random_labels = torch.randint(low=0, high=2, size=label_batch.shape).double()

        # This line will return a tensor that is either the value from labels if that
        # value is not 2.0 (tie). Otherwise, it will return the value in the same
        # position from random_labels
        label_batch = torch.where(label_batch == 2.0, random_labels, label_batch.double())

        unit_batch = unit_batch.float()
        context_batch = context_batch.float()
        label_batch = label_batch.permute(1, 0)

        if self._gpu_id is not None:
            unit_batch = unit_batch.to(self._gpu_id)
            context_batch = context_batch.to(self._gpu_id)
            label_batch = label_batch.to(self._gpu_id)

        return unit_batch, context_batch, label_batch

    def __iter__(self) -> "GBDataset":
        """__iter__ function so this thing is iterable

        Returns
        -------
        GBDataset
        """
        self._batch_idx = 0
        return self

    def __next__(self) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """__next__ function to make this iterable

        Returns
        -------
        Tuple[torch.Tensor, torch.Tensor, torch.Tensor]
            Unit data, context data, and label data, respectively
        """
        if self._batch_idx < self._length:
            # Grab the current batch
            unit_batch, context_batch, label_batch = self.__getitem__(self._batch_idx)
            # Increment our counter
            self._batch_idx += 1
            # Return the tensors
            return unit_batch, context_batch, label_batch
        else:
            raise StopIteration

    def __len__(self) -> int:
        """Length of the dataset

        Returns
        -------
        int
            The length of the dataset
        """
        return self._length
