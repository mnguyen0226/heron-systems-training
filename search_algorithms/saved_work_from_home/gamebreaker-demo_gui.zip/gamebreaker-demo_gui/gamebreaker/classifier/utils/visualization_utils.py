import numpy as np
import pandas as pd
import plotly.graph_objects as go
import shap
import torch
from adept.utils.util import DotDict

from gamebreaker.classifier.utils.common_utils import get_network
from gamebreaker.classifier.utils.common_utils import normalize_size
from gamebreaker.classifier.utils.dataset_utils import read_episode


def fix_label_positions(labels, threshold=0.05):
    """Fix the label positions

    Parameters
    ----------
    labels : List
        the labels of the data
    threshold : float, optional
        threshold value to fix by, by default 0.05

    Returns
    -------
    Tuple[List, List]
        The output labels and the output positions
    """
    out_labels = []
    out_positions = []
    for label in labels:
        if label in out_labels:
            continue

        label_pos = label
        while any(abs(label_pos - i) < threshold for i in out_positions):
            label_pos += 0.01

        out_labels.append(label)
        out_positions.append(label_pos)

    return out_labels, out_positions


def determine_temporal_accuracy(args_list, filepath):
    """This determines how accurate a networks predictions are across timesteps in a match

    Parameters
    ----------
    args_list : List
        contains arguments for each model to test
    filepath : string
        the path to the game to test accuracy on

    Returns
    -------
    accuracy list
        accuracy list of the networks on the match over time
    """
    # Determine the max length of engagements
    max_length = 0
    min_length = 100
    total_length = 0
    milestones = [int(i) for i in os.listdir(filepath) if ".txt" not in i]
    milestones.sort()
    milestones = [str(i) for i in milestones]
    for milestone in milestones:
        print(milestone)
        for file in os.listdir(os.path.join(filepath, milestone)):
            game_length = np.load(os.path.join(filepath, milestone, file), allow_pickle=True).shape[
                0
            ]
            if game_length > max_length:
                max_length = game_length

            if game_length < min_length:
                min_length = game_length

            total_length += game_length
    print(f"Max game length is {max_length}!")
    print(f"Min game length is {min_length}!")
    print(f"Total number of timesteps is {total_length}!")

    accuracy_list = np.zeros((len(args_list), max_length))
    # We want to specifically record the accuracy of the first and last timestep, so make
    # sure they aren't included in
    # the scaling
    scale_length = max_length - 2

    bin_count = np.zeros(max_length)
    for model_num, args in enumerate(args_list):
        network = get_network(args)
        count_list = np.zeros(max_length)
        running_accuracy = 0
        running_count = 0
        for milestone in milestones:
            print(milestone)
            for file in os.listdir(os.path.join(filepath, milestone)):
                data = np.load(os.path.join(filepath, milestone, file), allow_pickle=True)
                data = normalize_size(data)
                label = int(file[-5])
                y = np.full(data.shape[0], label)

                curr_length = data.shape[0]

                with torch.no_grad():
                    data = torch.from_numpy(data)
                    data = data.to(args.gpu_id)
                    y_pred = network.forward(data).cpu().numpy()

                y_pred = np.array([1 if i >= 0.5 else 0 for i in y_pred])
                timestep_accuracy = y_pred == y

                running_accuracy += np.sum(timestep_accuracy)
                running_count += len(timestep_accuracy)

                # Record the accuracy on the first and last time step
                accuracy_list[model_num, 0] += timestep_accuracy[0]
                count_list[0] += 1
                bin_count[0] += 1

                accuracy_list[model_num, -1] += timestep_accuracy[-1]
                count_list[-1] += 1
                bin_count[-1] += 1

                # Put the rest of the timesteps in locations based on their relative time
                # in the game
                curr_length = curr_length - 2
                indices = [i for i in range(1, curr_length)]
                for i in indices:
                    m = int(((i - 1) * (scale_length - 1)) / curr_length + 1)
                    accuracy_list[model_num, m] += timestep_accuracy[i]
                    count_list[m] += 1
                    bin_count[m] += 1
        accuracy_list[model_num, :] /= count_list[:]
        print(running_accuracy / running_count)
    return accuracy_list


def plot_predictions(x_data, y_data, model_names, title, xlabel):
    """Plots the predictions for models

    Parameters
    ----------
    x_data : array-like
        x data to plot
    y_data : array-like
        y data to plot
    model_names : List[String]
        list of names for the models
    title : string
        title for the plot
    xlabel : array-like
        the label for the x axes

    Returns
    -------
    fig : go.Figure
        the plotted predictions
    """
    fig = go.Figure()

    annotations = []

    start_points = []
    end_points = []
    for y, model_name in zip(y_data, model_names):
        fig.add_trace(
            go.Scatter(
                x=x_data,
                y=y,
                mode="lines+markers",
                name=model_name,
                line=dict(width=2),
                connectgaps=True,
            )
        )
        start_points.append(round(y[0], 2))
        end_points.append(round(y[-1], 2))

    start_points.sort()
    start_labels, start_pos = fix_label_positions(start_points)

    end_points.sort()
    end_labels, end_pos = fix_label_positions(end_points)

    for label, y_pos in zip(start_labels, start_pos):
        annotations.append(
            dict(
                xref="paper",
                x=0.05,
                y=y_pos,
                xanchor="right",
                yanchor="middle",
                text=label,
                font=dict(family="Arial", size=16),
                showarrow=False,
            )
        )

    for label, y_pos in zip(end_labels, end_pos):
        annotations.append(
            dict(
                xref="paper",
                x=0.95,
                y=y_pos,
                xanchor="left",
                yanchor="middle",
                text=label,
                font=dict(family="Arial", size=16),
                showarrow=False,
            )
        )

    fig.update_layout(
        title=dict(
            xref="paper",
            yref="paper",
            text=title,
            font=dict(family="Arial", size=30, color="rgb(37, 37, 37)"),
        ),
        xaxis=dict(
            showline=True,
            showgrid=False,
            showticklabels=True,
            linecolor="rgb(204, 204, 204)",
            linewidth=2,
            ticks="outside",
            tickfont=dict(family="Arial", size=12, color="rgb(82, 82, 82)",),
        ),
        yaxis=dict(showgrid=True, zeroline=True, showline=True, showticklabels=True,),
        xaxis_title=xlabel,
        yaxis_title="Probability of Blue Winning",
        annotations=annotations,
    )

    fig.update_yaxes(range=[-0.05, 1.05])
    return fig


def annotated_plot(predictions, model_names):
    """Creates an annotated plot of the model predictions

    Parameters
    ----------
    predictions : list
        List of dictionaries, each dictionary containing the following keys:
        - model : str, model name
        - pred : list of model predictions
    model_names : list
        List of strings to label each model with
    """

    y_data = predictions
    x_data = np.linspace(0, 1, len(predictions[0]))
    title = "Average Win Prediction Accuracy"
    xlabel = "Point in Game"
    fig = plot_predictions(x_data, y_data, model_names, title, xlabel)
    fig.show()


if __name__ == "__main__":
    import os

    model_names = ["Convpool", "Linear", "ResConv"]

    args = [
        {
            "save_loc": "/media/banshee/gb_winprob/",
            "model_name": name,
            "validation": True,
            "batch_size": 1,
            "gpu_id": 0,
            "datadir": "/media/banshee/gb_winprob/Data/proc_balanced_races_dev/",
        }
        for name in model_names
    ]

    args = [DotDict(arg) for arg in args]

    path = "/media/banshee/gb_winprob/Data/proc_advantage_disadvantage/Testing/"
    accuracies = determine_temporal_accuracy(args, path)
    annotated_plot(accuracies, [arg["model_name"] for arg in args])

    path = "/media/banshee/gb_winprob/Data/proc_advantage_disadvantage/Validation/"
    accuracies = determine_temporal_accuracy(args, path)
    annotated_plot(accuracies, [arg["model_name"] for arg in args])
    #
    # visualizer = WinProbVisualizer(args)
    # path = "/media/banshee/gb_winprob/Data/proc_advantage_disadvantage/Testing/0"
    # file_list = os.listdir(path)
    # file_list.sort()
    # for i in range(20):
    #     filename = os.path.join(path, file_list[i])
    #     pred = visualizer.predict_over_episode(filename)
    #     visualizer.annotated_plot(pred)
