from flask import jsonify
import time

from gamebreaker.backend.predict import predict
from gamebreaker.backend.process import (
    generate_perturbed_configs,
    generate_batches,
    generate_prediction_json,
)
from gamebreaker.backend.utils import generate_ticks

TICKS = generate_ticks()
temp = {}
for race, types in [
    ("terran", "units"),
    ("terran", "upgrades"),
    ("protoss", "units"),
    ("protoss", "upgrades"),
    ("zerg", "units"),
    ("zerg", "upgrades"),
]:
    for k, v in TICKS[race][types].items():
        temp[k] = v
TICKS = temp
UNIT_MAX = {k: TICKS[k][-1] for k in TICKS}


def handle(config):
    # t = time.time()
    configs = generate_perturbed_configs(config, unit_max=UNIT_MAX)
    # print('perturbed configs', time.time() - t)
    # t = time.time()
    batches, upgrades = generate_batches(configs)
    # print('batches', time.time() - t)
    # t = time.time()
    print(f'\n\n{batches.shape}\n\n')
    predictions = predict(batches, upgrades)
    print(predictions, end='\n\n')
    # print('predictions', time.time() - t)
    # t = time.time()
    final = generate_prediction_json(predictions, config, unit_max=UNIT_MAX)
    # print('configuring output', time.time() - t)
    # print(final)
    return jsonify(final)
