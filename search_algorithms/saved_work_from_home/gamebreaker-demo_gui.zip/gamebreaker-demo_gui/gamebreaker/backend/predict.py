import copy
import json

import numpy as np
import torch

from adept.utils.util import DotDict
from gamebreaker.classifier.network.network import Network

args = {
    "logdir": "/media/banshee/gb_winprob/attrition_models",
    "tag": "test_model",  # SHAP_model
    "test": True,
    "gpu_id": 0,
    # "batch_size": 1,
}

args = DotDict(args)

network = Network(args)


def predict(batches, upgrades):
    with torch.no_grad():
        predictions = network.forward(batches)  # network.forward(batches, upgrades)
    return predictions
