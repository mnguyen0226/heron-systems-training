import requests
import json

from gamebreaker.backend.utils import random_config

url = "http://127.0.0.1:5000"
payload = random_config()
print("payload ready")
r = requests.post(url, json=payload)
print("recieved response")
stuff = json.loads(r.content.decode())

print(payload, stuff)
