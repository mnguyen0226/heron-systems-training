from typing import List, Tuple, Union

import numpy as np
from pysc2.lib.upgrades import Upgrades
from pysc2.lib.units import Protoss, Terran, Zerg

from gamebreaker import unit_data
from gamebreaker.selector.base import Selector
from gamebreaker.unit_data import _AVAILABLE_UNITS, _UNIT_DATA
from gamebreaker.upgrade_data import (
    _PROTOSS_UPGRADES,
    _TERRAN_UPGRADES,
    _ZERG_UPGRADES,
)

MINERALS = 5000
GAS = 2075

TERRAN_UNITS = {unit for unit in _AVAILABLE_UNITS if isinstance(unit, Terran)}
PROTOSS_UNITS = {unit for unit in _AVAILABLE_UNITS if isinstance(unit, Protoss)}
ZERG_UNITS = {unit for unit in _AVAILABLE_UNITS if isinstance(unit, Zerg)}

PROTOSS_UPGRADES = {
    _PROTOSS_UPGRADES[upgrade].upgrade: _PROTOSS_UPGRADES[upgrade].upgrade.value
    for upgrade in _PROTOSS_UPGRADES
}
TERRAN_UPGRADES = {
    _TERRAN_UPGRADES[upgrade].upgrade: _TERRAN_UPGRADES[upgrade].upgrade.value
    for upgrade in _TERRAN_UPGRADES
}
ZERG_UPGRADES = {
    _ZERG_UPGRADES[upgrade].upgrade: _ZERG_UPGRADES[upgrade].upgrade.value
    for upgrade in _ZERG_UPGRADES
}

NAME_TO_UPGRADES = {upgrade.name: upgrade for upgrade in Upgrades}


def generate_coordinates(spawn, radius=4):
    return np.round(spawn + np.random.uniform(-radius, radius, 2))


def generate_spawn(map_size, radius=4):
    return np.round(
        np.random.uniform(
            [radius, radius], [map_size[0] - radius, map_size[1] - radius], 2
        )
    )


def tick_range(n):
    return list(range(n + 1))


def generate_unit_ticks(units=_AVAILABLE_UNITS, minerals=MINERALS, gas=GAS):
    return {
        unit.name: tick_range(
            min(
                int(
                    minerals
                    / (
                        _UNIT_DATA[unit].minerals
                        if _UNIT_DATA[unit].minerals > 0
                        else 1e-6
                    )
                ),
                int(
                    gas
                    / (
                        _UNIT_DATA[unit].gas
                        if _UNIT_DATA[unit].gas > 0
                        else 1e-6
                    )
                ),
            )
        )
        for unit in units
    }


def generate_upgrade_ticks(upgrades=Upgrades):
    upgrade_ticks = {}
    races = ["Protoss", "Terran", "Zerg"]

    for upgrade in upgrades:
        modified = False
        for race in races:
            if upgrade.name.find(race) != -1:
                if upgrade.name.find("Level") == -1:
                    upgrade_ticks[
                        upgrade.name[upgrade.name.find(race) + len(race) :]
                    ] = tick_range(1)
                else:
                    upgrade_ticks[
                        upgrade.name[
                            upgrade.name.find(race)
                            + len(race) : upgrade.name.find("Level")
                        ]
                    ] = tick_range(3)
                modified = True
        if not modified and upgrade.name.find("Level") == -1:
            upgrade_ticks[upgrade.name] = tick_range(1)
        elif not modified:
            upgrade_ticks[
                upgrade.name[: upgrade.name.find("Level")]
            ] = tick_range(3)

    return upgrade_ticks


def generate_ticks(minerals=MINERALS, gas=GAS):
    ticks = {
        "terran": {},
        "protoss": {},
        "zerg": {},
    }

    TERRAN_UNITS = {
        unit for unit in _AVAILABLE_UNITS if isinstance(unit, Terran)
    }
    PROTOSS_UNITS = {
        unit for unit in _AVAILABLE_UNITS if isinstance(unit, Protoss)
    }
    ZERG_UNITS = {unit for unit in _AVAILABLE_UNITS if isinstance(unit, Zerg)}
    ticks["terran"]["units"] = generate_unit_ticks(
        units=TERRAN_UNITS, minerals=minerals, gas=gas
    )
    ticks["protoss"]["units"] = generate_unit_ticks(
        units=PROTOSS_UNITS, minerals=minerals, gas=gas
    )
    ticks["zerg"]["units"] = generate_unit_ticks(
        units=ZERG_UNITS, minerals=minerals, gas=gas
    )

    PROTOSS_UPGRADES = {
        _PROTOSS_UPGRADES[upgrade]
        .upgrade: _PROTOSS_UPGRADES[upgrade]
        .upgrade.value
        for upgrade in _PROTOSS_UPGRADES
    }
    TERRAN_UPGRADES = {
        _TERRAN_UPGRADES[upgrade]
        .upgrade: _TERRAN_UPGRADES[upgrade]
        .upgrade.value
        for upgrade in _TERRAN_UPGRADES
    }
    ZERG_UPGRADES = {
        _ZERG_UPGRADES[upgrade].upgrade: _ZERG_UPGRADES[upgrade].upgrade.value
        for upgrade in _ZERG_UPGRADES
    }
    ticks["terran"]["upgrades"] = generate_upgrade_ticks(TERRAN_UPGRADES)
    ticks["protoss"]["upgrades"] = generate_upgrade_ticks(PROTOSS_UPGRADES)
    ticks["zerg"]["upgrades"] = generate_upgrade_ticks(ZERG_UPGRADES)

    return ticks


def initial_configs():
    configs = {
        "terran": {},
        "protoss": {},
        "zerg": {},
    }

    configs["terran"] = dict(
        configs["terran"], **{unit.name: 0 for unit in TERRAN_UNITS}
    )
    configs["protoss"] = dict(
        configs["protoss"], **{unit.name: 0 for unit in PROTOSS_UNITS}
    )
    configs["zerg"] = dict(
        configs["protoss"], **{unit.name: 0 for unit in ZERG_UNITS}
    )

    configs["terran"]["Marine"] = 2
    configs["protoss"]["Zealot"] = 1
    configs["zerg"]["Zergling"] = 4

    configs["terran"] = dict(
        configs["terran"],
        **{unit: 0 for unit in generate_upgrade_ticks(TERRAN_UPGRADES)}
    )
    configs["protoss"] = dict(
        configs["protoss"],
        **{unit: 0 for unit in generate_upgrade_ticks(PROTOSS_UPGRADES)}
    )
    configs["zerg"] = dict(
        configs["protoss"],
        **{unit: 0 for unit in generate_upgrade_ticks(ZERG_UPGRADES)}
    )

    return configs


def random_config(minerals=MINERALS, gas=GAS):
    ticks = generate_ticks(minerals=minerals, gas=gas)
    races = np.random.choice(["terran", "protoss", "zerg"], 2)

    config = {}
    for team, race in zip(["blue", "red"], races):
        config[team] = {race: {}}

        for key in ticks[race]["units"]:
            config[team][race][key] = int(np.random.choice(
                ticks[race]["units"][key]
            ))
        for key in ticks[race]["upgrades"]:
            config[team][race][key] = int(np.random.choice(
                ticks[race]["upgrades"][key]
            ))

    return config


class AllSelector(Selector):
    def __init__(
        self,
        available_units: List[
            Union[
                unit_data.units.Terran,
                unit_data.units.Protoss,
                unit_data.units.Zerg,
            ]
        ],
        x_area: Tuple[int, int] = (0, 10),
        y_area: Tuple[int, int] = (0, 10),
        units: int = np.Infinity,
        seed: int = None,
    ):
        super().__init__(available_units, x_area, y_area, seed)

        self.units = units

    def select(self):
        return self.format_dict(self.available_units)
