from flask import Flask, request, jsonify
from flask_cors import CORS

from gamebreaker.backend.handle_request import handle

app = Flask(__name__)
CORS(app)


@app.route("/", methods=["POST"])
def dashboard_predict():
    config = request.get_json()
    print(config, end='\n\n')
    return handle(config)


if __name__ == "__main__":
    app.run(debug=True)

# Run with:
# $ export FLASK_APP=server.py
# $ python -m flask run
