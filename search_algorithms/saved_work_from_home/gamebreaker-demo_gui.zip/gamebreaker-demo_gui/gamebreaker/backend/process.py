import copy
from itertools import chain

import numpy as np
from pysc2.lib.buffs import Buffs
from pysc2.lib.features import FeatureUnit
from pysc2.lib.units import Neutral, Terran, Protoss, Zerg

from adept.preprocess.base.preprocessor import CPUPreprocessor, GPUPreprocessor
from adept.preprocess.ops import FromNumpy, CastToFloat
from gamebreaker.backend.utils import (
    generate_spawn,
    generate_coordinates,
    generate_upgrade_ticks,
    NAME_TO_UPGRADES,
)
from gamebreaker.classifier.utils.preprocess_data import create_upgrades_vec
from gamebreaker.env.base.obs_info import (
    ExtraBuffs,
    ExtraUnitTypes,
    get_features_infos,
)
from gamebreaker.env.base.ops import (
    CopyOverScalarFeatures,
    CreateEmptyArray,
    ProcessCategoricalFeatures,
    ProcessScalarFeatures,
    FilterForNet,
)
from gamebreaker.unit_data import _UNIT_DATA, _AVAILABLE_UNITS

FEATURE_INFO = get_features_infos(32, 32)
ID_TO_UNIT = dict(
    enumerate(chain(Neutral, Terran, Protoss, Zerg, ExtraUnitTypes))
)
UNIT_TO_ID = {v: k for k, v in ID_TO_UNIT.items()}
NAME_TO_UNIT = {k.name: k for k in _AVAILABLE_UNITS}
ID_TO_BUFF = dict(enumerate(chain(Buffs, ExtraBuffs)))
BUFF_TO_ID = {v: k for k, v in ID_TO_BUFF.items()}

x_max, y_max = 32, 32
unit_max = 512

observation_space = {"raw_units": (None, len(FeatureUnit))}
observation_dtypes = {"raw_units": np.int64}

cpu_preprocessor = CPUPreprocessor(
    [
        FromNumpy("raw_units", "raw_units"),
        CreateEmptyArray(unit_max, "raw_units", "proc_units"),
        ProcessCategoricalFeatures(
            x_max, y_max, ["raw_units", "proc_units"], ["proc_units"]
        ),
        CopyOverScalarFeatures(["raw_units", "proc_units"], ["proc_units"]),
        FilterForNet("raw_units", "raw_units"),
    ],
    observation_space,
    observation_dtypes,
)
gpu_preprocessor = GPUPreprocessor(
    [
        FromNumpy("proc_units", "proc_units"),
        ProcessScalarFeatures(x_max, y_max, "proc_units", "proc_units"),
        CastToFloat("proc_units", "proc_units"),
    ],
    cpu_preprocessor.observation_space,
    {"proc_units": np.int64},
)

UPGRADE_TICKS = generate_upgrade_ticks()


def generate_army(troops, team, map_size=(x_max, y_max), radius=4, spawn=None):
    army = []
    # spawn = generate_spawn(map_size, radius) if spawn is None else spawn
    spawn = (12, 16) if team == "blue" else (20, 16)
    for troop_str in troops:
        if troop_str in NAME_TO_UNIT:
            troop_type = NAME_TO_UNIT[troop_str]
            if troop_type in _AVAILABLE_UNITS:
                for i in range(troops[troop_str]):
                    unit = np.zeros(len(FEATURE_INFO))
                    coordinate = generate_coordinates(spawn, radius)
                    for feature in FEATURE_INFO:
                        info = FEATURE_INFO[feature]
                        if feature == "unit_type":
                            unit[info.raw_idx] = troop_type
                        elif feature == "x":
                            unit[info.raw_idx] = coordinate[0]
                        elif feature == "y":
                            unit[info.raw_idx] = coordinate[1]
                        elif feature == "health":
                            unit[info.raw_idx] = _UNIT_DATA[troop_type].health
                        elif feature == "health_ratio":
                            unit[info.raw_idx] = 255
                        elif feature == "shield":
                            unit[info.raw_idx] = _UNIT_DATA[troop_type].shield
                        elif feature == "shield_ratio":
                            unit[info.raw_idx] = (
                                255 if _UNIT_DATA[troop_type].shield > 0 else 0
                            )
                        elif feature == "energy_ratio":
                            unit[info.raw_idx] = 0
                        elif feature == "alliance":
                            unit[info.raw_idx] = 1 if team == "blue" else 4
                        elif feature == "owner":
                            unit[info.raw_idx] = 1 if team == "blue" else 2
                        elif feature == "facing":
                            unit[info.raw_idx] = 0  # np.random.randint(0, 7)
                        elif feature == "cloak":
                            unit[info.raw_idx] = 3
                        elif feature == "is_on_screen":
                            unit[info.raw_idx] = 1
                        elif feature == "build_progress":
                            unit[info.raw_idx] = 100
                    army.append(unit)
    return np.asarray(army)


def generate_upgrades(upgrades, race):
    selected_upgrades = []
    for upgrade_str in upgrades:
        if upgrade_str in UPGRADE_TICKS:
            if (
                len(UPGRADE_TICKS[upgrade_str]) == 2
                and upgrades[upgrade_str] == 1
            ) or upgrade_str == "StructureArmor":
                selected_upgrades.append(
                    NAME_TO_UPGRADES[
                        upgrade_str
                        if upgrade_str != "StructureArmor"
                        else f"{race.capitalize()}{upgrade_str}"
                    ].value
                )
            elif (
                len(UPGRADE_TICKS[upgrade_str]) > 2
                and upgrades[upgrade_str] > 0
            ):
                for i in range(upgrades[upgrade_str], 0, -1):
                    selected_upgrades.append(
                        NAME_TO_UPGRADES[
                            f"{race.capitalize()}{upgrade_str}Level{upgrades[upgrade_str]}"
                        ]
                    )
    return np.asarray(selected_upgrades)


def generate_timestep(config, map_size=(32, 32), radius=4, spawn=None):
    teams = []
    upgrades = []
    for team in config:
        team_config = config[team]
        for race in team_config:
            race_config = team_config[race]
            teams.append(
                generate_army(
                    race_config,
                    team,
                    map_size=map_size,
                    radius=radius,
                    spawn=spawn,
                )
            )
            upgrades.append(generate_upgrades(race_config, race))
    timestep = teams[0]
    for team in teams[1:]:
        if timestep.shape[0] == 0:
            timestep = team
        elif team.shape[0] > 0:
            timestep = np.append(timestep, team, axis=0)
    return timestep, upgrades


def generate_perturbed_configs(config, unit_max=None):
    configs = {"main": config}
    for team in config:
        team_config = config[team]
        for race in team_config:
            race_config = team_config[race]
            for unit in race_config:
                if race_config[unit] > 0:
                    perturbed = copy.deepcopy(config)
                    perturbed[team][race][unit] -= 1
                    configs[unit + "-1"] = perturbed
                if race_config[unit] < (unit_max[unit] if unit_max else np.inf):
                    perturbed = copy.deepcopy(config)
                    perturbed[team][race][unit] += 1
                    configs[unit + "+1"] = perturbed
    return configs


def generate_batches(
    configs,
    cpu_preprocessor=cpu_preprocessor,
    gpu_preprocessor=gpu_preprocessor,
    map_size=(x_max, y_max),
    radius=4,
):
    batches = []
    upgrade_batches = []
    spawn = generate_spawn(map_size, radius=radius)
    for config_name in configs:
        timestep, upgrades = generate_timestep(
            configs[config_name], map_size, radius, spawn
        )
        obs = {"raw_units": timestep}
        obs = cpu_preprocessor(obs)
        batches.append(obs["proc_units"].numpy())
        upgrade_batches.append(create_upgrades_vec(upgrades))
    batches = np.asarray(batches)
    upgrade_batches = np.asarray(upgrade_batches)
    obs = {"proc_units": batches}
    obs = gpu_preprocessor(obs)
    return obs["proc_units"], upgrade_batches


def generate_prediction_json(predictions, config, unit_max=None):
    pred_json = copy.deepcopy(config)
    i = 0
    for team in config:
        team_config = config[team]
        for race in team_config:
            if team == "blue":
                pred_json[team][race] = {
                    k: predictions[k][0].item() * 100 for k in predictions
                }
            elif team == "red":
                pred_json[team][race] = {
                    k: (1 - predictions[k][0].item()) * 100 for k in predictions
                }
            race_config = team_config[race]
            win_deltas = {}
            # print(race)
            for unit in race_config:
                win_deltas[unit] = []
                if race_config[unit] > 0:
                    # print(race_config[unit], i)
                    if team == "blue":
                        win_deltas[unit].append(
                            (
                                predictions["win"][i].item()
                                - (pred_json[team][race]["win"] / 100)
                            )
                            * 100
                        )
                    elif team == "red":
                        win_deltas[unit].append(
                            (
                                (1 - predictions["win"][i].item())
                                - (pred_json[team][race]["win"] / 100)
                            )
                            * 100
                        )
                    i += 1
                else:
                    win_deltas[unit].append(0)
                if race_config[unit] < (
                    unit_max[unit] if unit_max else np.inf
                ):
                    # print(race_config[unit], i)
                    if team == "blue":
                        win_deltas[unit].append(
                            (
                                predictions["win"][i].item()
                                - (pred_json[team][race]["win"] / 100)
                            )
                            * 100
                        )
                    elif team == "red":
                        win_deltas[unit].append(
                            (
                                (1 - predictions["win"][i].item())
                                - (pred_json[team][race]["win"] / 100)
                            )
                            * 100
                        )
                    i += 1
                else:
                    win_deltas[unit].append(0)
        # print(len(predictions["win"]), i)
        pred_json[team][race]["win_deltas"] = win_deltas
    return pred_json
