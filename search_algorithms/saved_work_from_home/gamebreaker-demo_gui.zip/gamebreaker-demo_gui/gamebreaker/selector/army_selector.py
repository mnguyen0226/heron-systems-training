# Copyright (C) 2021 Heron Systems, Inc.
from abc import ABC
from abc import abstractmethod
from typing import List
from typing import Tuple
from typing import Union

import numpy as np

from gamebreaker import unit_data
from gamebreaker.selector.base import Selector
from gamebreaker.selector.selector import GeneralUniformSelector


class ArmySelector(Selector, ABC):
    def __init__(
        self,
        available_units: List[
            Union[unit_data.units.Terran, unit_data.units.Protoss, unit_data.units.Zerg,]
        ],
        x_area: Tuple[int, int] = (0, 10),
        y_area: Tuple[int, int] = (0, 10),
        seed: int = None,
    ):
        """A template that allows users to specify StarCraft II army sampling schemes."""
        super().__init__(seed)
        self.available_units = available_units
        self.x_area = x_area
        self.y_area = y_area

    @abstractmethod
    def select(self):
        ...

    def position(self):
        """Randomizes position within some given bounds."""
        return (
            int((self.x_area[1] - self.x_area[0] + 1) * self.rng.rand() + self.x_area[0]),
            int((self.y_area[1] - self.y_area[0] + 1) * self.rng.rand() + self.y_area[0]),
        )

    def format_dict(self, unit_list):
        """Formats list of units into output format."""
        return [{"unit_type": unit, "pos": self.position()} for unit in unit_list]


class GeneralUniformArmySelector(ArmySelector):
    def __init__(
        self,
        available_units: List[
            Union[unit_data.units.Terran, unit_data.units.Protoss, unit_data.units.Zerg,]
        ],
        x_area: Tuple[int, int] = (0, 10),
        y_area: Tuple[int, int] = (0, 10),
        minerals: int = np.Infinity,
        gas: int = np.Infinity,
        supply: int = np.Infinity,
        units: int = np.Infinity,
        seed: int = None,
    ):
        """
        Samples StarCraft II armies uniformly at random given a collection of available
        units, budgets on the armies (minerals, gas, supply, etc.), and bounds on where to
        spawn the units.
        """
        super().__init__(available_units, x_area, y_area, seed)

        self.minerals = minerals
        self.gas = gas
        self.supply = supply
        self.units = units

        # Determine the actual constraints that we're working with.
        self._constraints = build_constraints(
            self.available_units,
            minerals=self.minerals,
            gas=self.gas,
            supply=self.supply,
            units=self.units,
        )

        # Check that we have at least one valid constraint
        if not self._constraints:
            raise ValueError("Couldn't find any bounded constraints.")

        # Create the GeneralUniformSelector object
        self._gus = GeneralUniformSelector(self._constraints, seed=self.rng)

    def select(self):
        # Turn this sample into the right format
        sample = self._gus.select()
        if sample is None:
            return {}

        units = []
        for unit_ix, unit_type in enumerate(self.available_units):
            units.extend([unit_type for _ in range(sample[unit_ix])])

        return self.format_dict(units)


def build_constraints(
    available_units, minerals=np.Infinity, gas=np.Infinity, supply=np.Infinity, units=np.Infinity
):
    # Ignore constraints with infinite maximum. First, work with field constraints. Can't use a list
    # comprehension here because we're using locals().
    ret = []
    for field in ["minerals", "gas", "supply"]:
        if locals()[field] < np.Infinity:
            ret.append(
                (
                    [getattr(unit_data.unit_data(unit), field) for unit in available_units],
                    locals()[field],
                )
            )

    # Constrain the total number of units
    if units < np.Infinity:
        ret.append(([1 for unit in available_units], units))

    return ret


def to_raw(sample, index_names):
    from pysc2.lib.features import PlayerRelative
    from pysc2.lib.named_array import NamedNumpyArray

    ret = NamedNumpyArray(
        np.zeros((len(sample), len(index_names)), dtype=np.int64), [None, index_names],
    )

    for ix, unit in enumerate(sample):
        ret[ix].unit_type = unit["unit_type"]
        ret[ix].alliance = int(PlayerRelative.SELF)
        ret[ix].health = 0  #####
        ret[ix].shield = 0  #####
        ret[ix].energy = 0  #####
        ret[ix].build_progress = 100
        ret[ix].health_ratio = 255
        ret[ix].shield_ratio = 0  #####
        ret[ix].energy_ratio = 0  #####
        ret[ix].owner = 0  #####
        ret[ix].x = 0  #####
        ret[ix].y = 0  #####
        ret[ix].facing = 2
        ret[ix].radius = 0
        ret[ix].cloak = 3
        ret[ix].attack_upgrade_level = 1
        ret[ix].armor_upgrade_level = 1
        ret[ix].shield_upgrade_level = 1
        ret[ix].on_creep = 0

    return ret
