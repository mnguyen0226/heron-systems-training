import re
from typing import List
from typing import Optional
from typing import Union

import numpy as np
from pysc2.lib import units

from gamebreaker.data.upgrade_data import all_upgrades
from gamebreaker.data.upgrade_data import upgrade_race
from gamebreaker.selector.selector import Selector


class RandomUpgradeSelector(Selector):
    def __init__(
        self, seed: Optional[int] = 0, race: Union[units.Protoss, units.Terran, units.Zerg] = None
    ):
        """Class that will select random upgrades uniformly.

        Parameters
        ----------
        seed: int
            Seed for random number generator
        race: Union[units.Protoss, units.Terran, units.Zerg]
            What race to draw the upgrades from. If None, selector will select from all upgrades
            indiscriminately
        """
        # Initialize the Selector base with dummy values
        super().__init__(seed)
        self.race = race

        if race is None:
            self.available_upgrades = [action_name for action_name in all_upgrades()]
        else:
            self.available_upgrades = [
                action_name
                for action_name in all_upgrades()
                if upgrade_race(action_name) == self.race
            ]

    def select(self) -> List[str]:
        """Function called by the environment to generate a list of upgrades

        Returns
        -------
        List[str]
            List of research commands for the upgrades
        """
        # Randomly choose how many upgrades we're applying
        nb_upgrades = np.random.randint(len(self.available_upgrades))

        # Uniformly sample upgrades from the entire list
        selected_upgrades = np.random.choice(self.available_upgrades, nb_upgrades, replace=False,)

        selected_upgrades = selected_upgrades.tolist()

        # Any upgrade that is level 2 or level 3 cannot be researched until the previous
        # level upgrade is APPLIED (if you want armor level 2, you can't research it until
        # armor level 1 is finished researching). Therefore, we ensure the full tech trees
        # are included for leveled upgrades
        for upgrade in selected_upgrades:
            # All commands for researching upgrades end with "#_quick", where # is a
            # number.
            upgrade_level = re.search("(\d)", upgrade)
            if not upgrade_level:
                continue
            elif upgrade_level.group() == "2" or upgrade_level.group() == "3":
                upgrade_base = upgrade.split(upgrade_level.group())[0]
                for level in ["1_quick", "2_quick"]:
                    if upgrade_base + level not in selected_upgrades:
                        selected_upgrades.append(upgrade_base + level)

        # Sort to ensure all leveled upgrades occur in the proper order
        return sorted(selected_upgrades)
