# Copyright (C) 2020 Heron Systems, Inc.
import abc
from typing import List
from typing import Tuple

import numpy as np
from pysc2.lib import units

from gamebreaker.env.base.terrain_modifier import AddCreepRectangle
from gamebreaker.env.base.terrain_modifier import AddMultichoke
from gamebreaker.env.base.terrain_modifier import AddSingleBlocker
from gamebreaker.env.base.terrain_modifier import AddSingleCreepTumor
from gamebreaker.selector import GeneralUniformSelector
from gamebreaker.selector import Selector


class TerrainSelector(Selector, abc.ABC):
    def __init__(
        self, seed, bottom_left: Tuple[int, int], top_right: Tuple[int, int],
    ):
        """
        A generic terrain selector.

        :param seed: random seed
        :param bottom_left: bottom left of the specified space
        :param top_right: top right of the specified space
        """
        super().__init__(seed)
        self.bottom_left = bottom_left
        self.top_right = top_right

    @abc.abstractmethod
    def select(self):
        ...


class BlockingTerrainSelector(TerrainSelector, abc.ABC):
    def __init__(
        self,
        seed,
        bottom_left: Tuple[int, int],
        top_right: Tuple[int, int],
        unit_blocker: units.Neutral,
    ):
        """
        A generic terrain selector that involves adding blocks to part of the map.

        :param seed: random seed
        :param bottom_left: bottom left of the specified space
        :param top_right: top right of the specified space
        :param unit_blocker: the particular type of unit used in creating blocks
        """
        super().__init__(seed, bottom_left, top_right)
        self.unit_blocker = unit_blocker

    @abc.abstractmethod
    def select(self):
        ...


class _MultichokeLengthGeneralUniformSelector(Selector):
    def __init__(
        self, n_chokes, spacing, minimum_units_per_wall, choke_length_bounds, constraints, seed,
    ):
        super().__init__(seed)
        self.n_chokes = n_chokes
        self.spacing = spacing
        self.minimum_units_per_wall = minimum_units_per_wall
        self.choke_length_bounds = choke_length_bounds

        self._gus = GeneralUniformSelector(constraints)

    def select(self):
        return [
            segment_length + self.minimum_units_per_wall
            if segment_ix % 2 == 0
            else segment_length + self.choke_length_bounds[0]
            for segment_ix, segment_length in enumerate(self._gus.select())
        ]

    @staticmethod
    def create(
        n_chokes,
        wall_length,
        unit_blocker,
        minimum_units_per_wall,
        choke_length_bounds,
        seed: int = None,
    ):
        spacing = AddMultichoke.SPACING_MAP[unit_blocker]
        n_segments = 2 * n_chokes + 1
        total_length_constraint = (
            [spacing if segment_ix % 2 == 0 else 1 for segment_ix in range(n_segments)],
            # We use this wall length to enforce minimum values chosen per variable
            wall_length
            - spacing * minimum_units_per_wall * (n_chokes + 1)
            - choke_length_bounds[0] * n_chokes,
        )

        if total_length_constraint[1] < 0:
            return

        # TODO(karthik): enforcing max choke lengths triggers a bug in
        # GeneralUniformSelector; determine what the issue is.
        # max_choke_length_constraints = [
        #     (
        #         [1 if segment_ix == choke_ix else 0
        #          for segment_ix in range(n_segments)],
        #         choke_length_bounds[1],
        #     )
        #     for choke_ix in range(1, n_segments, 2)
        # ]
        #
        # for mclc in max_choke_length_constraints:
        #     assert len(mclc[0]) == len(total_length_constraint[0])

        return _MultichokeLengthGeneralUniformSelector(
            n_chokes,
            spacing,
            minimum_units_per_wall,
            choke_length_bounds,
            [total_length_constraint],
            seed,
        )


class MultichokeSelector(BlockingTerrainSelector):
    LENGTH_CULL = 2

    def __init__(
        self,
        bottom_left: Tuple[int, int],
        top_right: Tuple[int, int],
        orientations: List[str] = ["right", "up"],
        n_multichokes: List[int] = list(range(1, 6)),
        n_chokes: List[int] = list(range(1, 4)),
        thickness: List[int] = list(range(2, 4)),
        minimum_units_per_wall: int = 4,
        choke_length_bounds: Tuple[int, int] = (1, 5),
        unit_blocker: units.Neutral = units.Neutral.XelNagaTower,
        seed: int = None,
    ):
        """
        Add a wall to your environment. A wall is a Multichoke with no gaps.

        :param bottom_left: bottom left of the specified space
        :param top_right: top right of the specified space
        :param orientations: list of orientations that the multichokes can appear
        :param n_multichokes: list of possible number of multichokes that can appear
        :param n_chokes: list of possible number of chokes per multichoke
        :param minimum_units_per_wall: minimum number of blocks that constitutes a "wall"
        :param choke_length_bounds: a tuple (min_value, max_value) that specifies the
        minimum and maximum lengths for a choke in world units
        :param unit_blocker: the particular type of unit used in creating blocks
        :param seed: random seed
        """
        super().__init__(seed, bottom_left, top_right, unit_blocker)
        self.orientations = orientations
        self.n_chokes = n_chokes
        self.thickness = thickness
        self.n_multichokes = n_multichokes
        self.choke_length_bounds = choke_length_bounds
        self.unit_blocker = unit_blocker

        self.wall_length = {
            "right": self.top_right[0] - self.bottom_left[0] - MultichokeSelector.LENGTH_CULL,
            "up": self.top_right[1] - self.bottom_left[1] - MultichokeSelector.LENGTH_CULL,
        }

        self._multichoke_gus = {
            nc: {
                "right": _MultichokeLengthGeneralUniformSelector.create(
                    nc,
                    self.wall_length["right"],
                    self.unit_blocker,
                    minimum_units_per_wall=minimum_units_per_wall,
                    choke_length_bounds=choke_length_bounds,
                    seed=self.rng,
                ),
                "up": _MultichokeLengthGeneralUniformSelector.create(
                    nc,
                    self.wall_length["up"],
                    self.unit_blocker,
                    minimum_units_per_wall=minimum_units_per_wall,
                    choke_length_bounds=choke_length_bounds,
                    seed=self.rng,
                ),
            }
            for nc in self.n_chokes
        }

        # Only keep selectors that have been properly created
        self._multichoke_gus = {
            k: v for k, v in self._multichoke_gus.items() if v["right"] and v["up"]
        }
        self.n_chokes = sorted(list(self._multichoke_gus.keys()))

        if len(self.n_chokes) == 0:
            raise ValueError(
                "Couldn't find any valid multichoke configurations, likely because the "
                "imposed constraints were too restrictive."
            )

    def select(self):
        # First, determine orientation
        orientation = self.rng.choice(self.orientations)

        if orientation in ["left", "right"]:
            orientation = "right"
        elif orientation in ["up", "down"]:
            orientation = "up"
        else:
            raise ValueError(f"Invalid orientation found: {orientation}")

        # Next, determine the number of multichokes
        n_multichokes = self.rng.choice(self.n_multichokes)

        ret = []

        for multichoke_ix in range(n_multichokes):
            # What are the choke lengths?
            n_chokes = self.rng.choice(self.n_chokes)
            selector = self._multichoke_gus[n_chokes][orientation]

            offset = self.wall_length[orientation] // (n_multichokes + 2) * (multichoke_ix + 1)

            start_xy = np.array(self.bottom_left) + np.array(
                [0, offset] if orientation in ["left", "right"] else [offset, 0]
            )

            ret.append(
                AddMultichoke(
                    start_xy,
                    selector.select(),
                    orientation=orientation,
                    thickness=self.rng.choice(self.thickness),
                    unit_blocker=self.unit_blocker,
                )
            )

        return ret


class SprinkleSelector(TerrainSelector):
    def __init__(
        self,
        bottom_left: Tuple[int, int],
        top_right: Tuple[int, int],
        n_sprinkles: List[int] = list(range(50)),
        inverse_density: int = 4,
        seed: int = None,
    ):
        """
        Sprinkle random objects throughout the specified space.

        :param bottom_left: bottom left of the specified space
        :param top_right: top right of the specified space
        :param n_sprinkles: number of sprinkles throughout the space
        :param inverse_density: the higher number, the less densely spaced objects
        will be.
        :param seed: random seed
        """
        super().__init__(seed, bottom_left, top_right)
        self.inverse_density = inverse_density
        self.n_sprinkles = n_sprinkles

    def get_placements(self):
        placements = [
            (x, y)
            for x in range(self.bottom_left[0], self.top_right[0] + 1, self.inverse_density)
            for y in range(self.bottom_left[1], self.top_right[1] + 1, self.inverse_density)
        ]

        placement_ixs = np.random.choice(
            np.arange(len(placements)),
            size=min(self.rng.choice(self.n_sprinkles), len(placements)),
            replace=False,
        )

        return [placements[ix] for ix in placement_ixs]

    @abc.abstractmethod
    def select(self):
        ...


class SprinkleBlockSelector(SprinkleSelector):
    def __init__(
        self,
        bottom_left: Tuple[int, int],
        top_right: Tuple[int, int],
        n_blockers: List[int] = list(range(50)),
        inverse_density: int = 4,
        unit_blocker: units.Neutral = units.Neutral.XelNagaTower,
        seed: int = None,
    ):
        """
        Sprinkle random blocks throughout the specified space.

        :param bottom_left: bottom left of the specified space
        :param top_right: top right of the specified space
        :param n_sprinkles: number of sprinkles throughout the space
        :param inverse_density: the higher this number, the less densely spaced blocks
        will be.
        :param unit_blocker: the particular type of unit used in creating blocks
        :param seed: random seed
        """
        super().__init__(
            bottom_left, top_right, n_blockers, inverse_density=inverse_density, seed=seed,
        )
        self.unit_blocker = unit_blocker

    def select(self):
        return [
            AddSingleBlocker(placement, unit_blocker=self.unit_blocker)
            for placement in self.get_placements()
        ]


class SprinkleCreepSelector(SprinkleSelector):
    def __init__(
        self,
        bottom_left: Tuple[int, int],
        top_right: Tuple[int, int],
        n_tumors: List[int] = list(range(50)),
        inverse_density: int = 4,
        seed: int = None,
    ):
        """
        Sprinkle random creep tumors throughout the specified space.

        :param bottom_left: bottom left of the specified space
        :param top_right: top right of the specified space
        :param n_tumors: number of creep tumors to sprinkle throughout the space
        :param inverse_density: the higher this number, the less densely spaced blocks
        will be.
        :param seed: random seed
        """
        super().__init__(
            bottom_left, top_right, n_tumors, inverse_density=inverse_density, seed=seed
        )

    def select(self):
        return [AddSingleCreepTumor(placement) for placement in self.get_placements()]


class CreepRectangleSelector(TerrainSelector):
    def __init__(
        self, bottom_left: Tuple[int, int], top_right: Tuple[int, int],
    ):
        """
        Add a creep rectangle to the specified space.

        :param bottom_left: bottom left of the specified space
        :param top_right: top right of the specified space
        """
        super().__init__(None, bottom_left, top_right)

    def select(self):
        return [
            AddCreepRectangle(
                self.bottom_left,
                self.top_right[0] - self.bottom_left[0],
                self.top_right[1] - self.bottom_left[1],
            )
        ]
