import re
from typing import List
from typing import Optional

from gamebreaker.data.upgrade_data import all_upgrades
from gamebreaker.selector.selector import Selector


class UpgradeSelector(Selector):
    def __init__(self, upgrades: List[str], seed: Optional[int] = 0):
        """Allows user to specific exactly what upgrades they would like in a game.

        Parameters
        ----------
        upgrades: List[str]
            List of upgrade commands the user would like. Must be of the form returned
            by all_upgrades()
        seed: Optional[int]
            Seed for the random number generator
        """
        # Initialize the Selector base with dummy values
        super().__init__(seed)

        self._check_upgrades_valid(upgrades)

        self.upgrades = upgrades

        self._check_leveled_upgrades()

    @staticmethod
    def _check_upgrades_valid(upgrade_list: List[str]):
        """Ensures all of the upgrades given are valid

        Parameters
        ----------
        upgrade_list: List[str]
            List of upgrades the user would like to include.

        """
        for upgrade in upgrade_list:
            if upgrade not in all_upgrades():
                raise RuntimeError(f"{upgrade} not an available upgrade! (See upgrade_data.py)")

    def _check_leveled_upgrades(self):
        """Function for making sure all leveled commands are handled properly, i.e., if a level 3
        upgrade is requested, this function will make sure that level 2 and 1 are also included. If
        they aren't, this function will add them."""
        for upgrade in self.upgrades:
            # All commands for researching upgrades end with '#_quick', where # is a 1, 2, or 3
            upgrade_level = re.search("(\d)", upgrade)
            if not upgrade_level:
                continue
            elif upgrade_level.group() == "2" or upgrade_level.group() == "3":
                upgrade_base = upgrade.split(upgrade_level.group())[0]
                for level in ["1_quick", "2_quick"]:
                    if upgrade_base + level not in self.upgrades:
                        self.upgrades.append(upgrade_base + level)

        self.upgrades = sorted(self.upgrades)

    def select(self) -> List[str]:
        """Function called by the environment to generate a list of upgrades

        Returns
        -------
        List[str]
            List of research commands for the upgrades
        """
        return self.upgrades
