# Copyright (C) 2020 Heron Systems, Inc.
import abc

import numpy as np


class Selector(abc.ABC):
    def __init__(self, seed):
        """A template that allows users to specify general sampling schemes."""
        if seed is None:
            self.rng = np.random
        elif type(seed) == int:
            self.rng = np.random.RandomState(seed=seed)
        else:
            # This happens when a user passes in a custom generator
            self.rng = seed

    @abc.abstractmethod
    def select(self):
        pass
